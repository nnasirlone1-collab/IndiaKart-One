import unittest
import uuid
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.database import db
from indiakart_one.app.services.cart_service import CartService

class TestEndToEndUserJourneys(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        
        # Super Admin
        admin_login = self.client.post("/api/v1/auth/login", json={"identifier": "9876543210", "password": "Admin#IndiaKart2026"})
        self.admin_headers = {"Authorization": f"Bearer {admin_login.json()['data']['access_token']}"}

        # Buyer
        buyer_login = self.client.post("/api/v1/auth/login", json={"identifier": "9123456780", "password": "Password#123"})
        self.buyer_headers = {"Authorization": f"Bearer {buyer_login.json()['data']['access_token']}"}
        self.buyer_id = "user-buyer-1"
        CartService.clear_cart(self.buyer_id)

    def test_journey_a_buy_vegetables(self):
        """Journey A: Buyer discovers nearby seller, adds vegetables, checks out, pays, and seller fulfils."""
        # 1. Discover nearby vegetable sellers
        near_res = self.client.get("/api/v1/businesses?user_lat=12.9716&user_lon=77.5946&category_id=cat-fruits-veg")
        self.assertEqual(near_res.status_code, 200)
        sellers = near_res.json()["data"]
        self.assertTrue(len(sellers) >= 1)
        seller = sellers[0]

        # 2. Open storefront and select products
        prods_res = self.client.get(f"/api/v1/businesses/{seller['id']}/products")
        self.assertEqual(prods_res.status_code, 200)
        products = prods_res.json()["data"]
        self.assertTrue(len(products) >= 1)

        # 3. Add to cart
        add_res = self.client.post("/api/v1/cart/items", json={
            "product_id": "prod-tomatoes",
            "quantity": 2
        }, headers=self.buyer_headers)
        self.assertEqual(add_res.status_code, 200)

        # 4. Review cart charges
        cart_res = self.client.get("/api/v1/cart", headers=self.buyer_headers)
        self.assertEqual(cart_res.status_code, 200)
        cart = cart_res.json()["data"]
        self.assertEqual(cart["total_unique_items"], 1)

        # 5. Checkout
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = :uid", {"uid": self.buyer_id})
        checkout_res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.buyer_headers)
        self.assertEqual(checkout_res.status_code, 200)
        order = checkout_res.json()["data"][0]

        # 6. Payment via UPI intent
        intent_res = self.client.post("/api/v1/payments/intent", json={"order_id": order["id"], "payment_method": "upi_qr"}, headers=self.buyer_headers)
        intent_id = intent_res.json()["data"]["payment_intent_id"]

        # 7. Payment capture
        self.client.post("/api/v1/payments/verify", json={
            "payment_intent_id": intent_id,
            "gateway_payment_id": f"pay_{uuid.uuid4().hex[:8]}"
        }, headers=self.buyer_headers)

        # 8. Seller confirmation & delivery
        seller_login = self.client.post("/api/v1/auth/login", json={"identifier": "9234567890", "password": "Password#123"})
        seller_headers = {"Authorization": f"Bearer {seller_login.json()['data']['access_token']}"}

        deliver_res = self.client.post(
            f"/api/v1/orders/{order['id']}/status",
            json={"new_status": "delivered", "notes": "Delivered to customer doorstep"},
            headers=seller_headers
        )
        self.assertEqual(deliver_res.status_code, 200)
        self.assertEqual(deliver_res.json()["data"]["order_status"], "delivered")

    def test_journey_b_order_food_with_addons(self):
        """Journey B: Buyer discovers restaurant, selects dish with custom bread & butter add-ons, and orders."""
        # 1. Search restaurant dish
        dish_res = self.client.get("/api/v1/products?q=Paneer")
        self.assertEqual(dish_res.status_code, 200)
        dishes = dish_res.json()["data"]
        self.assertTrue(len(dishes) >= 1)
        dish = dishes[0]

        # 2. Get dish detail to read addons
        detail = self.client.get(f"/api/v1/products/{dish['id']}").json()["data"]
        addon_id = detail["addon_groups"][0]["addons"][0]["id"]

        # 3. Add to cart with addon
        add_res = self.client.post("/api/v1/cart/items", json={
            "product_id": dish["id"],
            "quantity": 1,
            "addon_ids": [addon_id]
        }, headers=self.buyer_headers)
        self.assertEqual(add_res.status_code, 200)

        # 4. Checkout
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = :uid", {"uid": self.buyer_id})
        order_res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.buyer_headers)
        self.assertEqual(order_res.status_code, 200)
        order = order_res.json()["data"][0]
        self.assertEqual(order["order_type"], "food")

    def test_journey_e_new_seller_onboarding_and_kyc_approval(self):
        """Journey E: New user registers, submits seller onboarding application, Admin reviews and approves KYC."""
        # 1. Register new seller
        mobile = f"987{uuid.uuid4().hex[:7]}"
        reg_res = self.client.post("/api/v1/auth/register", json={
            "mobile_number": mobile,
            "full_name": "Rajesh Kumar",
            "password": "Password#123",
            "initial_role": "buyer"
        })
        self.assertEqual(reg_res.status_code, 200)
        new_token = reg_res.json()["data"]["access_token"]
        new_headers = {"Authorization": f"Bearer {new_token}"}

        # 2. Submit 7-step onboarding
        onboard_res = self.client.post("/api/v1/seller/onboard", json={
            "legal_name": "Kumar Precision Tools Pvt Ltd",
            "display_name": "Kumar Precision Tools",
            "business_type": "manufacturer",
            "category_id": "cat-industrial-supplies",
            "description": "Precision tooling, milling cutters and carbide inserts",
            "phone": mobile,
            "gstin": "29AABCU9988C1Z3",
            "pan": "AABCU9988C",
            "address_line1": "Phase 1, Electronic City",
            "city": "Bengaluru",
            "state": "Karnataka",
            "pincode": "560100",
            "latitude": 12.8452,
            "longitude": 77.6602,
            "service_radius_km": 50.0,
            "account_number": "123456789012",
            "ifsc_code": "HDFC0001234"
        }, headers=new_headers)
        self.assertEqual(onboard_res.status_code, 200)
        biz_id = onboard_res.json()["business_id"]

        # 3. Super Admin views pending KYC queue
        pending_res = self.client.get("/api/v1/admin/sellers/pending", headers=self.admin_headers)
        self.assertEqual(pending_res.status_code, 200)
        pending_ids = [b["id"] for b in pending_res.json()["data"]]
        self.assertIn(biz_id, pending_ids)

        # 4. Super Admin approves KYC
        approve_res = self.client.post(
            f"/api/v1/admin/sellers/{biz_id}/review",
            json={"action": "approve"},
            headers=self.admin_headers
        )
        self.assertEqual(approve_res.status_code, 200)
        self.assertEqual(approve_res.json()["data"]["verification_status"], "approved")

        # 5. Verify seller can now access dashboard
        dash_res = self.client.get("/api/v1/seller/dashboard", headers=new_headers)
        self.assertEqual(dash_res.status_code, 200)
        self.assertEqual(dash_res.json()["data"]["business"]["verification_status"], "approved")

if __name__ == "__main__":
    unittest.main()
