import unittest
import uuid
from fastapi.testclient import TestClient
from indiakart_one.app.main import app

class TestAuthAndRBAC(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.test_mobile = f"998{uuid.uuid4().hex[:7]}"

    def test_01_user_registration_success(self):
        res = self.client.post("/api/v1/auth/register", json={
            "mobile_number": self.test_mobile,
            "full_name": "Pooja Verma",
            "password": "SecurePassword#2026",
            "email": f"pooja_{uuid.uuid4().hex[:5]}@example.com",
            "initial_role": "buyer"
        })
        self.assertEqual(res.status_code, 200)
        data = res.json()["data"]
        self.assertEqual(data["mobile_number"], self.test_mobile)
        self.assertIn("access_token", data)

    def test_02_duplicate_registration_rejected(self):
        mobile = f"997{uuid.uuid4().hex[:7]}"
        self.client.post("/api/v1/auth/register", json={
            "mobile_number": mobile,
            "full_name": "Initial User",
            "password": "Password#123"
        })
        res = self.client.post("/api/v1/auth/register", json={
            "mobile_number": mobile,
            "full_name": "Duplicate User",
            "password": "Password#123"
        })
        self.assertEqual(res.status_code, 400)
        self.assertIn("already exists", res.json()["detail"])

    def test_03_login_success_and_failure(self):
        mobile = f"996{uuid.uuid4().hex[:7]}"
        self.client.post("/api/v1/auth/register", json={
            "mobile_number": mobile,
            "full_name": "Login User",
            "password": "SecurePassword#2026"
        })

        # Valid login
        res = self.client.post("/api/v1/auth/login", json={
            "identifier": mobile,
            "password": "SecurePassword#2026"
        })
        self.assertEqual(res.status_code, 200)
        token = res.json()["data"]["access_token"]
        self.assertTrue(len(token) > 20)

        # Invalid password
        res_fail = self.client.post("/api/v1/auth/login", json={
            "identifier": mobile,
            "password": "WrongPassword"
        })
        self.assertEqual(res_fail.status_code, 401)

    def test_04_role_based_access_control(self):
        mobile = f"995{uuid.uuid4().hex[:7]}"
        reg_res = self.client.post("/api/v1/auth/register", json={
            "mobile_number": mobile,
            "full_name": "Buyer User",
            "password": "SecurePassword#2026",
            "initial_role": "buyer"
        })
        buyer_token = reg_res.json()["data"]["access_token"]

        # Attempt to access Super Admin overview endpoint
        admin_res = self.client.get(
            "/api/v1/admin/overview",
            headers={"Authorization": f"Bearer {buyer_token}"}
        )
        self.assertEqual(admin_res.status_code, 403)

        # Super Admin login
        admin_login = self.client.post("/api/v1/auth/login", json={
            "identifier": "9876543210",
            "password": "Admin#IndiaKart2026"
        })
        admin_token = admin_login.json()["data"]["access_token"]

        admin_overview = self.client.get(
            "/api/v1/admin/overview",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        self.assertEqual(admin_overview.status_code, 200)
        self.assertIn("total_users", admin_overview.json()["data"])

if __name__ == "__main__":
    unittest.main()
