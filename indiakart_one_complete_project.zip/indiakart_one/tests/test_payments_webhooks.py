import unittest
import hmac
import hashlib
import json
import uuid
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.config import settings
from indiakart_one.app.database import db

class TestPaymentsAndWebhooks(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        # Login as buyer
        buyer_login = self.client.post("/api/v1/auth/login", json={"identifier": "9123456780", "password": "Password#123"})
        self.buyer_token = buyer_login.json()["data"]["access_token"]
        self.buyer_headers = {"Authorization": f"Bearer {self.buyer_token}"}

        # Login as Super Admin
        admin_login = self.client.post("/api/v1/auth/login", json={"identifier": "9876543210", "password": "Admin#IndiaKart2026"})
        self.admin_token = admin_login.json()["data"]["access_token"]
        self.admin_headers = {"Authorization": f"Bearer {self.admin_token}"}

    def test_01_create_upi_payment_intent(self):
        # Create an order first
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = 'user-buyer-1'")
        self.client.post("/api/v1/cart/items", json={"product_id": "prod-potatoes", "quantity": 1}, headers=self.buyer_headers)
        order_res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.buyer_headers)
        order_id = order_res.json()["data"][0]["id"]

        intent_res = self.client.post("/api/v1/payments/intent", json={
            "order_id": order_id,
            "payment_method": "upi_qr",
            "gateway_provider": "razorpay"
        }, headers=self.buyer_headers)
        
        self.assertEqual(intent_res.status_code, 200)
        data = intent_res.json()["data"]
        self.assertIn("payment_intent_id", data)
        self.assertIn("upi_payment_string", data)
        self.assertTrue(data["upi_payment_string"].startswith("upi://pay?"))
        self.assertIn("BHIM", data["supported_upi_apps"])
        self.assertIn("Google Pay", data["supported_upi_apps"])
        self.assertEqual(data["status"], "created")

    def test_02_payment_verification_and_capture(self):
        # Create test order & intent
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = 'user-buyer-1'")
        self.client.post("/api/v1/cart/items", json={"product_id": "prod-potatoes", "quantity": 1}, headers=self.buyer_headers)
        order_res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.buyer_headers)
        order_id = order_res.json()["data"][0]["id"]

        intent_res = self.client.post("/api/v1/payments/intent", json={"order_id": order_id}, headers=self.buyer_headers)
        intent_id = intent_res.json()["data"]["payment_intent_id"]

        # Verify payment
        pay_id = f"pay_test_{uuid.uuid4().hex[:8]}"
        verify_res = self.client.post("/api/v1/payments/verify", json={
            "payment_intent_id": intent_id,
            "gateway_payment_id": pay_id,
            "gateway_signature": "mock_valid_signature_2026"
        }, headers=self.buyer_headers)

        self.assertEqual(verify_res.status_code, 200)
        self.assertEqual(verify_res.json()["data"]["status"], "captured")

        # Verify order transitioned to paid & confirmed
        order = db.query_one("SELECT payment_status, order_status FROM orders WHERE id = :id", {"id": order_id})
        self.assertEqual(order["payment_status"], "paid")
        self.assertEqual(order["order_status"], "confirmed")

    def test_03_webhook_hmac_signature_verification(self):
        # 1. Create order & intent
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = 'user-buyer-1'")
        self.client.post("/api/v1/cart/items", json={"product_id": "prod-potatoes", "quantity": 1}, headers=self.buyer_headers)
        order_res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.buyer_headers)
        order_id = order_res.json()["data"][0]["id"]

        intent_res = self.client.post("/api/v1/payments/intent", json={"order_id": order_id}, headers=self.buyer_headers)
        gateway_order_id = intent_res.json()["data"]["gateway_order_id"]

        # 2. Formulate webhook payload
        payload = {
            "event": "payment.captured",
            "payload": {
                "payment": {
                    "entity": {
                        "id": f"pay_wh_{uuid.uuid4().hex[:6]}",
                        "order_id": gateway_order_id,
                        "amount": 7000,
                        "currency": "INR",
                        "status": "captured"
                    }
                }
            }
        }
        payload_bytes = json.dumps(payload).encode('utf-8')

        # 3. Test Invalid Signature (must be rejected)
        invalid_res = self.client.post(
            "/api/v1/payments/webhook",
            content=payload_bytes,
            headers={"Content-Type": "application/json", "X-Razorpay-Signature": "invalid_sig_abc123"}
        )
        self.assertEqual(invalid_res.status_code, 400)
        self.assertIn("Invalid webhook signature", invalid_res.json()["detail"])

        # 4. Test Valid HMAC-SHA256 Signature (must succeed)
        valid_signature = hmac.new(
            settings.RAZORPAY_WEBHOOK_SECRET.encode('utf-8'),
            payload_bytes,
            hashlib.sha256
        ).hexdigest()

        valid_res = self.client.post(
            "/api/v1/payments/webhook",
            content=payload_bytes,
            headers={"Content-Type": "application/json", "X-Razorpay-Signature": valid_signature}
        )
        self.assertEqual(valid_res.status_code, 200)
        self.assertEqual(valid_res.json()["status"], "success")

    def test_04_admin_refund_processing(self):
        # Create order, capture payment
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = 'user-buyer-1'")
        self.client.post("/api/v1/cart/items", json={"product_id": "prod-potatoes", "quantity": 1}, headers=self.buyer_headers)
        order_res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.buyer_headers)
        order = order_res.json()["data"][0]

        intent_res = self.client.post("/api/v1/payments/intent", json={"order_id": order["id"]}, headers=self.buyer_headers)
        self.client.post("/api/v1/payments/verify", json={
            "payment_intent_id": intent_res.json()["data"]["payment_intent_id"],
            "gateway_payment_id": "pay_test_refund"
        }, headers=self.buyer_headers)

        # Admin issues full refund
        refund_res = self.client.post(
            "/api/v1/payments/refund",
            json={
                "order_id": order["id"],
                "amount_minor": order["grand_total_minor"],
                "reason": "Customer cancellation within permitted window"
            },
            headers=self.admin_headers
        )
        self.assertEqual(refund_res.status_code, 200)
        self.assertEqual(refund_res.json()["data"]["status"], "processed")

        # Verify order payment status is refunded
        order_updated = db.query_one("SELECT payment_status FROM orders WHERE id = :id", {"id": order["id"]})
        self.assertEqual(order_updated["payment_status"], "refunded")

if __name__ == "__main__":
    unittest.main()
