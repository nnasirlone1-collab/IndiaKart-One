import unittest
import uuid
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.database import db
from indiakart_one.app.services.cart_service import CartService
from indiakart_one.app.services.order_service import OrderService

class TestCartAndOrders(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        # Login as buyer
        login_res = self.client.post("/api/v1/auth/login", json={
            "identifier": "9123456780",
            "password": "Password#123"
        })
        self.token = login_res.json()["data"]["access_token"]
        self.headers = {"Authorization": f"Bearer {self.token}"}
        self.user_id = "user-buyer-1"
        CartService.clear_cart(self.user_id)

    def test_01_multi_seller_cart_and_wholesale_tier_auto_apply(self):
        # 1. Add 2 kg Tomatoes from Agro Fresh (retail price ₹40/kg = 4000 paise)
        res1 = self.client.post("/api/v1/cart/items", json={
            "product_id": "prod-tomatoes",
            "quantity": 2
        }, headers=self.headers)
        self.assertEqual(res1.status_code, 200)
        data1 = res1.json()["data"]
        self.assertEqual(data1["total_unique_items"], 1)
        self.assertEqual(data1["seller_orders_count"], 1)
        self.assertEqual(data1["items_subtotal_minor"], 8000) # 2 * 4000

        # 2. Add Shahi Paneer Butter Masala from Annapurna Restaurant (₹240 = 24000 paise)
        res2 = self.client.post("/api/v1/cart/items", json={
            "product_id": "prod-paneer-butter",
            "quantity": 1
        }, headers=self.headers)
        self.assertEqual(res2.status_code, 200)
        data2 = res2.json()["data"]
        self.assertEqual(data2["total_unique_items"], 2)
        # Verify multi-seller grouping: exactly 2 distinct seller groups
        self.assertEqual(data2["seller_orders_count"], 2)

        # 3. Increase Tomato quantity to 20 kg (should trigger wholesale tier: ₹32/kg = 3200 paise)
        cart_item_id = data2["sellers"][0]["items"][0]["cart_item_id"]
        if data2["sellers"][0]["items"][0]["product_id"] != "prod-tomatoes":
            cart_item_id = data2["sellers"][1]["items"][0]["cart_item_id"]

        res3 = self.client.put(f"/api/v1/cart/items/{cart_item_id}", json={
            "quantity": 20
        }, headers=self.headers)
        self.assertEqual(res3.status_code, 200)
        data3 = res3.json()["data"]
        
        # Verify tier was applied
        tomato_item = None
        for s in data3["sellers"]:
            for it in s["items"]:
                if it["product_id"] == "prod-tomatoes":
                    tomato_item = it
        self.assertIsNotNone(tomato_item)
        self.assertEqual(tomato_item["applied_unit_price_minor"], 3200) # Wholesale Tier applied!

    def test_02_coupon_application(self):
        # Cart with INDIAKART50 coupon (flat ₹50 off = 5000 paise on min order ₹299 = 29900 paise)
        self.client.post("/api/v1/cart/items", json={
            "product_id": "prod-paneer-butter",
            "quantity": 2 # 2 * 240 = ₹480 (> ₹299)
        }, headers=self.headers)

        res = self.client.get("/api/v1/cart?coupon_code=INDIAKART50", headers=self.headers)
        self.assertEqual(res.status_code, 200)
        cart = res.json()["data"]
        self.assertEqual(cart["applied_coupon"], "INDIAKART50")
        self.assertEqual(cart["discount_minor"], 5000) # ₹50 discount

    def test_03_checkout_and_idempotency_protection(self):
        # Set up cart with 2 kg potatoes
        self.client.post("/api/v1/cart/items", json={
            "product_id": "prod-potatoes",
            "quantity": 2
        }, headers=self.headers)

        # Get shipping address
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = :uid", {"uid": self.user_id})
        self.assertIsNotNone(addr)

        idempotency_key = f"TEST_IDEMPOTENCY_{uuid.uuid4().hex[:8]}"

        # First checkout attempt
        res1 = self.client.post(
            "/api/v1/checkout",
            json={"shipping_address_id": addr["id"], "fulfilment_type": "delivery"},
            headers={**self.headers, "Idempotency-Key": idempotency_key}
        )
        self.assertEqual(res1.status_code, 200)
        orders1 = res1.json()["data"]
        self.assertTrue(len(orders1) >= 1)
        first_order_id = orders1[0]["id"]

        # Duplicate checkout attempt with identical idempotency key (e.g. repeated tap)
        res2 = self.client.post(
            "/api/v1/checkout",
            json={"shipping_address_id": addr["id"], "fulfilment_type": "delivery"},
            headers={**self.headers, "Idempotency-Key": idempotency_key}
        )
        self.assertEqual(res2.status_code, 200)
        orders2 = res2.json()["data"]
        # Must return the previously created order, not duplicate!
        self.assertEqual(orders2[0]["id"], first_order_id)

    def test_04_order_status_progression(self):
        # Place order
        self.client.post("/api/v1/cart/items", json={"product_id": "prod-tomatoes", "quantity": 1}, headers=self.headers)
        addr = db.query_one("SELECT id FROM addresses WHERE user_id = :uid", {"uid": self.user_id})
        
        res = self.client.post("/api/v1/checkout", json={"shipping_address_id": addr["id"]}, headers=self.headers)
        order_id = res.json()["data"][0]["id"]

        # Advance status: confirmed -> processing -> delivered
        seller_login = self.client.post("/api/v1/auth/login", json={"identifier": "9234567890", "password": "Password#123"})
        seller_headers = {"Authorization": f"Bearer {seller_login.json()['data']['access_token']}"}

        status_res = self.client.post(
            f"/api/v1/orders/{order_id}/status",
            json={"new_status": "processing", "notes": "Vegetables sorted and packaged"},
            headers=seller_headers
        )
        self.assertEqual(status_res.status_code, 200)
        self.assertEqual(status_res.json()["data"]["order_status"], "processing")

        # Verify timeline
        detail_res = self.client.get(f"/api/v1/orders/{order_id}", headers=self.headers)
        self.assertEqual(detail_res.status_code, 200)
        timeline = detail_res.json()["data"]["timeline"]
        statuses = [t["status"] for t in timeline]
        self.assertIn("pending_confirmation", statuses)
        self.assertIn("processing", statuses)

if __name__ == "__main__":
    unittest.main()
