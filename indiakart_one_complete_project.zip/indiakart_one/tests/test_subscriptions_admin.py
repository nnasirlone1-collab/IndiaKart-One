import unittest
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.database import db

class TestSubscriptionsAndAdmin(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        # Login Super Admin
        admin_login = self.client.post("/api/v1/auth/login", json={"identifier": "9876543210", "password": "Admin#IndiaKart2026"})
        self.admin_token = admin_login.json()["data"]["access_token"]
        self.admin_headers = {"Authorization": f"Bearer {self.admin_token}"}

        # Login Seller
        seller_login = self.client.post("/api/v1/auth/login", json={"identifier": "9234567890", "password": "Password#123"})
        self.seller_token = seller_login.json()["data"]["access_token"]
        self.seller_headers = {"Authorization": f"Bearer {self.seller_token}"}

        # Reset plan price to ₹1,499.00 (149900 paise) for clean baseline
        db.execute("UPDATE subscription_plans SET monthly_price_minor = 149900 WHERE plan_code = 'BUSINESS_PRO'")

    def test_01_default_business_pro_plan_exists(self):
        res = self.client.get("/api/v1/subscriptions/plans")
        self.assertEqual(res.status_code, 200)
        plans = res.json()["data"]
        pro_plan = next((p for p in plans if p["plan_code"] == "BUSINESS_PRO"), None)
        self.assertIsNotNone(pro_plan)
        self.assertEqual(pro_plan["name"], "IndiaKart Business Pro")
        self.assertEqual(pro_plan["monthly_price_inr"], 1499.0) # Initial default ₹1,499

    def test_02_admin_changes_subscription_price_with_audit_trail(self):
        plans_res = self.client.get("/api/v1/subscriptions/plans")
        plan_id = plans_res.json()["data"][0]["id"]

        # Super admin changes price from ₹1,499 to ₹1,899 (189,900 paise)
        update_res = self.client.put(
            f"/api/v1/admin/subscriptions/plans/{plan_id}/price",
            json={"new_monthly_price_minor": 189900, "notes": "Annual revision approved by board"},
            headers=self.admin_headers
        )
        self.assertEqual(update_res.status_code, 200)
        updated_plan = update_res.json()["data"]
        self.assertEqual(updated_plan["monthly_price_minor"], 189900)

        # Check public plans endpoint reflects new price immediately
        plans_after = self.client.get("/api/v1/subscriptions/plans")
        pro_after = next((p for p in plans_after.json()["data"] if p["id"] == plan_id), None)
        self.assertEqual(pro_after["monthly_price_inr"], 1899.0)

        # Verify audit log recorded old and new values
        audit_res = self.client.get("/api/v1/admin/audit-logs", headers=self.admin_headers)
        self.assertEqual(audit_res.status_code, 200)
        logs = audit_res.json()["data"]
        price_log = next((l for l in logs if l["action_type"] == "SUBSCRIPTION_PRICE_UPDATE"), None)
        self.assertIsNotNone(price_log)
        self.assertIn("₹1499", price_log["old_value"])
        self.assertIn("₹1899", price_log["new_value"])

    def test_03_seller_subscribes_and_activates(self):
        plans_res = self.client.get("/api/v1/subscriptions/plans")
        plan_id = plans_res.json()["data"][0]["id"]

        sub_res = self.client.post("/api/v1/subscriptions/subscribe", json={"plan_id": plan_id}, headers=self.seller_headers)
        self.assertEqual(sub_res.status_code, 200)
        data = sub_res.json()["data"]
        self.assertEqual(data["status"], "active")
        self.assertTrue(data["total_payable_minor"] > 0)

        # Check my status
        status_res = self.client.get("/api/v1/subscriptions/my-status", headers=self.seller_headers)
        self.assertEqual(status_res.status_code, 200)
        self.assertEqual(status_res.json()["data"]["status"], "active")

if __name__ == "__main__":
    unittest.main()
