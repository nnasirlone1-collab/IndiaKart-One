import unittest
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.services.product_service import ProductService

class TestProductsAndWholesale(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_01_wholesale_tier_price_calculation(self):
        # prod-tomatoes has tiers:
        # 1-9 kg: ₹40 (4000 paise)
        # 10-49 kg: ₹32 (3200 paise)
        # 50+ kg: ₹25 (2500 paise)
        price_5 = ProductService.calculate_applicable_unit_price("prod-tomatoes", quantity=5)
        self.assertEqual(price_5, 4000)

        price_15 = ProductService.calculate_applicable_unit_price("prod-tomatoes", quantity=15)
        self.assertEqual(price_15, 3200)

        price_100 = ProductService.calculate_applicable_unit_price("prod-tomatoes", quantity=100)
        self.assertEqual(price_100, 2500)

    def test_02_product_with_variants(self):
        detail = ProductService.get_product_detail("prod-tomatoes")
        self.assertIsNotNone(detail)
        self.assertTrue(len(detail["variants"]) >= 2)
        variant_names = [v["variant_name"] for v in detail["variants"]]
        self.assertIn("1kg Pack", variant_names)
        self.assertIn("5kg Carton", variant_names)

    def test_03_price_on_demand_product_behavior(self):
        # prod-cnc-milling is price_on_demand
        detail = ProductService.get_product_detail("prod-cnc-milling")
        self.assertEqual(detail["pricing_mode"], "price_on_demand")
        
        # calculate_applicable_unit_price should raise error
        with self.assertRaises(ValueError):
            ProductService.calculate_applicable_unit_price("prod-cnc-milling", quantity=1)

    def test_04_restaurant_addons(self):
        detail = ProductService.get_product_detail("prod-paneer-butter")
        self.assertIsNotNone(detail)
        self.assertTrue(len(detail["addon_groups"]) >= 1)
        addon_names = [a["name"] for a in detail["addon_groups"][0]["addons"]]
        self.assertIn("Garlic Butter Naan (2 pcs)", addon_names)

if __name__ == "__main__":
    unittest.main()
