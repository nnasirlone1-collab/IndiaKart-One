import unittest
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.database import db

class TestB2BRFQWorkflow(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        # Buyer login
        buyer_login = self.client.post("/api/v1/auth/login", json={"identifier": "9123456780", "password": "Password#123"})
        self.buyer_token = buyer_login.json()["data"]["access_token"]
        self.buyer_headers = {"Authorization": f"Bearer {self.buyer_token}"}

        # Manufacturer/Supplier login (Tata Steel owner)
        supplier_login = self.client.post("/api/v1/auth/login", json={"identifier": "9345678901", "password": "Password#123"})
        self.supplier_token = supplier_login.json()["data"]["access_token"]
        self.supplier_headers = {"Authorization": f"Bearer {self.supplier_token}"}

    def test_01_complete_rfq_quotation_and_order_conversion(self):
        # 1. Buyer creates RFQ for 500 units of custom alloy flanges
        rfq_res = self.client.post("/api/v1/rfq", json={
            "product_name": "Custom CNC Turned Alloy Flanges 150mm",
            "required_quantity": 500,
            "unit_of_measure": "piece",
            "delivery_pincode": "560058",
            "delivery_city": "Bengaluru",
            "specifications": "Material SS316, 4 bolt holes, pressure rating 300 PSI",
            "target_price_minor": 85000, # ₹850 target
            "customization_details": "Laser engraved batch number on each flange"
        }, headers=self.buyer_headers)
        
        self.assertEqual(rfq_res.status_code, 200)
        rfq = rfq_res.json()["data"]
        rfq_id = rfq["id"]
        self.assertEqual(rfq["status"], "open")

        # 2. Supplier views RFQs and submits quotation #1
        quote_res1 = self.client.post(f"/api/v1/rfq/{rfq_id}/quotations", json={
            "unit_price_minor": 90000, # ₹900/piece
            "tax_rate_percent": 18.0,
            "packaging_costs_minor": 500000, # ₹5,000 packaging
            "shipping_costs_minor": 800000, # ₹8,000 freight
            "production_lead_time_days": 10,
            "payment_terms": "40% Advance, 60% On Delivery",
            "validity_days": 15,
            "notes": "CNC tooling and material certification included."
        }, headers=self.supplier_headers)
        
        self.assertEqual(quote_res1.status_code, 200)
        quote1 = quote_res1.json()["data"]
        self.assertEqual(quote1["revision_number"], 1)

        # 3. Supplier submits revised quotation #2 (Negotiation: reduced to ₹860/piece)
        quote_res2 = self.client.post(f"/api/v1/rfq/{rfq_id}/quotations", json={
            "unit_price_minor": 86000, # ₹860/piece
            "tax_rate_percent": 18.0,
            "packaging_costs_minor": 300000,
            "shipping_costs_minor": 700000,
            "production_lead_time_days": 8,
            "payment_terms": "30% Advance, 70% On Delivery",
            "validity_days": 14,
            "notes": "Revised pricing as per telephone discussion."
        }, headers=self.supplier_headers)
        
        self.assertEqual(quote_res2.status_code, 200)
        quote2 = quote_res2.json()["data"]
        self.assertEqual(quote2["revision_number"], 2) # Incremented revision!

        # 4. Buyer reviews quotations received for this RFQ
        buyer_view_quotes = self.client.get(f"/api/v1/rfq/{rfq_id}/quotations", headers=self.buyer_headers)
        self.assertEqual(buyer_view_quotes.status_code, 200)
        quotes_list = buyer_view_quotes.json()["data"]
        self.assertTrue(len(quotes_list) >= 2)

        # 5. Buyer accepts the revised quotation (quote2) -> Converts to Official Wholesale Order!
        accept_res = self.client.post(f"/api/v1/quotations/{quote2['id']}/accept", headers=self.buyer_headers)
        self.assertEqual(accept_res.status_code, 200)
        order = accept_res.json()["data"]
        self.assertEqual(order["order_type"], "wholesale")
        self.assertEqual(order["order_status"], "confirmed")
        self.assertTrue(order["order_number"].startswith("IKO-B2B-"))

        # Verify quotation status is converted
        updated_quote = db.query_one("SELECT status, resulting_order_id FROM quotations WHERE id = :id", {"id": quote2["id"]})
        self.assertEqual(updated_quote["status"], "accepted")
        self.assertEqual(updated_quote["resulting_order_id"], order["id"])

        # Verify RFQ status is accepted
        updated_rfq = db.query_one("SELECT status FROM buying_requirements WHERE id = :id", {"id": rfq_id})
        self.assertEqual(updated_rfq["status"], "accepted")

if __name__ == "__main__":
    unittest.main()
