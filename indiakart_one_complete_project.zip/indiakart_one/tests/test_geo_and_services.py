import unittest
from fastapi.testclient import TestClient
from indiakart_one.app.main import app
from indiakart_one.app.services.geo_service import GeoService

class TestGeoAndServices(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        # Login buyer
        login_res = self.client.post("/api/v1/auth/login", json={"identifier": "9123456780", "password": "Password#123"})
        self.buyer_token = login_res.json()["data"]["access_token"]
        self.buyer_headers = {"Authorization": f"Bearer {self.buyer_token}"}

    def test_01_haversine_and_road_distance_estimation(self):
        # Bangalore Koramangala (12.9352, 77.6245) to Indiranagar (12.9750, 77.6000)
        dist = GeoService.calculate_distance(12.9352, 77.6245, 12.9750, 77.6000)
        self.assertTrue(dist["straight_line_distance_km"] > 0)
        self.assertTrue(dist["estimated_road_distance_km"] > dist["straight_line_distance_km"])
        self.assertEqual(dist["distance_type"], "estimated_road_distance")
        self.assertTrue(dist["estimated_transit_minutes"] > 0)

    def test_02_nearby_business_discovery_with_radius(self):
        # Query near Bangalore center (12.9716, 77.5946)
        res = self.client.get("/api/v1/businesses?user_lat=12.9716&user_lon=77.5946&radius_km=25.0")
        self.assertEqual(res.status_code, 200)
        businesses = res.json()["data"]
        self.assertTrue(len(businesses) >= 3)
        # Verify distance fields are present
        for b in businesses:
            self.assertIn("straight_line_distance_km", b)
            self.assertIn("estimated_road_distance_km", b)
            self.assertIn("estimated_delivery_minutes", b)

    def test_03_services_marketplace_and_booking(self):
        # 1. List electrical and appliance services
        services_res = self.client.get("/api/v1/services")
        self.assertEqual(services_res.status_code, 200)
        services = services_res.json()["data"]
        self.assertTrue(len(services) >= 1)
        target_service = services[0]

        # 2. Book service appointment
        book_res = self.client.post("/api/v1/services/book", json={
            "service_id": target_service["id"],
            "booking_date": "2026-10-25",
            "time_slot": "10:00 AM - 12:00 PM",
            "notes": "Main circuit breaker tripping periodically"
        }, headers=self.buyer_headers)
        
        self.assertEqual(book_res.status_code, 200)
        booking = book_res.json()["data"]
        self.assertEqual(booking["status"], "pending")
        self.assertEqual(booking["time_slot"], "10:00 AM - 12:00 PM")

        # 3. View my bookings
        my_bookings_res = self.client.get("/api/v1/services/my-bookings", headers=self.buyer_headers)
        self.assertEqual(my_bookings_res.status_code, 200)
        self.assertTrue(len(my_bookings_res.json()["data"]) >= 1)

if __name__ == "__main__":
    unittest.main()
