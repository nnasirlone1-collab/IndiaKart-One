# Project IndiaKart One 🇮🇳
**The Complete B2B + B2C + Wholesale + Manufacturing + Services Super-App**

### Taglines
* Primary: *"Everything India Makes, Sells, Buys & Needs."*
* Supporting: *"From Your Daily Needs to India's Biggest Businesses."*

---

## Overview
IndiaKart One is a production-grade, unified commerce platform designed specifically for the Indian economy. It combines retail e-commerce, nearby business and restaurant ordering, wholesale procurement with dynamic volume tiers, custom manufacturing RFQs, and on-demand local services into a single-identity architecture with role-based access control.

## Project Structure
```
indiakart_one/
├── app/
│   ├── config.py                 # System configuration & environment settings
│   ├── database.py               # SQLite connection pool with Haversine spherical math
│   ├── security.py               # PBKDF2 hashing, JWT tokens, Webhook signature verification
│   ├── models/
│   │   └── schema.sql            # 40+ normalized relational tables & indexes
│   ├── services/
│   │   ├── auth_service.py       # Authentication, profiles, addresses, super-admin bootstrap
│   │   ├── geo_service.py        # Proximity discovery, road vs straight-line distance
│   │   ├── product_service.py    # Wholesale tiers, variants, add-ons, price on demand
│   │   ├── cart_service.py       # Multi-seller cart & dynamic quantity tier pricing
│   │   ├── order_service.py      # Multi-seller splitting, stock reservation, idempotency
│   │   ├── payment_service.py    # UPI QR, intent, Razorpay webhook HMAC verification
│   │   ├── subscription_service.py # Business Pro plan & dynamic price adjustments
│   │   ├── rfq_service.py        # B2B RFQs, supplier quotes, order conversion
│   │   ├── service_marketplace.py# Services marketplace & appointment scheduling
│   │   ├── messaging_service.py  # Isolated participant messaging & notifications
│   │   └── admin_service.py      # Platform KPIs, seller KYC approvals & audit logs
│   ├── routes/                   # 56 RESTful versioned endpoints (/api/v1/...)
│   └── seed_data.py              # Realistic Indian commerce demonstration data
├── static/
│   ├── css/styles.css            # Indian commerce design system
│   ├── js/app.js                 # Complete client-side application logic
│   └── index.html                # Responsive mobile-first single-page app
├── tests/                        # 26 automated unit & user journey tests (100% passing)
├── docs/
│   ├── ARCHITECTURE.md           # Domain architecture & transaction lifecycle
│   ├── EXTERNAL_SERVICES_SETUP.md# Credentials, Indian DLT SMS & payment gateway guide
│   └── DEPLOYMENT.md             # Docker, systemd, Nginx, Android & iOS store setup
├── requirements.txt              # Production Python dependencies
└── run.sh                        # Single-command launch script
```

## Quick Start
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Seed database
python3 -m indiakart_one.app.seed_data

# 3. Launch server
./run.sh
```

- Web UI: http://localhost:8000/
- API Docs: http://localhost:8000/docs
- Health: http://localhost:8000/health
