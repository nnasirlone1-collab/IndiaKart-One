# IndiaKart One 🇮🇳 — External Services Integration & Credential Setup Guide

This document outlines all external service dependencies, integration interfaces, sandbox simulation behaviors, and the exact procedures required to obtain live production credentials and regulatory approvals in India.

---

## 1. Summary of External Services & Operational Status

| Service Domain | Primary Provider | Integration Status | Credentials / Approvals Required |
|---|---|---|---|
| **Payment Gateway & UPI** | Razorpay / Cashfree | Operational (with HMAC-SHA256 verification & simulation mode) | Live Merchant KYC, Razorpay Key ID, Key Secret, Webhook Secret |
| **Maps & Geolocation** | Google Maps Platform / OpenStreetMap | Operational (OpenStreetMap baseline + Google Maps abstraction) | Google Maps API Key (Geocoding, Places, Distance Matrix) |
| **Push Notifications** | Firebase Cloud Messaging (FCM) & Apple APNs | Architecture & Payload Handler Ready | Firebase Service Account Key JSON, Apple APNs Auth Key (.p8) |
| **Transactional SMS & OTP** | ValueFirst / Twilio / Gupshup | Simulation & Service Interface Ready | Indian TRAI DLT Registration, Sender ID, Approved SMS Templates |
| **Object Storage** | AWS S3 / Google Cloud Storage | Local/Static Storage Baseline Ready | S3 Bucket, Access Key, Secret Key, CloudFront Distribution |

---

## 2. Payment Gateway Setup (Razorpay / Cashfree)

### Current Implementation:
- Located in `indiakart_one/app/services/payment_service.py`.
- Generates standard NPCI UPI URI strings (`upi://pay?pa=...`) for QR code and intent flows.
- Verifies incoming webhook events using HMAC-SHA256 signature checks on `X-Razorpay-Signature`.
- Replay prevention records event IDs in `payment_webhook_events`.

### Production Setup Procedure:
1. **Merchant Onboarding:** Register on the [Razorpay Dashboard](https://dashboard.razorpay.com/) or Cashfree Payments.
2. **Business KYC Submission:** Submit Certificate of Incorporation, GSTIN, Company PAN, Board Resolution, and Bank Account Proof.
3. **API Key Generation:** Navigate to **Settings → API Keys** to generate `Key ID` and `Key Secret`.
4. **Webhook Configuration:**
   - URL: `https://api.indiakart.one/api/v1/payments/webhook`
   - Active Events: `payment.captured`, `payment.failed`, `order.paid`, `refund.processed`
   - Secret: Configure a cryptographically secure random string and assign it to `RAZORPAY_WEBHOOK_SECRET`.
5. **Environment Variables:**
   ```bash
   RAZORPAY_KEY_ID="rzp_live_your_actual_key_id"
   RAZORPAY_KEY_SECRET="your_actual_key_secret"
   RAZORPAY_WEBHOOK_SECRET="your_actual_webhook_secret"
   ```

---

## 3. Location and Mapping Provider (Google Maps Platform)

### Current Implementation:
- Located in `indiakart_one/app/services/geo_service.py`.
- Server-side Haversine mathematical distance calculation directly in SQLite / PostgreSQL queries.
- Calibrated 1.30x road network factor to distinguish straight-line spherical distance from actual road driving distance.

### Production Setup Procedure:
1. Create a Google Cloud Project on the [Google Cloud Console](https://console.cloud.google.com/).
2. Enable the following APIs:
   - **Maps JavaScript API** (Web interactive map rendering)
   - **Geocoding API** (Reverse geocoding from GPS coordinates)
   - **Places API (New)** (Autocomplete address search)
   - **Distance Matrix API** (Real-time driving duration calculation)
3. Generate an API Key, restrict it by HTTP referrers (e.g., `*.indiakart.one/*`) and IP addresses.
4. Set environment variable:
   ```bash
   MAP_PROVIDER="google_maps"
   GOOGLE_MAPS_API_KEY="AIzaSyYourActualGoogleMapsKey"
   ```

---

## 4. Indian Telecom TRAI DLT Registration for SMS & OTP

In accordance with Telecom Regulatory Authority of India (TRAI) mandate, all commercial SMS traffic in India must be routed through a registered Distributed Ledger Technology (DLT) platform (e.g., Jio, Airtel, Vodafone Idea, or BSNL DLT).

### Production Setup Procedure:
1. **Entity Registration:** Register as a **Principal Entity (Enterprise)** on any telecom operator's DLT portal (e.g., [Vilpower DLT](https://www.vilpower.in/) or [Jio DLT](https://trueconnect.jio.com/)).
2. **Header (Sender ID) Approval:** Apply for a 6-character alphabetic Sender ID (e.g., `IKTONE`).
3. **Template Approval:** Register explicit SMS templates with variable parameters `{#var#}`:
   - **OTP Template:** `Your IndiaKart One verification code is {#var#}. Valid for 10 minutes. Do not share with anyone.`
   - **Order Confirmation:** `Order {#var#} confirmed on IndiaKart One. Track status in your app.`
4. Map the approved DLT Entity ID and Template ID in your SMS gateway provider (Twilio, Gupshup, or Exotel).

---

## 5. Push Notifications (FCM & Apple APNs)

### Production Setup Procedure:
1. **Firebase Console:** Create a project on [Firebase](https://console.firebase.google.com/).
2. **Service Account:** Navigate to **Project Settings → Service Accounts**, click **Generate new private key** and save as `fcm_service_account.json`.
3. **Apple Push Notification Service (APNs):**
   - In Apple Developer Portal, navigate to **Certificates, Identifiers & Profiles → Keys**.
   - Create an APNs key, download the `.p8` certificate.
   - Upload the `.p8` key, Key ID, and Apple Team ID to the Firebase Cloud Messaging settings.
