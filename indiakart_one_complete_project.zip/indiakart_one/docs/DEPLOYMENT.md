# IndiaKart One 🇮🇳 — Production Deployment & Release Guide

## 1. Quick Start / Local Execution

To start the platform immediately in development mode:

```bash
# 1. Initialize environment variables
export APP_ENV="development"
export DATABASE_PATH="/tmp/indiakart_one.db"
export JWT_SECRET_KEY="indiakart_super_secret_jwt_key_2026_production_grade"

# 2. Seed database with demonstration data (users, businesses, products, tiers)
python3 -m indiakart_one.app.seed_data

# 3. Run server via Uvicorn
python3 -m uvicorn indiakart_one.app.main:app --host 0.0.0.0 --port 8000 --reload
```

Once running:
- **Web App / Buyer & Seller UI:** Open `http://localhost:8000/` in any browser.
- **Interactive OpenAPI / Swagger Documentation:** Visit `http://localhost:8000/docs`.
- **System Health Endpoint:** `http://localhost:8000/health`.

---

## 2. Default Demonstration Credentials

| Role | Mobile Number / Identifier | Password | Associated Entity |
|---|---|---|---|
| **Super Administrator** | `9876543210` / `owner@indiakart.one` | `Admin#IndiaKart2026` | Platform Owner Console |
| **Buyer User** | `9123456780` | `Password#123` | Rahul Sharma (Bangalore) |
| **Vegetable Retailer** | `9234567890` | `Password#123` | Bharat Agro Fresh Produce |
| **Gourmet Restaurant** | `9456789012` | `Password#123` | Annapurna Gourmet Kitchen |
| **Manufacturer (B2B)** | `9345678901` | `Password#123` | Tata Alloy Industrial Hardware |
| **Service Provider** | `9567890123` | `Password#123` | Apex Smart Home & Electrical |

---

## 3. Production Architecture on Cloud Infrastructure

### Recommended Production Stack:
- **Compute:** AWS ECS (Fargate) or GCP Cloud Run / Kubernetes (EKS/GKE).
- **Primary Database:** AWS RDS PostgreSQL 15+ with PostGIS extension enabled.
- **Cache & Queue:** AWS ElastiCache for Redis (for WebSocket connections and background jobs).
- **Object Storage:** AWS S3 with CloudFront CDN for fast image delivery across India.

### Systemd Service Configuration (`/etc/systemd/system/indiakart.service`):
```ini
[Unit]
Description=IndiaKart One Commerce Super-App API Service
After=network.target

[Service]
User=spark
WorkingDirectory=/opt/indiakart_one
EnvironmentFile=/etc/indiakart.env
ExecStart=/usr/bin/python3 -m uvicorn indiakart_one.app.main:app --host 127.0.0.1 --port 8000 --workers 4
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### Nginx Reverse Proxy with SSL:
```nginx
server {
    listen 80;
    server_name api.indiakart.one app.indiakart.one;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.indiakart.one app.indiakart.one;

    ssl_certificate /etc/letsencrypt/live/indiakart.one/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/indiakart.one/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static/ {
        alias /opt/indiakart_one/static/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
}
```

---

## 4. Mobile Application Release Preparation

### Android (Google Play Store):
1. **Target SDK:** Android 14 (API level 34+).
2. **Permissions:**
   - `ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION` (geographical discovery)
   - `POST_NOTIFICATIONS` (order alerts and quotation updates)
3. **App Bundle Signing:** Generate release keystore and compile Android App Bundle (`.aab`):
   ```bash
   keytool -genkey -v -keystore indiakart-release.keystore -alias indiakart -keyalg RSA -keysize 2048 -validity 10000
   ```
4. **Google Play Console:** Complete Indian Developer Identity verification, Data Safety section, and Grievance Officer disclosure as mandated by the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules.

### iOS (Apple App Store):
1. **Bundle Identifier:** `one.indiakart.app`
2. **Capabilities:** Push Notifications, Background Fetch, Maps Location Services.
3. **App Store Review Guidelines:**
   - 3.1.1 In-App Purchase: Physical goods and B2B wholesale transactions are exempt from Apple 30% IAP fees (use Indian payment gateways like Razorpay/Cashfree).
   - Sign in with Apple integration when third-party social logins are provided.
