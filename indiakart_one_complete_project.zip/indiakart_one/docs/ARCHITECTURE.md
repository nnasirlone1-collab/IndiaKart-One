# IndiaKart One 🇮🇳 — System Architecture & Technical Specification

## 1. Executive Overview
**IndiaKart One** is an unified, production-grade commerce super-app tailored for the Indian economic landscape, integrating B2C daily essentials (groceries, vegetables, food delivery), B2B wholesale procurement, custom manufacturing requests (RFQ), and local professional services into a cohesive, single-identity platform.

### Core Brand Principles:
- **Primary Tagline:** *"Everything India Makes, Sells, Buys & Needs."*
- **Supporting Tagline:** *"From Your Daily Needs to India’s Biggest Businesses."*
- **Palette:** Deep Navy (`#142B4A`), IndiaKart Blue (`#1769E0`), Saffron Accent (`#FF9933`), Clean White (`#FFFFFF`), Soft Background (`#F5F7FB`).
- **Currency & Formatting:** Indian Rupee (₹) with Lakhs (1,00,000) and Crores (1,00,00,000) notation and integer minor unit storage (paise).

---

## 2. Architectural Pillars

### 2.1 Single Identity System with Role-Based Access Control (RBAC)
A single authenticated user profile can hold multiple concurrent roles (`buyer`, `seller`, `manufacturer`, `distributor`, `wholesaler`, `retailer`, `restaurant`, `service_provider`, `admin`, `super_admin`) without fragmenting accounts or duplicating credentials:
- **Primary Mode Switch:** Highly visible `[ BUY ] [ SELL ]` switch in the application header.
- **Role Isolation:** Private buyer data (saved addresses, personal phone numbers) remains shielded from suppliers by default.
- **Fine-Grained Permissions:** Fast path execution guards verify permissions at both API gateway and service levels.

### 2.2 Modular Domain Decomposition
```
indiakart_one/
├── app/
│   ├── config.py             # System configuration, credential injection & defaults
│   ├── database.py           # SQLite connection pool with Haversine spherical math function
│   ├── security.py           # PBKDF2-HMAC-SHA256 hashing, JWT engine, Webhook verification
│   ├── models/
│   │   └── schema.sql        # 40+ normalized relational tables with foreign keys and indexes
│   ├── services/
│   │   ├── auth_service.py         # User registration, login, bootstrap super-admin
│   │   ├── geo_service.py          # Geospatial search, straight-line vs road distance
│   │   ├── product_service.py      # Wholesale tiers, variants, add-ons, price on demand
│   │   ├── cart_service.py         # Multi-seller shopping cart & dynamic pricing
│   │   ├── order_service.py        # Multi-seller order generation, stock reservation
│   │   ├── payment_service.py      # UPI QR, intent, Razorpay webhook HMAC verification
│   │   ├── subscription_service.py # IndiaKart Business Pro plan & dynamic pricing
│   │   ├── rfq_service.py          # B2B RFQ, multi-tier quotes, conversion to order
│   │   ├── service_marketplace.py  # Service listings & appointment bookings
│   │   ├── messaging_service.py    # Participant-isolated secure messaging
│   │   └── admin_service.py        # Super-admin metrics, KYC review & audit trail
│   ├── routes/               # 56 RESTful versioned endpoints (/api/v1/...)
│   └── seed_data.py          # High-fidelity realistic Indian commerce demonstration seed
├── static/                   # Responsive Mobile & Desktop Web App UI
└── tests/                    # 26 automated unit and end-to-end user journey tests
```

---

## 3. Data Flow & Transaction Lifecycle

### 3.1 Multi-Seller Shopping Cart to Order Decomposition
When a customer adds items from different vendors (e.g., Organic Tomatoes from *Bharat Agro Fresh* and Shahi Paneer from *Annapurna Gourmet Kitchen*):
1. **Dynamic Wholesale Tier Evaluation:** As item quantity increases, the engine checks `wholesale_price_tiers` matching the range `[min_quantity, max_quantity]` and applies the tiered unit price in real-time.
2. **Multi-Seller Order Splitting:** On checkout, the transaction engine validates stock levels across all items atomically, reserves inventory, and generates distinct `orders` records for each seller with separate delivery fees, tax breakdowns, and settlement allocations.
3. **Idempotency Protection:** The checkout endpoint accepts an `Idempotency-Key` header, caching order identifiers to prevent duplicate billing during poor network conditions or repeated taps.

### 3.2 Payment Architecture & UPI Integration
- **NPCI-Compliant UPI URI Scheme:** Generates compliant URIs (`upi://pay?pa=...&pn=...&am=...&cu=INR`) for instant scanning via BHIM, Google Pay, PhonePe, Paytm, and CRED.
- **HMAC-SHA256 Webhook Verification:** External payment callbacks from Razorpay or Cashfree are cryptographically validated against `X-Razorpay-Signature` before transitioning order payment states.
- **Replay Protection:** Webhook event payloads are recorded in `payment_webhook_events` to ensure idempotent processing.

### 3.3 Dynamic Subscription Management
- **IndiaKart Business Pro Default:** Seeded at ₹1,499.00/month (149,900 paise) + 18% GST.
- **Zero-Downtime Price Updates:** Super-Administrators can alter monthly and annual rates via `/api/v1/admin/subscriptions/plans/{id}/price`. Every modification is committed to `admin_audit_logs` with before-and-after snapshots.

### 3.4 B2B RFQ & Multi-Tier Quotation Workflow
- **Buying Requirement (RFQ):** Buyers specify required quantity, unit of measure, target pricing, specifications, and delivery pincode.
- **Supplier Matching:** Verified manufacturers and wholesalers in the relevant category receive immediate alerts.
- **Quotation Revisions:** Suppliers submit structured quotes with lead times, payment milestones, and shipping charges. When suppliers revise their quotes, previous revisions are preserved.
- **Order Conversion:** Buyer acceptance instantly materializes a confirmed wholesale order.
