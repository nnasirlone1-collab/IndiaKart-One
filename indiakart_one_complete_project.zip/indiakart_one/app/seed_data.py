import uuid
from indiakart_one.app.database import db
from indiakart_one.app.security import hash_password
from indiakart_one.app.config import settings
from indiakart_one.app.services.auth_service import AuthService
from indiakart_one.app.services.subscription_service import SubscriptionService
from indiakart_one.app.services.product_service import ProductService

def seed_database():
    """Populates initial seed data for IndiaKart One development and testing."""
    print("[SEED] Starting database seeding...")
    
    # 1. Initialize schema
    db.init_db()
    
    # 2. Bootstrap Super Admin
    AuthService.bootstrap_super_admin()
    
    # 3. Ensure Default Subscription Plan (IndiaKart Business Pro ₹1,499.00)
    SubscriptionService.ensure_default_plan()
    
    # 4. Insert Default Categories
    categories = [
        ("cat-daily-essentials", "Daily Essentials", "daily-essentials", "shopping_cart", None, 0, 1),
        ("cat-groceries", "Groceries", "groceries", "grain", "cat-daily-essentials", 0, 2),
        ("cat-fruits-veg", "Fruits & Vegetables", "fruits-vegetables", "nutrition", "cat-daily-essentials", 0, 3),
        ("cat-restaurants", "Restaurants & Food", "restaurants-food", "restaurant", None, 0, 4),
        ("cat-fashion", "Fashion & Clothing", "fashion-clothing", "checkroom", None, 0, 5),
        ("cat-electronics", "Electronics & Gadgets", "electronics", "devices", None, 0, 6),
        ("cat-home-kitchen", "Home & Kitchen", "home-kitchen", "kitchen", None, 0, 7),
        ("cat-building-materials", "Building Materials", "building-materials", "foundation", None, 1, 8),
        ("cat-agriculture", "Agriculture & Farming", "agriculture-farming", "agriculture", None, 1, 9),
        ("cat-industrial-supplies", "Industrial Supplies", "industrial-supplies", "build", None, 1, 10),
        ("cat-machinery", "Machinery & Equipment", "machinery-equipment", "precision_manufacturing", None, 1, 11),
        ("cat-packaging", "Packaging Materials", "packaging-materials", "inventory_2", None, 1, 12),
        ("cat-services", "Professional Services", "professional-services", "handyman", None, 0, 13),
    ]
    
    for cid, name, slug, icon, pid, is_b2b, sort_order in categories:
        db.execute(
            """INSERT OR IGNORE INTO categories (id, name, slug, icon_name, parent_id, is_b2b, sort_order)
               VALUES (:id, :name, :slug, :icon, :pid, :b2b, :sort)""",
            {"id": cid, "name": name, "slug": slug, "icon": icon, "pid": pid, "b2b": is_b2b, "sort": sort_order}
        )

    # 5. Insert Initial Coupons
    coupons = [
        ("coup-ik50", "INDIAKART50", "Flat ₹50 off on orders above ₹299", "fixed", 5000, 29900, 5000),
        ("coup-first", "FIRSTORDER", "15% discount up to ₹150 for first time buyers", "percentage", 15.0, 19900, 15000),
        ("coup-bulk", "WHOLESALE10", "10% discount on wholesale orders above ₹5,000", "percentage", 10.0, 500000, 500000)
    ]
    for cid, code, desc, dtype, val, min_v, max_d in coupons:
        db.execute(
            """INSERT OR IGNORE INTO coupons (id, code, description, discount_type, discount_value, min_order_value_minor, max_discount_minor)
               VALUES (:id, :code, :desc, :dtype, :val, :min_v, :max_d)""",
            {"id": cid, "code": code, "desc": desc, "dtype": dtype, "val": val, "min_v": min_v, "max_d": max_d}
        )

    # 6. Seed Test Users
    test_users = [
        ("user-buyer-1", "9123456780", "rahul.sharma@example.com", "Rahul Sharma", ["buyer"]),
        ("user-seller-1", "9234567890", "vikram.singh@example.com", "Vikram Singh", ["buyer", "seller"]),
        ("user-mfr-1", "9345678901", "ananya.desai@example.com", "Ananya Desai", ["buyer", "seller", "manufacturer"]),
        ("user-rest-1", "9456789012", "karan.malhotra@example.com", "Chef Karan Malhotra", ["buyer", "seller", "restaurant"]),
        ("user-serv-1", "9567890123", "suresh.kumar@example.com", "Suresh Kumar", ["buyer", "seller", "service_provider"]),
    ]
    
    for uid, mobile, email, name, roles in test_users:
        if not db.query_one("SELECT id FROM users WHERE id = :id", {"id": uid}):
            pwd_hash, salt = hash_password("Password#123")
            db.execute(
                """INSERT INTO users (id, mobile_number, email, full_name, password_hash, salt, is_verified)
                   VALUES (:id, :mobile, :email, :name, :hash, :salt, 1)""",
                {"id": uid, "mobile": mobile, "email": email, "name": name, "hash": pwd_hash, "salt": salt}
            )
            for r in roles:
                db.execute(
                    "INSERT OR IGNORE INTO user_roles (id, user_id, role) VALUES (:id, :uid, :r)",
                    {"id": str(uuid.uuid4()), "uid": uid, "r": r}
                )

    # 7. Add Seed Delivery Address for Buyer
    if not db.query_one("SELECT id FROM addresses WHERE user_id = 'user-buyer-1'"):
        AuthService.add_address(
            user_id="user-buyer-1",
            label="Home",
            recipient="Rahul Sharma",
            phone="9123456780",
            line1="Flat 402, Shanti Vihar Apartments, Koramangala 4th Block",
            city="Bengaluru",
            state="Karnataka",
            pincode="560034",
            lat=12.9352,
            lon=77.6245,
            is_default=True
        )

    # 8. Seed Businesses
    businesses = [
        (
            "biz-agro-fresh", "user-seller-1", "Bharat Agro Fresh Produce Pvt Ltd", "Bharat Agro Fresh",
            "retailer", "cat-fruits-veg", "Direct farm fresh fruits and organic vegetables delivered within 2 hours.",
            "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400",
            "contact@bharatfresh.in", "9234567890", "29ABCDE1234F1Z5",
            "Shop 12, APMC Yard, Yeshwanthpur", "Bengaluru", "Karnataka", "560022",
            12.9716, 77.5946, 20.0, "approved", 4.8, 142
        ),
        (
            "biz-annapurna", "user-rest-1", "Annapurna Gourmet Kitchen LLP", "Annapurna Gourmet Kitchen",
            "restaurant", "cat-restaurants", "Authentic North Indian, Mughlai curries, biryanis and tandoori breads.",
            "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400",
            "orders@annapurna.in", "9456789012", "29AABCA9876C1Z2",
            "84, 100 Feet Road, Indiranagar", "Bengaluru", "Karnataka", "560038",
            12.9750, 77.6000, 12.0, "approved", 4.6, 389
        ),
        (
            "biz-tata-steel", "user-mfr-1", "Tata Alloy Industrial Hardware Works", "Tata Alloy Industrial",
            "manufacturer", "cat-industrial-supplies", "High-precision alloy fasteners, structural bolts, and CNC machined parts.",
            "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=400",
            "sales@tataalloy.com", "9345678901", "29AAACT0001A1Z9",
            "Plot 45, Peenya Industrial Area 2nd Stage", "Bengaluru", "Karnataka", "560058",
            12.9100, 77.5200, 100.0, "approved", 4.9, 95
        ),
        (
            "biz-surya-textiles", "user-seller-1", "Surya Wholesale Garments & Textiles", "Surya Textiles Wholesale",
            "wholesaler", "cat-fashion", "Direct mill wholesale cotton fabrics, readymade shirts, and formal trousers.",
            "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400",
            "surya@suryatextiles.in", "9234567890", "29BBDCS5544B1Z4",
            "Commercial Street, Tasker Town", "Bengaluru", "Karnataka", "560001",
            12.9600, 77.5800, 60.0, "approved", 4.5, 62
        ),
        (
            "biz-apex-services", "user-serv-1", "Apex Smart Home & Electrical Solutions", "Apex Smart Electricals",
            "service_provider", "cat-services", "Licensed master electricians, home wiring, inverter installations, and AC repairs.",
            "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400",
            "support@apexservices.in", "9567890123", "29CCDPQ7788D1Z1",
            "Brigade Road, Ashok Nagar", "Bengaluru", "Karnataka", "560025",
            12.9800, 77.6100, 25.0, "approved", 4.7, 78
        ),
        (
            "biz-pending-kyc", "user-mfr-1", "Shree Sai Precision Engineering", "Shree Sai Precision",
            "manufacturer", "cat-machinery", "Heavy industrial gears, presses and lathe fabrications.",
            "https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?w=400",
            "shreesai@example.com", "9345678901", "29EEFFG1122H1Z0",
            "Bommasandra Industrial Area", "Bengaluru", "Karnataka", "560099",
            12.8200, 77.6800, 50.0, "pending", 0.0, 0
        )
    ]

    for bid, oid, legal, disp, btype, cat, desc, logo, email, phone, gstin, addr, city, state, pin, lat, lon, srad, vstat, rat, rcnt in businesses:
        if not db.query_one("SELECT id FROM businesses WHERE id = :id", {"id": bid}):
            db.execute(
                """INSERT INTO businesses (
                    id, owner_id, legal_name, display_name, business_type, category_id,
                    description, logo_url, email, phone, gstin, address_line1,
                    city, state, pincode, latitude, longitude, service_radius_km,
                    verification_status, rating, review_count, subscription_active
                ) VALUES (
                    :id, :oid, :legal, :disp, :btype, :cat,
                    :desc, :logo, :email, :phone, :gstin, :addr,
                    :city, :state, :pin, :lat, :lon, :srad,
                    :vstat, :rat, :rcnt, 1
                )""",
                {
                    "id": bid, "oid": oid, "legal": legal, "disp": disp, "btype": btype, "cat": cat,
                    "desc": desc, "logo": logo, "email": email, "phone": phone, "gstin": gstin, "addr": addr,
                    "city": city, "state": state, "pin": pin, "lat": lat, "lon": lon, "srad": srad,
                    "vstat": vstat, "rat": rat, "rcnt": rcnt
                }
            )
            # Add business hours (Open 08:00 to 22:00)
            for dow in range(7):
                db.execute(
                    "INSERT OR IGNORE INTO business_hours (id, business_id, day_of_week, open_time, close_time) VALUES (:id, :bid, :dow, '08:00', '22:00')",
                    {"id": str(uuid.uuid4()), "bid": bid, "dow": dow}
                )

    # 9. Seed Products with Variants, Addons, and Wholesale Tiers
    # Product A: Farm Fresh Tomatoes (Vegetables)
    if not db.query_one("SELECT id FROM products WHERE id = 'prod-tomatoes'"):
        ProductService.create_product(
            product_id="prod-tomatoes",
            business_id="biz-agro-fresh",
            category_id="cat-fruits-veg",
            name="Farm Fresh Organic Tomatoes",
            retail_price_minor=4000, # ₹40.00 / kg
            pricing_mode="fixed",
            short_description="Vine-ripened organic red tomatoes grown without synthetic pesticides.",
            description="Crisp, juicy tomatoes hand-picked at dawn. Perfect for daily Indian curries, salads, and gravies.",
            unit_of_measure="kg",
            stock_quantity=500,
            primary_image_url="https://images.unsplash.com/photo-1546470427-e26264be0b11?w=400",
            is_veg=1,
            variants=[
                {"variant_name": "500g Pack", "additional_price_minor": -1800, "retail_price_minor": 2200, "stock_quantity": 200},
                {"variant_name": "1kg Pack", "additional_price_minor": 0, "retail_price_minor": 4000, "stock_quantity": 200},
                {"variant_name": "5kg Carton", "additional_price_minor": 14000, "retail_price_minor": 18000, "stock_quantity": 100}
            ],
            wholesale_tiers=[
                {"min_quantity": 10, "max_quantity": 49, "unit_price_minor": 3200, "lead_time_days": 1},
                {"min_quantity": 50, "max_quantity": None, "unit_price_minor": 2500, "lead_time_days": 1}
            ]
        )

    # Product B: Farm Fresh Potatoes
    if not db.query_one("SELECT id FROM products WHERE id = 'prod-potatoes'"):
        ProductService.create_product(
            product_id="prod-potatoes",
            business_id="biz-agro-fresh",
            category_id="cat-fruits-veg",
            name="Premium Jyoti Potatoes",
            retail_price_minor=3000, # ₹30.00 / kg
            unit_of_measure="kg",
            stock_quantity=800,
            primary_image_url="https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400",
            is_veg=1,
            wholesale_tiers=[
                {"min_quantity": 25, "max_quantity": 99, "unit_price_minor": 2400, "lead_time_days": 1},
                {"min_quantity": 100, "max_quantity": None, "unit_price_minor": 1900, "lead_time_days": 2}
            ]
        )

    # Product C: Paneer Butter Masala (Restaurant)
    if not db.query_one("SELECT id FROM products WHERE id = 'prod-paneer-butter'"):
        ProductService.create_product(
            product_id="prod-paneer-butter",
            business_id="biz-annapurna",
            category_id="cat-restaurants",
            name="Shahi Paneer Butter Masala",
            retail_price_minor=24000, # ₹240.00
            pricing_mode="fixed",
            short_description="Rich cashew and tomato gravy infused with fresh cottage cheese and aromatic kasuri methi.",
            unit_of_measure="portion",
            stock_quantity=100,
            primary_image_url="https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400",
            is_veg=1,
            addon_groups=[
                {
                    "title": "Portion & Bread Add-ons",
                    "is_required": False,
                    "min_selections": 0,
                    "max_selections": 3,
                    "addons": [
                        {"name": "Extra Amul Butter Cube", "price_minor": 2000},
                        {"name": "Garlic Butter Naan (2 pcs)", "price_minor": 6000},
                        {"name": "Jeera Basmati Rice", "price_minor": 8000}
                    ]
                }
            ]
        )

    # Product D: Industrial Alloy Bolts (B2B Wholesale / Manufacturer)
    if not db.query_one("SELECT id FROM products WHERE id = 'prod-bolts-m12'"):
        ProductService.create_product(
            product_id="prod-bolts-m12",
            business_id="biz-tata-steel",
            category_id="cat-industrial-supplies",
            name="Grade 8.8 High-Tensile Hex Bolts M12",
            retail_price_minor=1500, # ₹15.00 per bolt
            pricing_mode="fixed_and_rfq",
            short_description="ISO 4014 compliant zinc-plated high-tensile structural fasteners.",
            unit_of_measure="piece",
            min_order_quantity=10,
            stock_quantity=25000,
            primary_image_url="https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=400",
            wholesale_tiers=[
                {"min_quantity": 50, "max_quantity": 499, "unit_price_minor": 1200, "lead_time_days": 2},
                {"min_quantity": 500, "max_quantity": 1999, "unit_price_minor": 950, "lead_time_days": 3},
                {"min_quantity": 2000, "max_quantity": None, "unit_price_minor": 750, "lead_time_days": 5}
            ]
        )

    # Product E: Heavy Duty CNC Milling Machine (Price on Demand / RFQ Only)
    if not db.query_one("SELECT id FROM products WHERE id = 'prod-cnc-milling'"):
        ProductService.create_product(
            product_id="prod-cnc-milling",
            business_id="biz-tata-steel",
            category_id="cat-machinery",
            name="5-Axis Industrial CNC Milling Centre 12000 RPM",
            retail_price_minor=0,
            pricing_mode="price_on_demand",
            short_description="Heavy duty 5-axis vertical machining center for aerospace and automotive tool manufacturing.",
            unit_of_measure="unit",
            stock_quantity=5,
            primary_image_url="https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400"
        )

    # 10. Seed Service Listings
    services = [
        (
            "serv-electrical-inspect", "biz-apex-services", "Full Home Electrical Safety Audit & Wiring Inspection",
            "Certified licensed electricians perform complete load calculation, earthing inspection, and circuit breaker tests.",
            "Electrical", "fixed", 49900, 90, 20.0
        ),
        (
            "serv-ac-service", "biz-apex-services", "Split & Window AC Deep Jet Cleaning & Gas Check",
            "Comprehensive anti-bacterial jet wash, filter cleaning, cooling coil inspection, and gas pressure diagnostics.",
            "Appliances", "fixed", 79900, 60, 20.0
        )
    ]
    for sid, bid, sname, desc, scat, pmodel, price, dur, rad in services:
        if not db.query_one("SELECT id FROM service_listings WHERE id = :id", {"id": sid}):
            db.execute(
                """INSERT INTO service_listings (id, business_id, service_name, description, service_category, pricing_model, base_price_minor, duration_minutes, coverage_radius_km)
                   VALUES (:id, :bid, :sname, :desc, :scat, :pmodel, :price, :dur, :rad)""",
                {"id": sid, "bid": bid, "sname": sname, "desc": desc, "scat": scat, "pmodel": pmodel, "price": price, "dur": dur, "rad": rad}
            )

    print("[SEED] Database seeding completed successfully!")

if __name__ == "__main__":
    # Remove existing tmp database if clean start needed
    import os
    if os.path.exists("/tmp/indiakart_one.db"):
        os.remove("/tmp/indiakart_one.db")
    seed_database()
