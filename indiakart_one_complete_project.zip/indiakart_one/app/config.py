import os
from pydantic import BaseModel

class Settings(BaseModel):
    APP_NAME: str = "IndiaKart One"
    APP_ENV: str = os.getenv("APP_ENV", "development")
    DATABASE_PATH: str = os.getenv("DATABASE_PATH", "/tmp/indiakart_one.db")
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "indiakart_super_secret_jwt_key_2026_production_grade")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 7 days
    
    # Super-Admin initial bootstrap credentials (configurable via env)
    BOOTSTRAP_ADMIN_MOBILE: str = os.getenv("BOOTSTRAP_ADMIN_MOBILE", "9876543210")
    BOOTSTRAP_ADMIN_EMAIL: str = os.getenv("BOOTSTRAP_ADMIN_EMAIL", "owner@indiakart.one")
    BOOTSTRAP_ADMIN_PASSWORD: str = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "Admin#IndiaKart2026")
    BOOTSTRAP_ADMIN_NAME: str = os.getenv("BOOTSTRAP_ADMIN_NAME", "Platform Super Administrator")
    
    # Payment Gateways (Razorpay / Cashfree)
    RAZORPAY_KEY_ID: str = os.getenv("RAZORPAY_KEY_ID", "rzp_test_placeholder_key_id")
    RAZORPAY_KEY_SECRET: str = os.getenv("RAZORPAY_KEY_SECRET", "rzp_test_placeholder_secret_key")
    RAZORPAY_WEBHOOK_SECRET: str = os.getenv("RAZORPAY_WEBHOOK_SECRET", "rzp_webhook_secret_verification_token")
    
    # Map & Geolocation
    MAP_PROVIDER: str = os.getenv("MAP_PROVIDER", "openstreetmap") # 'google_maps', 'mapbox', 'openstreetmap'
    DEFAULT_SERVICE_RADIUS_KM: float = 15.0
    
    # Business Pro Subscription Default
    DEFAULT_SUBSCRIPTION_MONTHLY_PRICE_PAISE: int = 149900 # ₹1,499.00
    DEFAULT_COMMISSION_PERCENT: float = 5.0 # 5% platform fee

settings = Settings()
