import hashlib
import hmac
import secrets
import json
import base64
import time
from typing import Dict, Any, Optional, List
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from indiakart_one.app.config import settings

security_bearer = HTTPBearer(auto_error=False)

def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """Hashes a password using PBKDF2-HMAC-SHA256 with 100,000 iterations."""
    if not salt:
        salt = secrets.token_hex(16)
    key = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    )
    return key.hex(), salt

def verify_password(plain_password: str, stored_hash: str, salt: str) -> bool:
    """Verifies a plain password against the stored hash and salt."""
    computed_hash, _ = hash_password(plain_password, salt)
    return hmac.compare_digest(computed_hash, stored_hash)

def _b64_url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode('utf-8').rstrip('=')

def _b64_url_decode(data_str: str) -> bytes:
    padding = '=' * (4 - (len(data_str) % 4))
    return base64.urlsafe_b64decode(data_str + padding)

def create_access_token(payload: Dict[str, Any], expires_in_seconds: int = None) -> str:
    """Creates an HMAC-SHA256 signed JSON Web Token (JWT)."""
    if expires_in_seconds is None:
        expires_in_seconds = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    
    header = {"alg": "HS256", "typ": "JWT"}
    payload_copy = payload.copy()
    payload_copy["exp"] = int(time.time()) + expires_in_seconds
    payload_copy["iat"] = int(time.time())
    
    header_bytes = json.dumps(header, separators=(',', ':')).encode('utf-8')
    payload_bytes = json.dumps(payload_copy, separators=(',', ':')).encode('utf-8')
    
    encoded_header = _b64_url_encode(header_bytes)
    encoded_payload = _b64_url_encode(payload_bytes)
    
    signing_input = f"{encoded_header}.{encoded_payload}".encode('utf-8')
    signature = hmac.new(
        settings.JWT_SECRET_KEY.encode('utf-8'),
        signing_input,
        hashlib.sha256
    ).digest()
    
    encoded_signature = _b64_url_encode(signature)
    return f"{encoded_header}.{encoded_payload}.{encoded_signature}"

def decode_access_token(token: str) -> Optional[Dict[str, Any]]:
    """Decodes and cryptographically verifies an HMAC-SHA256 signed JWT."""
    try:
        parts = token.split('.')
        if len(parts) != 3:
            return None
        
        encoded_header, encoded_payload, encoded_signature = parts
        signing_input = f"{encoded_header}.{encoded_payload}".encode('utf-8')
        
        expected_sig = hmac.new(
            settings.JWT_SECRET_KEY.encode('utf-8'),
            signing_input,
            hashlib.sha256
        ).digest()
        
        actual_sig = _b64_url_decode(encoded_signature)
        if not hmac.compare_digest(expected_sig, actual_sig):
            return None
        
        payload_bytes = _b64_url_decode(encoded_payload)
        payload = json.loads(payload_bytes.decode('utf-8'))
        
        # Check expiration
        if payload.get("exp") and time.time() > payload["exp"]:
            return None
            
        return payload
    except Exception:
        return None

def verify_webhook_signature(payload_body: bytes, signature_header: str, secret: str) -> bool:
    """Verifies HMAC-SHA256 signature for Razorpay / Cashfree webhooks."""
    try:
        expected_signature = hmac.new(
            secret.encode('utf-8'),
            payload_body,
            hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected_signature, signature_header)
    except Exception:
        return False

def get_current_user(credentials: Optional[HTTPAuthorizationCredentials] = Security(security_bearer)) -> Dict[str, Any]:
    """Dependency that extracts and validates the authenticated user from the Bearer token."""
    from indiakart_one.app.database import db
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication credentials required")
    
    payload = decode_access_token(credentials.credentials)
    if not payload or not payload.get("sub"):
        raise HTTPException(status_code=401, detail="Invalid or expired authentication token")
    
    user_id = payload["sub"]
    user = db.query_one("SELECT * FROM users WHERE id = :user_id AND is_active = 1", {"user_id": user_id})
    if not user:
        raise HTTPException(status_code=401, detail="User account not found or deactivated")
    
    # Attach roles
    roles = db.query("SELECT role FROM user_roles WHERE user_id = :user_id", {"user_id": user_id})
    user["roles"] = [r["role"] for r in roles]
    return user

def require_roles(required_roles: List[str]):
    """Role-based authorization guard."""
    def role_checker(current_user: Dict[str, Any] = Depends(get_current_user)):
        user_roles = current_user.get("roles", [])
        if "super_admin" in user_roles:
            return current_user
        for r in required_roles:
            if r in user_roles:
                return current_user
        raise HTTPException(
            status_code=403, 
            detail=f"Access denied. Requires one of roles: {', '.join(required_roles)}"
        )
    return role_checker
