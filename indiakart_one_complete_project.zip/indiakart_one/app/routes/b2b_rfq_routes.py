from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.rfq_service import RFQService
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(tags=["B2B Marketplace & RFQ"])

class CreateRFQRequest(BaseModel):
    product_name: str
    required_quantity: int
    unit_of_measure: str
    delivery_pincode: str
    delivery_city: str
    category_id: Optional[str] = None
    specifications: Optional[str] = None
    target_price_minor: Optional[int] = None
    required_date: Optional[str] = None
    customization_details: Optional[str] = None

class SubmitQuotationRequest(BaseModel):
    unit_price_minor: int
    tax_rate_percent: float = 18.0
    packaging_costs_minor: int = 0
    shipping_costs_minor: int = 0
    production_lead_time_days: int = 7
    payment_terms: str = "30% Advance, 70% Before Dispatch"
    validity_days: int = 14
    notes: Optional[str] = None

@router.post("/api/v1/rfq")
def create_rfq(req: CreateRFQRequest, user: Dict[str, Any] = Depends(get_current_user)):
    rfq = RFQService.create_rfq(
        buyer_id=user["id"],
        product_name=req.product_name,
        required_quantity=req.required_quantity,
        unit_of_measure=req.unit_of_measure,
        delivery_pincode=req.delivery_pincode,
        delivery_city=req.delivery_city,
        category_id=req.category_id,
        specifications=req.specifications,
        target_price_minor=req.target_price_minor,
        required_date=req.required_date,
        customization_details=req.customization_details
    )
    return {"status": "success", "message": "Buying requirement posted to verified suppliers.", "data": rfq}

@router.get("/api/v1/rfq")
def list_rfqs(
    role_view: str = Query("all", description="all, buyer, or supplier"),
    user: Dict[str, Any] = Depends(get_current_user)
):
    if role_view == "buyer":
        sql = "SELECT * FROM buying_requirements WHERE buyer_id = :uid ORDER BY created_at DESC"
        params = {"uid": user["id"]}
    else:
        # Suppliers can view open RFQs
        sql = "SELECT * FROM buying_requirements WHERE status IN ('open', 'quotes_received') ORDER BY created_at DESC"
        params = {}

    rfqs = db.query(sql, params)
    for r in rfqs:
        quotes_count = db.query_one("SELECT COUNT(*) as c FROM quotations WHERE rfq_id = :rid", {"rid": r["id"]})["c"]
        r["quotations_received_count"] = quotes_count
    return {"status": "success", "data": rfqs}

@router.get("/api/v1/rfq/{rfq_id}")
def get_rfq(rfq_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    rfq = db.query_one("SELECT * FROM buying_requirements WHERE id = :id", {"id": rfq_id})
    if not rfq:
        raise HTTPException(status_code=404, detail="RFQ not found")
    return {"status": "success", "data": rfq}

@router.get("/api/v1/rfq/{rfq_id}/quotations")
def get_rfq_quotations(rfq_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    rfq = db.query_one("SELECT * FROM buying_requirements WHERE id = :id", {"id": rfq_id})
    if not rfq:
        raise HTTPException(status_code=404, detail="RFQ not found")

    quotes = db.query(
        """SELECT q.*, b.display_name AS supplier_name, b.business_type, b.rating AS supplier_rating
           FROM quotations q
           JOIN businesses b ON q.supplier_id = b.id
           WHERE q.rfq_id = :rid
           ORDER BY q.created_at DESC""",
        {"rid": rfq_id}
    )
    return {"status": "success", "data": quotes}

@router.post("/api/v1/rfq/{rfq_id}/quotations")
def submit_quotation(rfq_id: str, req: SubmitQuotationRequest, user: Dict[str, Any] = Depends(get_current_user)):
    biz = db.query_one("SELECT id FROM businesses WHERE owner_id = :uid AND verification_status = 'approved'", {"uid": user["id"]})
    if not biz:
        raise HTTPException(status_code=403, detail="Only approved businesses can submit quotations.")

    try:
        quote = RFQService.submit_quotation(
            rfq_id=rfq_id,
            supplier_id=biz["id"],
            unit_price_minor=req.unit_price_minor,
            tax_rate_percent=req.tax_rate_percent,
            packaging_costs_minor=req.packaging_costs_minor,
            shipping_costs_minor=req.shipping_costs_minor,
            production_lead_time_days=req.production_lead_time_days,
            payment_terms=req.payment_terms,
            validity_days=req.validity_days,
            notes=req.notes
        )
        return {"status": "success", "message": "Quotation submitted successfully.", "data": quote}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/api/v1/quotations/{quotation_id}/accept")
def accept_quotation(quotation_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        order = RFQService.accept_quotation_and_convert_to_order(quotation_id, user["id"])
        return {
            "status": "success",
            "message": "Quotation accepted! Converted into official confirmed wholesale order.",
            "data": order
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
