from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.subscription_service import SubscriptionService
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(prefix="/api/v1/subscriptions", tags=["Seller Subscriptions"])

class SubscribeRequest(BaseModel):
    plan_id: str

@router.get("/plans")
def get_plans():
    plans = SubscriptionService.get_plans()
    return {"status": "success", "data": plans}

@router.post("/subscribe")
def subscribe(req: SubscribeRequest, user: Dict[str, Any] = Depends(get_current_user)):
    biz = db.query_one("SELECT id FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
    if not biz:
        raise HTTPException(status_code=400, detail="You must register a business before subscribing.")

    try:
        sub = SubscriptionService.subscribe_business(biz["id"], req.plan_id)
        return {"status": "success", "data": sub}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/my-status")
def get_my_subscription(user: Dict[str, Any] = Depends(get_current_user)):
    biz = db.query_one("SELECT id FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
    if not biz:
        return {"status": "success", "data": None}

    sub = db.query_one(
        """SELECT s.*, sp.name AS plan_name, sp.monthly_price_minor, sp.listing_limit, sp.rfq_access
           FROM subscriptions s
           JOIN subscription_plans sp ON s.plan_id = sp.id
           WHERE s.business_id = :bid
           ORDER BY s.created_at DESC LIMIT 1""",
        {"bid": biz["id"]}
    )
    return {"status": "success", "data": sub}
