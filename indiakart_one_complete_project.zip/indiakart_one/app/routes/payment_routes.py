from fastapi import APIRouter, HTTPException, Depends, Header, Request
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.payment_service import PaymentService
from indiakart_one.app.security import get_current_user, require_roles
from indiakart_one.app.database import db

router = APIRouter(prefix="/api/v1/payments", tags=["Payments & Settlements"])

class PaymentIntentRequest(BaseModel):
    order_id: Optional[str] = None
    subscription_id: Optional[str] = None
    payment_method: str = "upi_qr" # 'upi_qr', 'upi_intent', 'card', 'netbanking', 'cod', 'bank_transfer'
    gateway_provider: str = "razorpay"

class VerifyPaymentRequest(BaseModel):
    payment_intent_id: str
    gateway_payment_id: str
    gateway_signature: Optional[str] = None

class RefundRequest(BaseModel):
    order_id: str
    amount_minor: int
    reason: str

@router.post("/intent")
def create_intent(req: PaymentIntentRequest, user: Dict[str, Any] = Depends(get_current_user)):
    amount_minor = 0
    if req.order_id:
        order = db.query_one("SELECT grand_total_minor FROM orders WHERE id = :id", {"id": req.order_id})
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        amount_minor = order["grand_total_minor"]
    elif req.subscription_id:
        sub = db.query_one(
            """SELECT sp.monthly_price_minor, sp.gst_percent 
               FROM subscriptions s 
               JOIN subscription_plans sp ON s.plan_id = sp.id 
               WHERE s.id = :id""",
            {"id": req.subscription_id}
        )
        if not sub:
            raise HTTPException(status_code=404, detail="Subscription not found")
        base = sub["monthly_price_minor"]
        gst = int(round(base * (sub["gst_percent"] / 100.0)))
        amount_minor = base + gst
    else:
        raise HTTPException(status_code=400, detail="Either order_id or subscription_id is required")

    intent = PaymentService.create_payment_intent(
        order_id=req.order_id,
        subscription_id=req.subscription_id,
        amount_minor=amount_minor,
        payment_method=req.payment_method,
        gateway_provider=req.gateway_provider
    )
    return {"status": "success", "data": intent}

@router.post("/verify")
def verify_payment(req: VerifyPaymentRequest, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        captured = PaymentService.verify_and_capture_payment(
            payment_intent_id=req.payment_intent_id,
            gateway_payment_id=req.gateway_payment_id,
            gateway_signature=req.gateway_signature
        )
        return {"status": "success", "message": "Payment verified and captured successfully.", "data": captured}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/webhook")
async def payment_webhook(request: Request, x_razorpay_signature: Optional[str] = Header(None, alias="X-Razorpay-Signature")):
    payload_bytes = await request.body()
    try:
        payload_data = await request.json()
    except Exception:
        payload_data = {}

    sig = x_razorpay_signature or "simulated_header"
    try:
        res = PaymentService.process_webhook_event("razorpay", payload_bytes, sig, payload_data)
        return {"status": "success", "data": res}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/refund")
def issue_refund(req: RefundRequest, user: Dict[str, Any] = Depends(require_roles(["admin", "super_admin"]))):
    try:
        refund = PaymentService.process_refund(req.order_id, req.amount_minor, req.reason, user["id"])
        return {"status": "success", "message": "Refund processed.", "data": refund}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
