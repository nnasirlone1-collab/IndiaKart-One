from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.auth_service import AuthService
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication & Identity"])

class RegisterRequest(BaseModel):
    mobile_number: str = Field(..., example="9812345678")
    full_name: str = Field(..., example="Amit Patel")
    password: str = Field(..., min_length=6, example="Password#123")
    email: Optional[str] = Field(None, example="amit@example.com")
    initial_role: str = Field("buyer", example="buyer")

class LoginRequest(BaseModel):
    identifier: str = Field(..., example="9876543210")
    password: str = Field(..., example="Admin#IndiaKart2026")

class AddressRequest(BaseModel):
    label: str = "Home"
    recipient_name: str
    phone_number: str
    address_line1: str
    address_line2: Optional[str] = None
    city: str
    state: str
    pincode: str
    latitude: float
    longitude: float
    is_default: bool = False

@router.post("/register")
def register(req: RegisterRequest):
    try:
        res = AuthService.register_user(
            mobile_number=req.mobile_number,
            full_name=req.full_name,
            password=req.password,
            email=req.email,
            initial_role=req.initial_role
        )
        return {"status": "success", "data": res}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login")
def login(req: LoginRequest):
    try:
        res = AuthService.authenticate_user(req.identifier, req.password)
        return {"status": "success", "data": res}
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))

@router.get("/me")
def get_me(user: Dict[str, Any] = Depends(get_current_user)):
    user_copy = user.copy()
    user_copy.pop("password_hash", None)
    user_copy.pop("salt", None)
    
    # Check if user has an associated business
    biz = db.query_one("SELECT id, display_name, business_type, verification_status FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
    user_copy["business"] = biz
    return {"status": "success", "data": user_copy}

user_router = APIRouter(prefix="/api/v1/users", tags=["Users & Addresses"])

@user_router.get("/addresses")
def get_addresses(user: Dict[str, Any] = Depends(get_current_user)):
    addrs = db.query("SELECT * FROM addresses WHERE user_id = :uid ORDER BY is_default DESC, created_at DESC", {"uid": user["id"]})
    return {"status": "success", "data": addrs}

@user_router.post("/addresses")
def add_address(req: AddressRequest, user: Dict[str, Any] = Depends(get_current_user)):
    addr = AuthService.add_address(
        user_id=user["id"],
        label=req.label,
        recipient=req.recipient_name,
        phone=req.phone_number,
        line1=req.address_line1,
        city=req.city,
        state=req.state,
        pincode=req.pincode,
        lat=req.latitude,
        lon=req.longitude,
        is_default=req.is_default
    )
    return {"status": "success", "data": addr}
