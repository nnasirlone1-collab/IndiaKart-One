from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.messaging_service import MessagingService
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(tags=["Messaging & Notifications"])

class StartConversationRequest(BaseModel):
    recipient_user_id: str
    conversation_type: str = "direct"
    reference_id: Optional[str] = None
    initial_message: Optional[str] = None

class SendMessageRequest(BaseModel):
    content: str
    attachment_url: Optional[str] = None

@router.post("/api/v1/conversations")
def start_conversation(req: StartConversationRequest, user: Dict[str, Any] = Depends(get_current_user)):
    conv_id = MessagingService.get_or_create_conversation(
        user_1=user["id"],
        user_2=req.recipient_user_id,
        conversation_type=req.conversation_type,
        reference_id=req.reference_id
    )
    if req.initial_message:
        MessagingService.send_message(conv_id, user["id"], req.initial_message)

    return {"status": "success", "conversation_id": conv_id}

@router.get("/api/v1/conversations")
def list_conversations(user: Dict[str, Any] = Depends(get_current_user)):
    convs = db.query(
        """SELECT c.*, 
                  (SELECT m.content FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message,
                  (SELECT m.created_at FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message_at
           FROM conversations c
           JOIN conversation_participants cp ON c.id = cp.conversation_id
           WHERE cp.user_id = :uid
           ORDER BY last_message_at DESC""",
        {"uid": user["id"]}
    )
    return {"status": "success", "data": convs}

@router.get("/api/v1/conversations/{conversation_id}/messages")
def get_messages(conversation_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        messages = MessagingService.get_messages(conversation_id, user["id"])
        return {"status": "success", "data": messages}
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))

@router.post("/api/v1/conversations/{conversation_id}/messages")
def send_message(conversation_id: str, req: SendMessageRequest, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        msg = MessagingService.send_message(conversation_id, user["id"], req.content, req.attachment_url)
        return {"status": "success", "data": msg}
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))

@router.get("/api/v1/notifications")
def get_notifications(user: Dict[str, Any] = Depends(get_current_user)):
    notifs = db.query(
        "SELECT * FROM notifications WHERE user_id = :uid ORDER BY created_at DESC LIMIT 50",
        {"uid": user["id"]}
    )
    # Mark read
    db.execute("UPDATE notifications SET is_read = 1 WHERE user_id = :uid", {"uid": user["id"]})
    return {"status": "success", "data": notifs}
