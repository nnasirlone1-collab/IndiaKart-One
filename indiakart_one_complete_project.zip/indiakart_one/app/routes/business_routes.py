import uuid
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.geo_service import GeoService
from indiakart_one.app.security import get_current_user, require_roles
from indiakart_one.app.database import db

router = APIRouter(prefix="/api/v1/businesses", tags=["Businesses & Storefronts"])

class SellerOnboardRequest(BaseModel):
    legal_name: str
    display_name: str
    business_type: str # retailer, wholesaler, manufacturer, distributor, restaurant, service_provider
    category_id: Optional[str] = None
    description: Optional[str] = None
    phone: str
    email: Optional[str] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    address_line1: str
    city: str
    state: str
    pincode: str
    latitude: float
    longitude: float
    service_radius_km: float = 15.0
    account_holder_name: Optional[str] = None
    bank_name: Optional[str] = None
    account_number: Optional[str] = None
    ifsc_code: Optional[str] = None
    upi_vpa: Optional[str] = None

@router.get("")
def list_businesses(
    user_lat: Optional[float] = Query(None, description="User latitude for proximity search"),
    user_lon: Optional[float] = Query(None, description="User longitude for proximity search"),
    business_type: Optional[str] = Query(None, description="Filter by business type"),
    category_id: Optional[str] = Query(None, description="Filter by category ID"),
    radius_km: float = Query(30.0, description="Search radius in kilometers"),
    limit: int = Query(50, description="Max results")
):
    if user_lat is not None and user_lon is not None:
        results = GeoService.find_nearby_businesses(
            user_lat=user_lat,
            user_lon=user_lon,
            business_type=business_type,
            category_id=category_id,
            max_radius_km=radius_km,
            limit=limit
        )
        return {"status": "success", "count": len(results), "data": results}
    else:
        sql = "SELECT * FROM businesses WHERE verification_status = 'approved' AND is_open = 1"
        params: Dict[str, Any] = {}
        if business_type:
            sql += " AND business_type = :btype"
            params["btype"] = business_type
        if category_id:
            sql += " AND category_id = :cat_id"
            params["cat_id"] = category_id
        sql += " ORDER BY rating DESC LIMIT :lim"
        params["lim"] = limit
        rows = db.query(sql, params)
        return {"status": "success", "count": len(rows), "data": rows}

@router.get("/{business_id}")
def get_storefront(business_id: str):
    biz = db.query_one("SELECT * FROM businesses WHERE id = :id", {"id": business_id})
    if not biz:
        raise HTTPException(status_code=404, detail="Business not found")
    
    # Load business hours
    hours = db.query("SELECT day_of_week, open_time, close_time, is_closed FROM business_hours WHERE business_id = :id ORDER BY day_of_week ASC", {"id": business_id})
    biz["hours"] = hours
    
    # Load recent reviews
    reviews = db.query(
        """SELECT r.*, u.full_name AS reviewer_name 
           FROM reviews r 
           JOIN users u ON r.user_id = u.id 
           WHERE r.business_id = :id 
           ORDER BY r.created_at DESC LIMIT 10""",
        {"id": business_id}
    )
    biz["recent_reviews"] = reviews

    return {"status": "success", "data": biz}

@router.get("/{business_id}/products")
def get_storefront_products(
    business_id: str,
    category_id: Optional[str] = None,
    pricing_mode: Optional[str] = None
):
    sql = """
        SELECT p.*, c.name AS category_name 
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE p.business_id = :bid AND p.is_active = 1 AND p.moderation_status = 'approved'
    """
    params: Dict[str, Any] = {"bid": business_id}
    if category_id:
        sql += " AND p.category_id = :cid"
        params["cid"] = category_id
    if pricing_mode:
        sql += " AND p.pricing_mode = :pmode"
        params["pmode"] = pricing_mode

    sql += " ORDER BY p.created_at DESC"
    products = db.query(sql, params)
    
    # Attach wholesale tiers to each
    for p in products:
        p["wholesale_tiers"] = db.query(
            "SELECT min_quantity, max_quantity, unit_price_minor FROM wholesale_price_tiers WHERE product_id = :pid ORDER BY min_quantity ASC",
            {"pid": p["id"]}
        )

    return {"status": "success", "count": len(products), "data": products}

seller_router = APIRouter(prefix="/api/v1/seller", tags=["Seller Management"])

@seller_router.post("/onboard")
def onboard_seller(req: SellerOnboardRequest, user: Dict[str, Any] = Depends(get_current_user)):
    existing = db.query_one("SELECT id FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
    if existing:
        raise HTTPException(status_code=400, detail="You already have a registered business application.")

    biz_id = str(uuid.uuid4())
    db.execute(
        """INSERT INTO businesses (
            id, owner_id, legal_name, display_name, business_type, category_id,
            description, phone, email, gstin, pan, address_line1,
            city, state, pincode, latitude, longitude, service_radius_km,
            verification_status, subscription_active
        ) VALUES (
            :id, :oid, :legal, :disp, :btype, :cat,
            :desc, :phone, :email, :gstin, :pan, :addr,
            :city, :state, :pin, :lat, :lon, :srad,
            'pending', 0
        )""",
        {
            "id": biz_id, "oid": user["id"], "legal": req.legal_name, "disp": req.display_name,
            "btype": req.business_type, "cat": req.category_id, "desc": req.description,
            "phone": req.phone, "email": req.email, "gstin": req.gstin, "pan": req.pan,
            "addr": req.address_line1, "city": req.city, "state": req.state, "pin": req.pincode,
            "lat": req.latitude, "lon": req.longitude, "srad": req.service_radius_km
        }
    )

    # Save bank info if provided
    if req.account_number and req.ifsc_code:
        masked = f"XXXXXX{req.account_number[-4:]}" if len(req.account_number) >= 4 else "XXXX"
        db.execute(
            """INSERT INTO business_bank_details (
                id, business_id, account_holder_name, bank_name, account_number_masked, ifsc_code, upi_vpa
            ) VALUES (
                :id, :bid, :hname, :bname, :mask, :ifsc, :upi
            )""",
            {
                "id": str(uuid.uuid4()), "bid": biz_id, "hname": req.account_holder_name or req.display_name,
                "bname": req.bank_name or "Bank", "mask": masked, "ifsc": req.ifsc_code, "upi": req.upi_vpa
            }
        )

    return {"status": "success", "message": "Seller application submitted for KYC review.", "business_id": biz_id}

@seller_router.get("/dashboard")
def get_seller_dashboard(user: Dict[str, Any] = Depends(get_current_user)):
    biz = db.query_one("SELECT * FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
    if not biz:
        raise HTTPException(status_code=404, detail="No business associated with this account.")

    # Calculate live metrics
    orders_stat = db.query_one(
        """SELECT 
            COUNT(*) as total_orders,
            COUNT(CASE WHEN order_status = 'pending_confirmation' THEN 1 END) as pending_orders,
            COUNT(CASE WHEN order_status = 'delivered' THEN 1 END) as completed_orders,
            COUNT(CASE WHEN order_status = 'cancelled' THEN 1 END) as cancelled_orders,
            COALESCE(SUM(grand_total_minor), 0) as gmv_minor
           FROM orders WHERE business_id = :bid""",
        {"bid": biz["id"]}
    )

    low_stock = db.query_one(
        "SELECT COUNT(*) as c FROM products WHERE business_id = :bid AND stock_quantity < 10",
        {"bid": biz["id"]}
    )["c"]

    unanswered_rfqs = db.query_one(
        """SELECT COUNT(*) as c FROM buying_requirements br
           WHERE br.status = 'open' AND (:cat IS NULL OR br.category_id = :cat)""",
        {"cat": biz["category_id"]}
    )["c"]

    # Active subscription
    sub = db.query_one(
        """SELECT s.*, sp.name as plan_name, sp.monthly_price_minor 
           FROM subscriptions s 
           JOIN subscription_plans sp ON s.plan_id = sp.id 
           WHERE s.business_id = :bid AND s.status IN ('active', 'grace_period', 'trial')""",
        {"bid": biz["id"]}
    )

    return {
        "status": "success",
        "data": {
            "business": biz,
            "metrics": {
                "total_orders": orders_stat["total_orders"],
                "pending_orders": orders_stat["pending_orders"],
                "completed_orders": orders_stat["completed_orders"],
                "cancelled_orders": orders_stat["cancelled_orders"],
                "gmv_inr": round(orders_stat["gmv_minor"] / 100.0, 2),
                "low_stock_items": low_stock,
                "unanswered_enquiries": unanswered_rfqs
            },
            "subscription": sub
        }
    }
