from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.admin_service import AdminService
from indiakart_one.app.services.subscription_service import SubscriptionService
from indiakart_one.app.security import get_current_user, require_roles
from indiakart_one.app.database import db

router = APIRouter(prefix="/api/v1/admin", tags=["Super Administration Portal"])

class SellerReviewRequest(BaseModel):
    action: str = Field(..., example="approve") # approve, reject, request_documents
    reason: Optional[str] = None

class ChangePlanPriceRequest(BaseModel):
    new_monthly_price_minor: int = Field(..., example=199900) # In paise
    notes: Optional[str] = None

@router.get("/overview")
def get_admin_overview(user: Dict[str, Any] = Depends(require_roles(["admin", "super_admin"]))):
    metrics = AdminService.get_platform_metrics()
    return {"status": "success", "data": metrics}

@router.get("/sellers/pending")
def get_pending_sellers(user: Dict[str, Any] = Depends(require_roles(["admin", "super_admin"]))):
    sellers = db.query(
        """SELECT b.*, u.full_name AS owner_name, u.mobile_number AS owner_mobile, u.email AS owner_email
           FROM businesses b
           JOIN users u ON b.owner_id = u.id
           WHERE b.verification_status IN ('pending', 'documents_required')
           ORDER BY b.created_at ASC"""
    )
    return {"status": "success", "count": len(sellers), "data": sellers}

@router.post("/sellers/{business_id}/review")
def review_seller(business_id: str, req: SellerReviewRequest, user: Dict[str, Any] = Depends(require_roles(["admin", "super_admin"]))):
    try:
        biz = AdminService.review_seller_application(
            business_id=business_id,
            action=req.action,
            admin_id=user["id"],
            reason=req.reason
        )
        return {"status": "success", "message": f"Seller application marked as {req.action}d.", "data": biz}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/subscriptions/plans/{plan_id}/price")
def update_subscription_price(plan_id: str, req: ChangePlanPriceRequest, user: Dict[str, Any] = Depends(require_roles(["super_admin"]))):
    """Allows Super Administrator to update the monthly subscription price dynamically."""
    try:
        updated_plan = SubscriptionService.update_plan_price(
            plan_id=plan_id,
            new_monthly_price_minor=req.new_monthly_price_minor,
            admin_user_id=user["id"],
            notes=req.notes
        )
        return {
            "status": "success",
            "message": "Subscription plan price updated successfully and recorded in audit log.",
            "data": updated_plan
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/audit-logs")
def get_audit_logs(limit: int = Query(100), user: Dict[str, Any] = Depends(require_roles(["admin", "super_admin"]))):
    logs = AdminService.get_audit_logs(limit=limit)
    return {"status": "success", "count": len(logs), "data": logs}
