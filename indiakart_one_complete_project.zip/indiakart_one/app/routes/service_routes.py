from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.service_marketplace import ServiceMarketplace
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(prefix="/api/v1/services", tags=["Services Marketplace"])

class BookServiceRequest(BaseModel):
    service_id: str
    booking_date: str # YYYY-MM-DD
    time_slot: str # e.g. "10:00 AM - 12:00 PM"
    address_id: Optional[str] = None
    notes: Optional[str] = None

@router.get("")
def list_services(category: Optional[str] = Query(None)):
    sql = """
        SELECT s.*, b.display_name AS business_name, b.phone AS provider_phone, b.rating AS provider_rating
        FROM service_listings s
        JOIN businesses b ON s.business_id = b.id
        WHERE s.is_available = 1 AND b.verification_status = 'approved'
    """
    params = {}
    if category:
        sql += " AND s.service_category = :cat"
        params["cat"] = category
    sql += " ORDER BY b.rating DESC"
    services = db.query(sql, params)
    return {"status": "success", "data": services}

@router.post("/book")
def book_service(req: BookServiceRequest, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        booking = ServiceMarketplace.book_service(
            service_id=req.service_id,
            buyer_id=user["id"],
            booking_date=req.booking_date,
            time_slot=req.time_slot,
            address_id=req.address_id,
            notes=req.notes
        )
        return {"status": "success", "message": "Service booking confirmed.", "data": booking}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/my-bookings")
def get_my_bookings(user: Dict[str, Any] = Depends(get_current_user)):
    bookings = db.query(
        """SELECT sb.*, sl.service_name, sl.service_category, b.display_name AS provider_name, b.phone AS provider_phone
           FROM service_bookings sb
           JOIN service_listings sl ON sb.service_id = sl.id
           JOIN businesses b ON sb.business_id = b.id
           WHERE sb.buyer_id = :uid
           ORDER BY sb.booking_date DESC, sb.created_at DESC""",
        {"uid": user["id"]}
    )
    return {"status": "success", "data": bookings}
