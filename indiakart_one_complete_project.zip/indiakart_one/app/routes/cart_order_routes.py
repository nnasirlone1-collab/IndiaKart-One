import json
from fastapi import APIRouter, HTTPException, Depends, Query, Header
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.cart_service import CartService
from indiakart_one.app.services.order_service import OrderService
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(tags=["Cart & Orders"])

class AddCartItemRequest(BaseModel):
    product_id: str
    quantity: int = 1
    variant_id: Optional[str] = None
    addon_ids: Optional[List[str]] = None

class UpdateCartItemRequest(BaseModel):
    quantity: int

class CheckoutRequest(BaseModel):
    shipping_address_id: str
    fulfilment_type: str = "delivery"
    coupon_code: Optional[str] = None
    special_instructions: Optional[str] = None

class UpdateOrderStatusRequest(BaseModel):
    new_status: str
    notes: Optional[str] = None

@router.get("/api/v1/cart")
def get_cart(coupon_code: Optional[str] = Query(None), user: Dict[str, Any] = Depends(get_current_user)):
    summary = CartService.get_cart_summary(user["id"], coupon_code)
    return {"status": "success", "data": summary}

@router.post("/api/v1/cart/items")
def add_cart_item(req: AddCartItemRequest, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        summary = CartService.add_item(
            user_id=user["id"],
            product_id=req.product_id,
            quantity=req.quantity,
            variant_id=req.variant_id,
            addon_ids=req.addon_ids
        )
        return {"status": "success", "data": summary}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/api/v1/cart/items/{item_id}")
def update_cart_item(item_id: str, req: UpdateCartItemRequest, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        summary = CartService.update_item_quantity(user["id"], item_id, req.quantity)
        return {"status": "success", "data": summary}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/api/v1/cart/items/{item_id}")
def remove_cart_item(item_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    summary = CartService.remove_item(user["id"], item_id)
    return {"status": "success", "data": summary}

@router.post("/api/v1/cart/clear")
def clear_cart(user: Dict[str, Any] = Depends(get_current_user)):
    CartService.clear_cart(user["id"])
    return {"status": "success", "message": "Cart cleared"}

@router.post("/api/v1/checkout")
def checkout(
    req: CheckoutRequest,
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
    user: Dict[str, Any] = Depends(get_current_user)
):
    try:
        orders = OrderService.checkout(
            user_id=user["id"],
            shipping_address_id=req.shipping_address_id,
            fulfilment_type=req.fulfilment_type,
            coupon_code=req.coupon_code,
            special_instructions=req.special_instructions,
            idempotency_key=idempotency_key
        )
        return {"status": "success", "message": f"Successfully created {len(orders)} seller order(s).", "data": orders}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/api/v1/orders")
def get_orders(
    role_view: str = Query("buyer", description="View as buyer or seller"),
    status: Optional[str] = Query(None),
    user: Dict[str, Any] = Depends(get_current_user)
):
    if role_view == "seller":
        biz = db.query_one("SELECT id FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
        if not biz:
            return {"status": "success", "data": []}
        sql = """
            SELECT o.*, u.full_name AS buyer_name, u.mobile_number AS buyer_phone
            FROM orders o
            JOIN users u ON o.buyer_id = u.id
            WHERE o.business_id = :bid
        """
        params = {"bid": biz["id"]}
    else:
        sql = """
            SELECT o.*, b.display_name AS business_name, b.business_type
            FROM orders o
            JOIN businesses b ON o.business_id = b.id
            WHERE o.buyer_id = :uid
        """
        params = {"uid": user["id"]}

    if status:
        sql += " AND o.order_status = :status"
        params["status"] = status

    sql += " ORDER BY o.created_at DESC"
    orders = db.query(sql, params)

    # Attach item summaries
    for o in orders:
        items = db.query("SELECT * FROM order_items WHERE order_id = :oid", {"oid": o["id"]})
        for it in items:
            if it.get("selected_addons_json"):
                try:
                    it["addons"] = json.loads(it["selected_addons_json"])
                except Exception:
                    it["addons"] = []
        o["items"] = items

    return {"status": "success", "count": len(orders), "data": orders}

@router.get("/api/v1/orders/{order_id}")
def get_order_detail(order_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    order = db.query_one(
        """SELECT o.*, b.display_name AS business_name, b.phone AS business_phone, b.address_line1 AS business_address
           FROM orders o
           JOIN businesses b ON o.business_id = b.id
           WHERE o.id = :id""",
        {"id": order_id}
    )
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    # Authorize: user must be buyer, business owner, or admin
    biz = db.query_one("SELECT owner_id FROM businesses WHERE id = :bid", {"bid": order["business_id"]})
    is_admin = "admin" in user.get("roles", []) or "super_admin" in user.get("roles", [])
    if not (order["buyer_id"] == user["id"] or (biz and biz["owner_id"] == user["id"]) or is_admin):
        raise HTTPException(status_code=403, detail="Unauthorized to view this order")

    # Load items and history
    items = db.query("SELECT * FROM order_items WHERE order_id = :oid", {"oid": order_id})
    for it in items:
        if it.get("selected_addons_json"):
            try:
                it["addons"] = json.loads(it["selected_addons_json"])
            except Exception:
                it["addons"] = []
    order["items"] = items

    history = db.query("SELECT * FROM order_status_history WHERE order_id = :oid ORDER BY created_at ASC", {"oid": order_id})
    order["timeline"] = history

    return {"status": "success", "data": order}

@router.post("/api/v1/orders/{order_id}/status")
def update_order_status(order_id: str, req: UpdateOrderStatusRequest, user: Dict[str, Any] = Depends(get_current_user)):
    try:
        updated = OrderService.update_order_status(order_id, req.new_status, user["id"], req.notes)
        return {"status": "success", "data": updated}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
