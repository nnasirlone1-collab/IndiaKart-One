from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from indiakart_one.app.services.product_service import ProductService
from indiakart_one.app.security import get_current_user
from indiakart_one.app.database import db

router = APIRouter(tags=["Product Catalogue & Search"])

class CreateProductRequest(BaseModel):
    category_id: str
    name: str
    retail_price_minor: int = 0
    pricing_mode: str = "fixed" # fixed, price_on_demand, fixed_and_rfq
    short_description: Optional[str] = None
    description: Optional[str] = None
    brand: Optional[str] = None
    unit_of_measure: str = "piece"
    min_order_quantity: int = 1
    stock_quantity: int = 0
    primary_image_url: Optional[str] = None
    is_veg: int = 1
    variants: Optional[List[Dict[str, Any]]] = None
    wholesale_tiers: Optional[List[Dict[str, Any]]] = None
    addon_groups: Optional[List[Dict[str, Any]]] = None

@router.get("/api/v1/categories")
def list_categories(is_b2b: Optional[int] = Query(None)):
    sql = "SELECT * FROM categories WHERE is_active = 1"
    params: Dict[str, Any] = {}
    if is_b2b is not None:
        sql += " AND is_b2b = :b2b"
        params["b2b"] = is_b2b
    sql += " ORDER BY sort_order ASC"
    return {"status": "success", "data": db.query(sql, params)}

@router.get("/api/v1/products")
def search_products(
    q: Optional[str] = Query(None, description="Search query across title, brand, description"),
    category_id: Optional[str] = Query(None),
    business_type: Optional[str] = Query(None),
    pricing_mode: Optional[str] = Query(None),
    min_price: Optional[int] = Query(None),
    max_price: Optional[int] = Query(None),
    is_veg: Optional[int] = Query(None),
    sort_by: str = Query("created_at_desc", description="sort option: price_asc, price_desc, rating, created_at_desc"),
    limit: int = Query(50)
):
    sql = """
        SELECT p.*, b.display_name AS business_name, b.business_type, b.rating AS business_rating, c.name AS category_name
        FROM products p
        JOIN businesses b ON p.business_id = b.id
        JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1 AND p.moderation_status = 'approved' AND b.verification_status = 'approved'
    """
    params: Dict[str, Any] = {}

    if q:
        sql += " AND (p.name LIKE :q OR p.brand LIKE :q OR p.description LIKE :q OR b.display_name LIKE :q)"
        params["q"] = f"%{q}%"

    if category_id:
        sql += " AND p.category_id = :cid"
        params["cid"] = category_id

    if business_type:
        sql += " AND b.business_type = :btype"
        params["btype"] = business_type

    if pricing_mode:
        sql += " AND p.pricing_mode = :pmode"
        params["pmode"] = pricing_mode

    if min_price is not None:
        sql += " AND p.retail_price_minor >= :min_p"
        params["min_p"] = min_price

    if max_price is not None:
        sql += " AND p.retail_price_minor <= :max_p"
        params["max_p"] = max_price

    if is_veg is not None:
        sql += " AND p.is_veg = :veg"
        params["veg"] = is_veg

    if sort_by == "price_asc":
        sql += " ORDER BY p.retail_price_minor ASC"
    elif sort_by == "price_desc":
        sql += " ORDER BY p.retail_price_minor DESC"
    elif sort_by == "rating":
        sql += " ORDER BY b.rating DESC"
    else:
        sql += " ORDER BY p.created_at DESC"

    sql += " LIMIT :lim"
    params["lim"] = limit

    products = db.query(sql, params)
    
    # Attach wholesale tier indicators
    for p in products:
        tiers = db.query("SELECT min_quantity, unit_price_minor FROM wholesale_price_tiers WHERE product_id = :pid ORDER BY min_quantity ASC", {"pid": p["id"]})
        p["has_wholesale_pricing"] = len(tiers) > 0
        p["wholesale_tiers"] = tiers

    return {"status": "success", "count": len(products), "data": products}

@router.get("/api/v1/products/{product_id}")
def get_product_details(product_id: str):
    product = ProductService.get_product_detail(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"status": "success", "data": product}

@router.post("/api/v1/products")
def create_product(req: CreateProductRequest, user: Dict[str, Any] = Depends(get_current_user)):
    biz = db.query_one("SELECT id FROM businesses WHERE owner_id = :uid", {"uid": user["id"]})
    if not biz:
        raise HTTPException(status_code=403, detail="You must have an approved business to create products.")

    try:
        product = ProductService.create_product(
            business_id=biz["id"],
            category_id=req.category_id,
            name=req.name,
            retail_price_minor=req.retail_price_minor,
            pricing_mode=req.pricing_mode,
            short_description=req.short_description,
            description=req.description,
            brand=req.brand,
            unit_of_measure=req.unit_of_measure,
            min_order_quantity=req.min_order_quantity,
            stock_quantity=req.stock_quantity,
            primary_image_url=req.primary_image_url,
            is_veg=req.is_veg,
            variants=req.variants,
            wholesale_tiers=req.wholesale_tiers,
            addon_groups=req.addon_groups
        )
        return {"status": "success", "data": product}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
