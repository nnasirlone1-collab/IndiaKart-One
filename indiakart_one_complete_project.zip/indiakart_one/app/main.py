import os
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from indiakart_one.app.config import settings
from indiakart_one.app.database import db
from indiakart_one.app.seed_data import seed_database

# Import routers
from indiakart_one.app.routes.auth_routes import router as auth_router, user_router
from indiakart_one.app.routes.business_routes import router as business_router, seller_router
from indiakart_one.app.routes.product_routes import router as product_router
from indiakart_one.app.routes.cart_order_routes import router as cart_order_router
from indiakart_one.app.routes.payment_routes import router as payment_router
from indiakart_one.app.routes.subscription_routes import router as subscription_router
from indiakart_one.app.routes.b2b_rfq_routes import router as b2b_rfq_router
from indiakart_one.app.routes.service_routes import router as service_router
from indiakart_one.app.routes.messaging_routes import router as messaging_router
from indiakart_one.app.routes.admin_routes import router as admin_router

app = FastAPI(
    title="IndiaKart One API 🇮🇳",
    description="The Complete B2B + B2C + Wholesale + Manufacturing + Services Super-App Platform",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include All API Routers
app.include_router(auth_router)
app.include_router(user_router)
app.include_router(business_router)
app.include_router(seller_router)
app.include_router(product_router)
app.include_router(cart_order_router)
app.include_router(payment_router)
app.include_router(subscription_router)
app.include_router(b2b_rfq_router)
app.include_router(service_router)
app.include_router(messaging_router)
app.include_router(admin_router)

# Static files mount
static_dir = Path(__file__).parent.parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

@app.on_event("startup")
def on_startup():
    print(f"[{settings.APP_NAME}] Initializing database at {settings.DATABASE_PATH}...")
    # Seed database if not initialized
    try:
        count = db.query_one("SELECT COUNT(*) as c FROM users")["c"]
        if count == 0:
            seed_database()
    except Exception:
        seed_database()
    print(f"[{settings.APP_NAME}] Startup complete.")

@app.get("/health")
def health_check():
    try:
        user_count = db.query_one("SELECT COUNT(*) as c FROM users")["c"]
        return {
            "status": "healthy",
            "app_name": settings.APP_NAME,
            "version": "1.0.0",
            "database": "connected",
            "users_count": user_count
        }
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}

@app.get("/", response_class=FileResponse)
def serve_index():
    index_file = static_dir / "index.html"
    if index_file.exists():
        return FileResponse(str(index_file))
    return HTMLResponse("<h1>IndiaKart One API is running. Visit <a href='/docs'>/docs</a> for Swagger documentation.</h1>")
