-- IndiaKart One Comprehensive Relational Database Schema
-- Standard SQL compatible with SQLite3 / PostgreSQL

PRAGMA foreign_keys = ON;

-- 1. IDENTITY & USERS
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    mobile_number TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    full_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    is_active INTEGER DEFAULT 1,
    is_verified INTEGER DEFAULT 0,
    mfa_enabled INTEGER DEFAULT 0,
    mfa_secret TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_roles (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL, -- 'buyer', 'seller', 'manufacturer', 'distributor', 'wholesaler', 'retailer', 'restaurant', 'service_provider', 'admin', 'super_admin'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, role)
);

CREATE TABLE IF NOT EXISTS user_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token TEXT UNIQUE NOT NULL,
    device_info TEXT,
    ip_address TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS addresses (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label TEXT DEFAULT 'Home', -- 'Home', 'Work', 'Warehouse', 'Factory'
    recipient_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    address_line1 TEXT NOT NULL,
    address_line2 TEXT,
    landmark TEXT,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    pincode TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    is_default INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS authentication_events (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    event_type TEXT NOT NULL, -- 'LOGIN_SUCCESS', 'LOGIN_FAILURE', 'MFA_CHALLENGE', 'LOGOUT', 'PASSWORD_RESET'
    ip_address TEXT,
    user_agent TEXT,
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. BUSINESSES & SELLER ONBOARDING
CREATE TABLE IF NOT EXISTS businesses (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    legal_name TEXT NOT NULL,
    display_name TEXT NOT NULL,
    business_type TEXT NOT NULL, -- 'retailer', 'wholesaler', 'manufacturer', 'distributor', 'restaurant', 'service_provider'
    category_id TEXT,
    description TEXT,
    logo_url TEXT,
    cover_image_url TEXT,
    email TEXT,
    phone TEXT NOT NULL,
    website TEXT,
    gstin TEXT,
    pan TEXT,
    address_line1 TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    pincode TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    service_radius_km REAL DEFAULT 15.0,
    verification_status TEXT DEFAULT 'pending', -- 'draft', 'pending', 'documents_required', 'approved', 'rejected', 'suspended'
    rejection_reason TEXT,
    is_open INTEGER DEFAULT 1,
    min_order_value_minor INTEGER DEFAULT 0, -- INR in paise
    delivery_supported INTEGER DEFAULT 1,
    pickup_supported INTEGER DEFAULT 1,
    rating REAL DEFAULT 0.0,
    review_count INTEGER DEFAULT 0,
    subscription_active INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS business_documents (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL, -- 'PAN', 'GST_CERTIFICATE', 'FSSAI_LICENSE', 'UDYAM_MSME', 'TRADE_LICENSE', 'BANK_PROOF'
    document_number TEXT,
    file_url TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS business_service_areas (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    pincode TEXT,
    city TEXT,
    radius_km REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS business_hours (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL, -- 0=Sunday, 1=Monday ... 6=Saturday
    open_time TEXT NOT NULL, -- '09:00'
    close_time TEXT NOT NULL, -- '21:00'
    is_closed INTEGER DEFAULT 0,
    UNIQUE(business_id, day_of_week)
);

CREATE TABLE IF NOT EXISTS business_bank_details (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    account_holder_name TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    account_number_masked TEXT NOT NULL,
    ifsc_code TEXT NOT NULL,
    upi_vpa TEXT,
    is_verified INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. PRODUCTS & CATALOGUE
CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    icon_name TEXT,
    parent_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    is_b2b INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    short_description TEXT,
    description TEXT,
    brand TEXT,
    manufacturer_name TEXT,
    sku TEXT,
    hsn_code TEXT,
    unit_of_measure TEXT DEFAULT 'piece', -- 'kg', 'gram', 'piece', 'box', 'carton', 'litre', 'metre'
    package_size TEXT,
    pricing_mode TEXT DEFAULT 'fixed', -- 'fixed', 'price_on_demand', 'fixed_and_rfq'
    retail_price_minor INTEGER NOT NULL DEFAULT 0, -- INR in paise
    mrp_price_minor INTEGER, -- Maximum Retail Price in paise
    tax_rate_percent REAL DEFAULT 5.0, -- GST rate
    min_order_quantity INTEGER DEFAULT 1,
    stock_quantity INTEGER DEFAULT 0,
    is_in_stock INTEGER DEFAULT 1,
    is_active INTEGER DEFAULT 1,
    moderation_status TEXT DEFAULT 'approved', -- 'pending', 'approved', 'rejected'
    primary_image_url TEXT,
    images_json TEXT, -- JSON array of image URLs
    is_veg INTEGER DEFAULT 1, -- For food & groceries
    preparation_time_minutes INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_variants (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_name TEXT NOT NULL, -- e.g., '500g', '1kg', 'Red - XL'
    sku TEXT,
    additional_price_minor INTEGER DEFAULT 0,
    retail_price_minor INTEGER,
    stock_quantity INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_addon_groups (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    title TEXT NOT NULL, -- 'Extra Cheese', 'Packaging Option', 'Custom Branding'
    is_required INTEGER DEFAULT 0,
    min_selections INTEGER DEFAULT 0,
    max_selections INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_addons (
    id TEXT PRIMARY KEY,
    group_id TEXT NOT NULL REFERENCES product_addon_groups(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    price_minor INTEGER DEFAULT 0,
    is_available INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS wholesale_price_tiers (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    min_quantity INTEGER NOT NULL,
    max_quantity INTEGER, -- NULL means infinity (e.g., 200+)
    unit_price_minor INTEGER NOT NULL,
    lead_time_days INTEGER DEFAULT 3,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory_movements (
    id TEXT PRIMARY KEY,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_id TEXT,
    quantity_change INTEGER NOT NULL, -- + for restock, - for order
    movement_type TEXT NOT NULL, -- 'RESTOCK', 'ORDER_FULFILLED', 'ORDER_CANCELLED', 'ADJUSTMENT'
    reference_id TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. SHOPPING CARTS & WISHLISTS
CREATE TABLE IF NOT EXISTS carts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

CREATE TABLE IF NOT EXISTS cart_items (
    id TEXT PRIMARY KEY,
    cart_id TEXT NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_id TEXT REFERENCES product_variants(id) ON DELETE SET NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    applied_unit_price_minor INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cart_item_addons (
    id TEXT PRIMARY KEY,
    cart_item_id TEXT NOT NULL REFERENCES cart_items(id) ON DELETE CASCADE,
    addon_id TEXT NOT NULL REFERENCES product_addons(id) ON DELETE CASCADE,
    price_minor INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS wishlists (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, product_id)
);

CREATE TABLE IF NOT EXISTS coupons (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    description TEXT,
    discount_type TEXT NOT NULL, -- 'percentage', 'fixed'
    discount_value REAL NOT NULL, -- 10% or 100 paise
    min_order_value_minor INTEGER DEFAULT 0,
    max_discount_minor INTEGER,
    starts_at TIMESTAMP,
    expires_at TIMESTAMP,
    usage_limit INTEGER,
    is_active INTEGER DEFAULT 1
);

-- 5. ORDERS & FULFILMENT
CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    order_number TEXT UNIQUE NOT NULL,
    buyer_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE RESTRICT,
    order_type TEXT DEFAULT 'retail', -- 'retail', 'wholesale', 'food', 'service'
    order_status TEXT DEFAULT 'pending_confirmation', -- 'awaiting_payment', 'pending_confirmation', 'confirmed', 'processing', 'ready_for_pickup', 'out_for_delivery', 'delivered', 'cancelled', 'returned'
    payment_status TEXT DEFAULT 'unpaid', -- 'unpaid', 'pending', 'paid', 'failed', 'refunded', 'partially_refunded'
    items_subtotal_minor INTEGER NOT NULL,
    tax_total_minor INTEGER NOT NULL DEFAULT 0,
    delivery_fee_minor INTEGER NOT NULL DEFAULT 0,
    discount_total_minor INTEGER NOT NULL DEFAULT 0,
    grand_total_minor INTEGER NOT NULL,
    currency TEXT DEFAULT 'INR',
    shipping_address_id TEXT REFERENCES addresses(id),
    shipping_address_snapshot TEXT, -- JSON formatted copy of address at checkout time
    fulfilment_type TEXT DEFAULT 'delivery', -- 'delivery', 'pickup', 'freight', 'service_appointment'
    special_instructions TEXT,
    idempotency_key TEXT UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    variant_id TEXT,
    product_name TEXT NOT NULL,
    variant_name TEXT,
    quantity INTEGER NOT NULL,
    unit_price_minor INTEGER NOT NULL,
    total_price_minor INTEGER NOT NULL,
    tax_rate_percent REAL DEFAULT 5.0,
    tax_minor INTEGER DEFAULT 0,
    selected_addons_json TEXT
);

CREATE TABLE IF NOT EXISTS order_status_history (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    status TEXT NOT NULL,
    notes TEXT,
    changed_by_user_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. PAYMENTS & SETTLEMENTS
CREATE TABLE IF NOT EXISTS payment_intents (
    id TEXT PRIMARY KEY,
    order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
    subscription_id TEXT,
    amount_minor INTEGER NOT NULL,
    currency TEXT DEFAULT 'INR',
    payment_method TEXT NOT NULL, -- 'upi_qr', 'upi_intent', 'card', 'netbanking', 'cod', 'bank_transfer'
    gateway_provider TEXT DEFAULT 'razorpay', -- 'razorpay', 'cashfree', 'manual_cod'
    gateway_order_id TEXT,
    gateway_payment_id TEXT,
    status TEXT DEFAULT 'created', -- 'created', 'authorized', 'captured', 'failed', 'refunded'
    signature TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payment_webhook_events (
    id TEXT PRIMARY KEY,
    gateway_provider TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    signature_header TEXT,
    is_verified INTEGER DEFAULT 0,
    is_processed INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS refunds (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    payment_intent_id TEXT REFERENCES payment_intents(id),
    amount_minor INTEGER NOT NULL,
    reason TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'processed', 'rejected'
    gateway_refund_id TEXT,
    approved_by_user_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS commission_records (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE RESTRICT,
    order_total_minor INTEGER NOT NULL,
    commission_rate_percent REAL NOT NULL,
    commission_amount_minor INTEGER NOT NULL,
    tax_on_commission_minor INTEGER DEFAULT 0,
    seller_payout_minor INTEGER NOT NULL,
    settlement_status TEXT DEFAULT 'pending', -- 'pending', 'settled', 'held'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. SELLER SUBSCRIPTIONS
CREATE TABLE IF NOT EXISTS subscription_plans (
    id TEXT PRIMARY KEY,
    plan_code TEXT UNIQUE NOT NULL, -- 'BUSINESS_PRO', 'BUSINESS_ENTERPRISE'
    name TEXT NOT NULL,
    description TEXT,
    monthly_price_minor INTEGER NOT NULL DEFAULT 149900, -- Default ₹1,499.00 in paise
    annual_price_minor INTEGER NOT NULL DEFAULT 1499000, -- ₹14,990.00
    currency TEXT DEFAULT 'INR',
    gst_percent REAL DEFAULT 18.0,
    listing_limit INTEGER DEFAULT 500,
    rfq_access INTEGER DEFAULT 1,
    verified_badge_eligible INTEGER DEFAULT 1,
    analytics_tier TEXT DEFAULT 'pro',
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    plan_id TEXT NOT NULL REFERENCES subscription_plans(id) ON DELETE RESTRICT,
    status TEXT DEFAULT 'active', -- 'trial', 'active', 'past_due', 'grace_period', 'expired', 'cancelled'
    current_period_start TIMESTAMP NOT NULL,
    current_period_end TIMESTAMP NOT NULL,
    grace_period_end TIMESTAMP,
    auto_renew INTEGER DEFAULT 1,
    last_payment_intent_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subscription_history (
    id TEXT PRIMARY KEY,
    subscription_id TEXT NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL, -- 'CREATED', 'RENEWED', 'PLAN_CHANGED', 'PRICE_UPDATED', 'CANCELLED', 'EXPIRED'
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. B2B / WHOLESALE / RFQ & QUOTATIONS
CREATE TABLE IF NOT EXISTS buying_requirements (
    id TEXT PRIMARY KEY,
    buyer_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    product_name TEXT NOT NULL,
    specifications TEXT,
    required_quantity INTEGER NOT NULL,
    unit_of_measure TEXT NOT NULL,
    target_price_minor INTEGER,
    delivery_pincode TEXT NOT NULL,
    delivery_city TEXT NOT NULL,
    required_date DATE,
    customization_details TEXT,
    status TEXT DEFAULT 'open', -- 'open', 'quotes_received', 'accepted', 'fulfilled', 'closed'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quotations (
    id TEXT PRIMARY KEY,
    rfq_id TEXT NOT NULL REFERENCES buying_requirements(id) ON DELETE CASCADE,
    supplier_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE RESTRICT,
    revision_number INTEGER DEFAULT 1,
    unit_price_minor INTEGER NOT NULL,
    total_price_minor INTEGER NOT NULL,
    tax_rate_percent REAL DEFAULT 18.0,
    packaging_costs_minor INTEGER DEFAULT 0,
    shipping_costs_minor INTEGER DEFAULT 0,
    production_lead_time_days INTEGER DEFAULT 7,
    payment_terms TEXT DEFAULT '30% Advance, 70% Before Dispatch',
    validity_days INTEGER DEFAULT 14,
    notes TEXT,
    status TEXT DEFAULT 'submitted', -- 'submitted', 'under_review', 'accepted', 'rejected', 'expired', 'converted_to_order'
    resulting_order_id TEXT REFERENCES orders(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. MESSAGING & NOTIFICATIONS
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    conversation_type TEXT DEFAULT 'direct', -- 'direct', 'rfq_discussion', 'order_support'
    reference_id TEXT, -- e.g. RFQ ID or Order ID
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS conversation_participants (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_read_at TIMESTAMP,
    UNIQUE(conversation_id, user_id)
);

CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    content TEXT NOT NULL,
    attachment_url TEXT,
    attachment_type TEXT,
    is_system_message INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    notification_type TEXT NOT NULL, -- 'ORDER_UPDATE', 'RFQ_RECEIVED', 'QUOTE_RECEIVED', 'PAYMENT', 'PROMO'
    reference_id TEXT,
    is_read INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. SERVICES MARKETPLACE
CREATE TABLE IF NOT EXISTS service_listings (
    id TEXT PRIMARY KEY,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    service_name TEXT NOT NULL,
    description TEXT,
    service_category TEXT NOT NULL,
    pricing_model TEXT DEFAULT 'fixed', -- 'fixed', 'hourly', 'starting_at', 'quote_on_inspection'
    base_price_minor INTEGER NOT NULL,
    duration_minutes INTEGER DEFAULT 60,
    coverage_radius_km REAL DEFAULT 10.0,
    is_available INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_bookings (
    id TEXT PRIMARY KEY,
    service_id TEXT NOT NULL REFERENCES service_listings(id) ON DELETE RESTRICT,
    buyer_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE RESTRICT,
    booking_date DATE NOT NULL,
    time_slot TEXT NOT NULL, -- '10:00 AM - 12:00 PM'
    service_address_id TEXT REFERENCES addresses(id),
    status TEXT DEFAULT 'pending', -- 'pending', 'confirmed', 'in_progress', 'completed', 'cancelled'
    agreed_price_minor INTEGER NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 11. REVIEWS & RATINGS
CREATE TABLE IF NOT EXISTS reviews (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    business_id TEXT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    product_id TEXT REFERENCES products(id) ON DELETE SET NULL,
    service_id TEXT REFERENCES service_listings(id) ON DELETE SET NULL,
    order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    is_verified_purchase INTEGER DEFAULT 0,
    seller_reply TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 12. PLATFORM SETTINGS & AUDIT LOGS
CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_by_user_id TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id TEXT PRIMARY KEY,
    admin_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    action_type TEXT NOT NULL, -- 'PRICE_CHANGE', 'SELLER_APPROVED', 'SELLER_SUSPENDED', 'REFUND_APPROVED', 'COMMISSION_CONFIG'
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    old_value TEXT,
    new_value TEXT,
    ip_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- INDEXES for fast retrieval & search
CREATE INDEX IF NOT EXISTS idx_products_business ON products(business_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active, moderation_status);
CREATE INDEX IF NOT EXISTS idx_businesses_geo ON businesses(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_businesses_type ON businesses(business_type, verification_status);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_business ON orders(business_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_quotations_rfq ON quotations(rfq_id);
