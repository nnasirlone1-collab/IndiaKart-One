import sqlite3
import math
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from indiakart_one.app.config import settings

def haversine_distance_km(lat1: Optional[float], lon1: Optional[float], lat2: Optional[float], lon2: Optional[float]) -> float:
    """Calculates spherical distance between two points on Earth in kilometers."""
    if lat1 is None or lon1 is None or lat2 is None or lon2 is None:
        return 999999.0
    try:
        r = 6371.0 # Earth's radius in km
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat / 2) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(r * c, 2)
    except Exception:
        return 999999.0

class Database:
    def __init__(self, db_path: str = None):
        self.db_path = db_path or settings.DATABASE_PATH
        # Ensure parent directory exists
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.create_function("haversine_distance_km", 4, haversine_distance_km)
        return conn

    def init_db(self, schema_file: str = None):
        if not schema_file:
            current_dir = Path(__file__).parent
            schema_file = str(current_dir / "models" / "schema.sql")
        
        with open(schema_file, "r") as f:
            sql_script = f.read()

        with self.get_connection() as conn:
            conn.executescript(sql_script)
            conn.commit()

    def query(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def query_one(self, sql: str, params: tuple = ()) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            row = cursor.fetchone()
            return dict(row) if row else None

    def execute(self, sql: str, params: tuple = ()) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            conn.commit()
            return cursor.rowcount

    def execute_many(self, statements: List[tuple]) -> None:
        """Executes a list of (sql, params) in a single atomic transaction."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            for sql, params in statements:
                cursor.execute(sql, params)
            conn.commit()

db = Database()
