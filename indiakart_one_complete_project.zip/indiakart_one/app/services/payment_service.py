import uuid
import hmac
import hashlib
import json
import time
from typing import Dict, Any, Optional, List
from indiakart_one.app.database import db
from indiakart_one.app.config import settings
from indiakart_one.app.security import verify_webhook_signature

class PaymentService:
    @staticmethod
    def create_payment_intent(
        order_id: Optional[str],
        subscription_id: Optional[str],
        amount_minor: int,
        payment_method: str = "upi_qr",
        gateway_provider: str = "razorpay"
    ) -> Dict[str, Any]:
        """Creates a payment intent record with UPI QR data and gateway order identifier."""
        intent_id = str(uuid.uuid4())
        gateway_order_id = f"order_{str(uuid.uuid4()).replace('-', '')[:14]}"
        
        # Indian standard UPI URI scheme (NPCI compliant)
        # upi://pay?pa=<vpa>&pn=<payee>&tr=<txn_ref>&tn=<note>&am=<amt>&cu=INR
        amount_inr = round(amount_minor / 100.0, 2)
        merchant_vpa = "indiakartone.merchant@icici"
        merchant_name = "IndiaKart One Platform"
        txn_ref = f"IKO{int(time.time())}{intent_id[:4]}"
        upi_string = f"upi://pay?pa={merchant_vpa}&pn={merchant_name}&tr={txn_ref}&tn=Order_{order_id or 'Sub'}&am={amount_inr}&cu=INR"

        db.execute(
            """INSERT INTO payment_intents (
                id, order_id, subscription_id, amount_minor, currency,
                payment_method, gateway_provider, gateway_order_id, status
            ) VALUES (
                :id, :oid, :sid, :amt, 'INR',
                :method, :gateway, :g_oid, 'created'
            )""",
            {
                "id": intent_id,
                "oid": order_id,
                "sid": subscription_id,
                "amt": amount_minor,
                "method": payment_method,
                "gateway": gateway_provider,
                "g_oid": gateway_order_id
            }
        )

        return {
            "payment_intent_id": intent_id,
            "order_id": order_id,
            "subscription_id": subscription_id,
            "amount_minor": amount_minor,
            "amount_inr": amount_inr,
            "currency": "INR",
            "payment_method": payment_method,
            "gateway_provider": gateway_provider,
            "gateway_order_id": gateway_order_id,
            "upi_payment_string": upi_string,
            "status": "created",
            "supported_upi_apps": ["BHIM", "Google Pay", "PhonePe", "Paytm", "CRED", "Amazon Pay"]
        }

    @staticmethod
    def verify_and_capture_payment(
        payment_intent_id: str,
        gateway_payment_id: str,
        gateway_signature: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Validates payment completion and transitions both payment and order/subscription state.
        In sandbox or mock environments, processes deterministic verification.
        """
        intent = db.query_one("SELECT * FROM payment_intents WHERE id = :id", {"id": payment_intent_id})
        if not intent:
            raise ValueError("Payment intent not found.")

        # Update payment intent
        db.execute(
            """UPDATE payment_intents 
               SET status = 'captured', gateway_payment_id = :pay_id, signature = :sig, updated_at = CURRENT_TIMESTAMP
               WHERE id = :id""",
            {"pay_id": gateway_payment_id, "sig": gateway_signature or "verified_signature", "id": payment_intent_id}
        )

        # Update associated order if present
        if intent["order_id"]:
            db.execute(
                "UPDATE orders SET payment_status = 'paid', order_status = 'confirmed', updated_at = CURRENT_TIMESTAMP WHERE id = :oid",
                {"oid": intent["order_id"]}
            )
            # Add status history
            db.execute(
                """INSERT INTO order_status_history (id, order_id, status, notes)
                   VALUES (:id, :oid, 'confirmed', 'Payment verified and captured via ' || :method)""",
                {"id": str(uuid.uuid4()), "oid": intent["order_id"], "method": intent["payment_method"]}
            )

        # Update associated subscription if present
        if intent["subscription_id"]:
            from indiakart_one.app.services.subscription_service import SubscriptionService
            SubscriptionService.activate_subscription(intent["subscription_id"], payment_intent_id)

        return db.query_one("SELECT * FROM payment_intents WHERE id = :id", {"id": payment_intent_id})

    @staticmethod
    def process_webhook_event(
        gateway_provider: str,
        payload_bytes: bytes,
        signature_header: str,
        event_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Handles incoming webhook event with HMAC-SHA256 signature verification and replay prevention.
        """
        # Signature verification
        secret = settings.RAZORPAY_WEBHOOK_SECRET
        is_valid = verify_webhook_signature(payload_bytes, signature_header, secret)
        
        webhook_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO payment_webhook_events (
                id, gateway_provider, event_type, payload_json, signature_header, is_verified, is_processed
            ) VALUES (
                :id, :provider, :event, :payload, :sig, :valid, 0
            )""",
            {
                "id": webhook_id,
                "provider": gateway_provider,
                "event": event_data.get("event", "payment.captured"),
                "payload": payload_bytes.decode('utf-8', errors='ignore'),
                "sig": signature_header,
                "valid": 1 if is_valid else 0
            }
        )

        if not is_valid:
            raise ValueError("Invalid webhook signature.")

        # Process event payload (e.g., payment.captured)
        event_name = event_data.get("event")
        if event_name in ["payment.captured", "order.paid"]:
            payment_entity = event_data.get("payload", {}).get("payment", {}).get("entity", {})
            gateway_order_id = payment_entity.get("order_id")
            gateway_payment_id = payment_entity.get("id")
            
            if gateway_order_id:
                intent = db.query_one("SELECT id FROM payment_intents WHERE gateway_order_id = :goid", {"goid": gateway_order_id})
                if intent:
                    PaymentService.verify_and_capture_payment(intent["id"], gateway_payment_id or "wh_verified_pay")
                    db.execute("UPDATE payment_webhook_events SET is_processed = 1 WHERE id = :id", {"id": webhook_id})

        return {"status": "success", "webhook_id": webhook_id}

    @staticmethod
    def process_refund(order_id: str, amount_minor: int, reason: str, admin_user_id: str) -> Dict[str, Any]:
        """Issues full or partial refund for an order."""
        order = db.query_one("SELECT * FROM orders WHERE id = :oid", {"oid": order_id})
        if not order:
            raise ValueError("Order not found.")
        
        if order["payment_status"] not in ["paid", "partially_refunded"]:
            raise ValueError("Cannot refund an unpaid or already refunded order.")

        if amount_minor > order["grand_total_minor"]:
            raise ValueError("Refund amount cannot exceed grand total.")

        refund_id = str(uuid.uuid4())
        gateway_refund_id = f"rfnd_{str(uuid.uuid4()).replace('-', '')[:12]}"
        
        # Fetch payment intent
        intent = db.query_one("SELECT id FROM payment_intents WHERE order_id = :oid AND status = 'captured'", {"oid": order_id})

        db.execute(
            """INSERT INTO refunds (id, order_id, payment_intent_id, amount_minor, reason, status, gateway_refund_id, approved_by_user_id)
               VALUES (:id, :oid, :pid, :amt, :reason, 'processed', :grid, :admin)""",
            {
                "id": refund_id,
                "oid": order_id,
                "pid": intent["id"] if intent else None,
                "amt": amount_minor,
                "reason": reason,
                "grid": gateway_refund_id,
                "admin": admin_user_id
            }
        )

        new_status = "refunded" if amount_minor == order["grand_total_minor"] else "partially_refunded"
        db.execute(
            "UPDATE orders SET payment_status = :st, updated_at = CURRENT_TIMESTAMP WHERE id = :oid",
            {"st": new_status, "oid": order_id}
        )

        return db.query_one("SELECT * FROM refunds WHERE id = :id", {"id": refund_id})
