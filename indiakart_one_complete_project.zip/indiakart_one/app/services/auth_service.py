import uuid
import time
from typing import Dict, Any, Optional, List
from indiakart_one.app.database import db
from indiakart_one.app.security import hash_password, verify_password, create_access_token
from indiakart_one.app.config import settings

class AuthService:
    @staticmethod
    def register_user(mobile_number: str, full_name: str, password: str, email: Optional[str] = None, initial_role: str = "buyer") -> Dict[str, Any]:
        # Check if mobile exists
        existing = db.query_one("SELECT id FROM users WHERE mobile_number = :mobile", {"mobile": mobile_number})
        if existing:
            raise ValueError("An account with this mobile number already exists.")
        
        if email:
            existing_email = db.query_one("SELECT id FROM users WHERE email = :email", {"email": email})
            if existing_email:
                raise ValueError("An account with this email already exists.")
        
        user_id = str(uuid.uuid4())
        pwd_hash, salt = hash_password(password)
        
        db.execute(
            """INSERT INTO users (id, mobile_number, email, full_name, password_hash, salt, is_verified) 
               VALUES (:id, :mobile, :email, :full_name, :hash, :salt, 1)""",
            {
                "id": user_id,
                "mobile": mobile_number,
                "email": email,
                "full_name": full_name,
                "hash": pwd_hash,
                "salt": salt
            }
        )
        
        # Assign initial role
        role_id = str(uuid.uuid4())
        db.execute(
            "INSERT INTO user_roles (id, user_id, role) VALUES (:id, :user_id, :role)",
            {"id": role_id, "user_id": user_id, "role": initial_role}
        )
        
        token = create_access_token({"sub": user_id, "mobile": mobile_number, "roles": [initial_role]})
        
        return {
            "user_id": user_id,
            "mobile_number": mobile_number,
            "full_name": full_name,
            "email": email,
            "roles": [initial_role],
            "access_token": token,
            "token_type": "bearer"
        }

    @staticmethod
    def authenticate_user(identifier: str, password: str) -> Dict[str, Any]:
        user = db.query_one(
            "SELECT * FROM users WHERE mobile_number = :id_val OR email = :id_val",
            {"id_val": identifier}
        )
        if not user or not user["is_active"]:
            raise ValueError("Invalid credentials or account deactivated.")
        
        if not verify_password(password, user["password_hash"], user["salt"]):
            # Log failure
            event_id = str(uuid.uuid4())
            db.execute(
                "INSERT INTO authentication_events (id, user_id, event_type, details) VALUES (:id, :uid, 'LOGIN_FAILURE', 'Incorrect password')",
                {"id": event_id, "uid": user["id"]}
            )
            raise ValueError("Invalid credentials.")
        
        roles = db.query("SELECT role FROM user_roles WHERE user_id = :uid", {"uid": user["id"]})
        role_list = [r["role"] for r in roles]
        
        token = create_access_token({"sub": user["id"], "mobile": user["mobile_number"], "roles": role_list})
        
        # Log success
        event_id = str(uuid.uuid4())
        db.execute(
            "INSERT INTO authentication_events (id, user_id, event_type, details) VALUES (:id, :uid, 'LOGIN_SUCCESS', 'Successful authentication')",
            {"id": event_id, "uid": user["id"]}
        )
        
        return {
            "user_id": user["id"],
            "mobile_number": user["mobile_number"],
            "full_name": user["full_name"],
            "email": user["email"],
            "roles": role_list,
            "access_token": token,
            "token_type": "bearer"
        }

    @staticmethod
    def bootstrap_super_admin() -> None:
        """Initializes the super administrator account securely if not already present."""
        admin = db.query_one("SELECT id FROM users WHERE mobile_number = :m", {"m": settings.BOOTSTRAP_ADMIN_MOBILE})
        if not admin:
            user_id = str(uuid.uuid4())
            pwd_hash, salt = hash_password(settings.BOOTSTRAP_ADMIN_PASSWORD)
            db.execute(
                """INSERT INTO users (id, mobile_number, email, full_name, password_hash, salt, is_verified, is_active)
                   VALUES (:id, :mobile, :email, :name, :hash, :salt, 1, 1)""",
                {
                    "id": user_id,
                    "mobile": settings.BOOTSTRAP_ADMIN_MOBILE,
                    "email": settings.BOOTSTRAP_ADMIN_EMAIL,
                    "name": settings.BOOTSTRAP_ADMIN_NAME,
                    "hash": pwd_hash,
                    "salt": salt
                }
            )
            # Add roles
            for r in ["buyer", "seller", "admin", "super_admin"]:
                db.execute(
                    "INSERT OR IGNORE INTO user_roles (id, user_id, role) VALUES (:id, :uid, :r)",
                    {"id": str(uuid.uuid4()), "uid": user_id, "r": r}
                )
            print(f"[BOOTSTRAP] Super Admin initialized: {settings.BOOTSTRAP_ADMIN_MOBILE} ({settings.BOOTSTRAP_ADMIN_EMAIL})")

    @staticmethod
    def add_user_role(user_id: str, role: str) -> None:
        existing = db.query_one("SELECT id FROM user_roles WHERE user_id = :uid AND role = :r", {"uid": user_id, "r": role})
        if not existing:
            db.execute("INSERT INTO user_roles (id, user_id, role) VALUES (:id, :uid, :r)", {"id": str(uuid.uuid4()), "uid": user_id, "r": role})

    @staticmethod
    def add_address(user_id: str, label: str, recipient: str, phone: str, line1: str, city: str, state: str, pincode: str, lat: float, lon: float, is_default: bool = False) -> Dict[str, Any]:
        address_id = str(uuid.uuid4())
        if is_default:
            db.execute("UPDATE addresses SET is_default = 0 WHERE user_id = :uid", {"uid": user_id})
        
        db.execute(
            """INSERT INTO addresses (id, user_id, label, recipient_name, phone_number, address_line1, city, state, pincode, latitude, longitude, is_default)
               VALUES (:id, :uid, :lbl, :rec, :phone, :l1, :city, :state, :pin, :lat, :lon, :def)""",
            {
                "id": address_id,
                "uid": user_id,
                "lbl": label,
                "rec": recipient,
                "phone": phone,
                "l1": line1,
                "city": city,
                "state": state,
                "pin": pincode,
                "lat": lat,
                "lon": lon,
                "def": 1 if is_default else 0
            }
        )
        return db.query_one("SELECT * FROM addresses WHERE id = :id", {"id": address_id})
