import uuid
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db

class ServiceMarketplace:
    @staticmethod
    def create_service(
        business_id: str,
        service_name: str,
        service_category: str,
        pricing_model: str,
        base_price_minor: int,
        description: Optional[str] = None,
        duration_minutes: int = 60,
        coverage_radius_km: float = 15.0
    ) -> Dict[str, Any]:
        service_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO service_listings (
                id, business_id, service_name, description, service_category,
                pricing_model, base_price_minor, duration_minutes, coverage_radius_km
            ) VALUES (
                :id, :bid, :sname, :desc, :scat,
                :pmodel, :price, :dur, :rad
            )""",
            {
                "id": service_id,
                "bid": business_id,
                "sname": service_name,
                "desc": description,
                "scat": service_category,
                "pmodel": pricing_model,
                "price": base_price_minor,
                "dur": duration_minutes,
                "rad": coverage_radius_km
            }
        )
        return db.query_one("SELECT * FROM service_listings WHERE id = :id", {"id": service_id})

    @staticmethod
    def book_service(
        service_id: str,
        buyer_id: str,
        booking_date: str,
        time_slot: str,
        address_id: Optional[str] = None,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        service = db.query_one("SELECT * FROM service_listings WHERE id = :id AND is_available = 1", {"id": service_id})
        if not service:
            raise ValueError("Service listing not found or currently unavailable.")

        booking_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO service_bookings (
                id, service_id, buyer_id, business_id, booking_date, time_slot,
                service_address_id, status, agreed_price_minor, notes
            ) VALUES (
                :id, :sid, :bid, :biz_id, :bdate, :slot,
                :aid, 'pending', :price, :notes
            )""",
            {
                "id": booking_id,
                "sid": service_id,
                "bid": buyer_id,
                "biz_id": service["business_id"],
                "bdate": booking_date,
                "slot": time_slot,
                "aid": address_id,
                "price": service["base_price_minor"],
                "notes": notes
            }
        )

        # Notify provider
        db.execute(
            """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
               SELECT :nid, owner_id, 'New Service Booking', 'New booking request for ' || :sname, 'ORDER_UPDATE', :bid
               FROM businesses WHERE id = :biz_id""",
            {
                "nid": str(uuid.uuid4()),
                "sname": service["service_name"],
                "bid": booking_id,
                "biz_id": service["business_id"]
            }
        )

        return db.query_one("SELECT * FROM service_bookings WHERE id = :id", {"id": booking_id})
