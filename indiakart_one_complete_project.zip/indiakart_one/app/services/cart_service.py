import uuid
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db
from indiakart_one.app.services.product_service import ProductService

class CartService:
    @staticmethod
    def get_or_create_cart(user_id: str) -> str:
        cart = db.query_one("SELECT id FROM carts WHERE user_id = :uid", {"uid": user_id})
        if cart:
            return cart["id"]
        cart_id = str(uuid.uuid4())
        db.execute("INSERT INTO carts (id, user_id) VALUES (:id, :uid)", {"id": cart_id, "uid": user_id})
        return cart_id

    @classmethod
    def add_item(
        cls,
        user_id: str,
        product_id: str,
        quantity: int = 1,
        variant_id: Optional[str] = None,
        addon_ids: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        cart_id = cls.get_or_create_cart(user_id)
        
        # Verify product availability and stock
        prod = db.query_one("SELECT * FROM products WHERE id = :id AND is_active = 1", {"id": product_id})
        if not prod:
            raise ValueError("Product not available or discontinued.")
        
        if prod["pricing_mode"] == "price_on_demand":
            raise ValueError("Cannot add Price-on-Demand product to cart directly. Please submit an RFQ.")

        if quantity < prod["min_order_quantity"]:
            raise ValueError(f"Minimum order quantity for this item is {prod['min_order_quantity']}.")

        if prod["stock_quantity"] < quantity:
            raise ValueError(f"Insufficient stock. Available: {prod['stock_quantity']}.")

        # Determine unit price using wholesale tiers or retail price
        unit_price_minor = ProductService.calculate_applicable_unit_price(product_id, quantity, variant_id)

        # Check if identical item already in cart
        existing = db.query_one(
            """SELECT id, quantity FROM cart_items 
               WHERE cart_id = :cid AND product_id = :pid AND (variant_id = :vid OR (variant_id IS NULL AND :vid IS NULL))""",
            {"cid": cart_id, "pid": product_id, "vid": variant_id}
        )

        if existing:
            new_qty = existing["quantity"] + quantity
            if prod["stock_quantity"] < new_qty:
                raise ValueError(f"Insufficient stock for requested total quantity ({new_qty}).")
            
            # Recalculate price with updated quantity tier
            updated_unit_price = ProductService.calculate_applicable_unit_price(product_id, new_qty, variant_id)
            db.execute(
                "UPDATE cart_items SET quantity = :q, applied_unit_price_minor = :p WHERE id = :id",
                {"q": new_qty, "p": updated_unit_price, "id": existing["id"]}
            )
            cart_item_id = existing["id"]
        else:
            cart_item_id = str(uuid.uuid4())
            db.execute(
                """INSERT INTO cart_items (id, cart_id, product_id, variant_id, quantity, applied_unit_price_minor)
                   VALUES (:id, :cid, :pid, :vid, :q, :p)""",
                {"id": cart_item_id, "cid": cart_id, "pid": product_id, "vid": variant_id, "q": quantity, "p": unit_price_minor}
            )

        # Attach addons
        if addon_ids:
            for aid in addon_ids:
                addon = db.query_one("SELECT price_minor FROM product_addons WHERE id = :aid", {"aid": aid})
                if addon:
                    db.execute(
                        "INSERT INTO cart_item_addons (id, cart_item_id, addon_id, price_minor) VALUES (:id, :ciid, :aid, :p)",
                        {"id": str(uuid.uuid4()), "ciid": cart_item_id, "aid": aid, "p": addon["price_minor"]}
                    )

        return cls.get_cart_summary(user_id)

    @classmethod
    def update_item_quantity(cls, user_id: str, cart_item_id: str, new_quantity: int) -> Dict[str, Any]:
        cart_id = cls.get_or_create_cart(user_id)
        if new_quantity <= 0:
            db.execute("DELETE FROM cart_item_addons WHERE cart_item_id = :id", {"id": cart_item_id})
            db.execute("DELETE FROM cart_items WHERE id = :id AND cart_id = :cid", {"id": cart_item_id, "cid": cart_id})
            return cls.get_cart_summary(user_id)

        item = db.query_one("SELECT * FROM cart_items WHERE id = :id AND cart_id = :cid", {"id": cart_item_id, "cid": cart_id})
        if not item:
            raise ValueError("Item not found in cart.")

        prod = db.query_one("SELECT stock_quantity, min_order_quantity FROM products WHERE id = :id", {"id": item["product_id"]})
        if new_quantity < prod["min_order_quantity"]:
            raise ValueError(f"Minimum order quantity is {prod['min_order_quantity']}.")
        if new_quantity > prod["stock_quantity"]:
            raise ValueError(f"Insufficient stock. Available: {prod['stock_quantity']}.")

        # Re-evaluate wholesale tier for new quantity
        new_unit_price = ProductService.calculate_applicable_unit_price(item["product_id"], new_quantity, item["variant_id"])

        db.execute(
            "UPDATE cart_items SET quantity = :q, applied_unit_price_minor = :p WHERE id = :id",
            {"q": new_quantity, "p": new_unit_price, "id": cart_item_id}
        )
        return cls.get_cart_summary(user_id)

    @classmethod
    def remove_item(cls, user_id: str, cart_item_id: str) -> Dict[str, Any]:
        cart_id = cls.get_or_create_cart(user_id)
        db.execute("DELETE FROM cart_item_addons WHERE cart_item_id = :id", {"id": cart_item_id})
        db.execute("DELETE FROM cart_items WHERE id = :id AND cart_id = :cid", {"id": cart_item_id, "cid": cart_id})
        return cls.get_cart_summary(user_id)

    @classmethod
    def clear_cart(cls, user_id: str) -> None:
        cart = db.query_one("SELECT id FROM carts WHERE user_id = :uid", {"uid": user_id})
        if cart:
            db.execute(
                "DELETE FROM cart_item_addons WHERE cart_item_id IN (SELECT id FROM cart_items WHERE cart_id = :cid)",
                {"cid": cart["id"]}
            )
            db.execute("DELETE FROM cart_items WHERE cart_id = :cid", {"cid": cart["id"]})

    @classmethod
    def get_cart_summary(cls, user_id: str, coupon_code: Optional[str] = None) -> Dict[str, Any]:
        cart_id = cls.get_or_create_cart(user_id)
        items = db.query(
            """SELECT 
                ci.id AS cart_item_id,
                ci.quantity,
                ci.applied_unit_price_minor,
                p.id AS product_id,
                p.name AS product_name,
                p.unit_of_measure,
                p.primary_image_url,
                p.tax_rate_percent,
                p.stock_quantity,
                p.business_id,
                b.display_name AS business_name,
                b.business_type,
                pv.id AS variant_id,
                pv.variant_name
               FROM cart_items ci
               JOIN products p ON ci.product_id = p.id
               JOIN businesses b ON p.business_id = b.id
               LEFT JOIN product_variants pv ON ci.variant_id = pv.id
               WHERE ci.cart_id = :cid""",
            {"cid": cart_id}
        )

        # Group items by seller (Multi-seller cart support)
        seller_groups: Dict[str, Dict[str, Any]] = {}
        total_items_subtotal = 0
        total_tax = 0
        total_delivery = 0

        for item in items:
            # Load item addons
            addons = db.query(
                """SELECT pa.name, cia.price_minor 
                   FROM cart_item_addons cia 
                   JOIN product_addons pa ON cia.addon_id = pa.id 
                   WHERE cia.cart_item_id = :ciid""",
                {"ciid": item["cart_item_id"]}
            )
            item["addons"] = addons
            addons_total_per_unit = sum(a["price_minor"] for a in addons)
            item_effective_unit_price = item["applied_unit_price_minor"] + addons_total_per_unit
            item_line_total = item_effective_unit_price * item["quantity"]
            item_tax = int(round(item_line_total * (item["tax_rate_percent"] / 100.0)))
            
            item["effective_unit_price_minor"] = item_effective_unit_price
            item["line_total_minor"] = item_line_total
            item["tax_minor"] = item_tax

            bid = item["business_id"]
            if bid not in seller_groups:
                seller_groups[bid] = {
                    "business_id": bid,
                    "business_name": item["business_name"],
                    "business_type": item["business_type"],
                    "items": [],
                    "subtotal_minor": 0,
                    "tax_minor": 0,
                    "delivery_fee_minor": 4000, # ₹40.00 standard delivery per seller
                    "seller_total_minor": 0
                }
            
            seller_groups[bid]["items"].append(item)
            seller_groups[bid]["subtotal_minor"] += item_line_total
            seller_groups[bid]["tax_minor"] += item_tax

        # Free delivery threshold (e.g. ₹500 per seller)
        for bid, grp in seller_groups.items():
            if grp["subtotal_minor"] >= 50000: # ₹500 in paise
                grp["delivery_fee_minor"] = 0
            grp["seller_total_minor"] = grp["subtotal_minor"] + grp["tax_minor"] + grp["delivery_fee_minor"]
            total_items_subtotal += grp["subtotal_minor"]
            total_tax += grp["tax_minor"]
            total_delivery += grp["delivery_fee_minor"]

        discount_minor = 0
        applied_coupon = None
        if coupon_code:
            coupon = db.query_one(
                "SELECT * FROM coupons WHERE code = :c AND is_active = 1 AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)",
                {"c": coupon_code.upper()}
            )
            if coupon and total_items_subtotal >= coupon["min_order_value_minor"]:
                if coupon["discount_type"] == "percentage":
                    discount_minor = int(round(total_items_subtotal * (coupon["discount_value"] / 100.0)))
                    if coupon["max_discount_minor"]:
                        discount_minor = min(discount_minor, coupon["max_discount_minor"])
                else:
                    discount_minor = int(coupon["discount_value"])
                applied_coupon = coupon["code"]

        grand_total = max(0, total_items_subtotal + total_tax + total_delivery - discount_minor)

        return {
            "cart_id": cart_id,
            "total_unique_items": len(items),
            "seller_orders_count": len(seller_groups),
            "sellers": list(seller_groups.values()),
            "items_subtotal_minor": total_items_subtotal,
            "tax_total_minor": total_tax,
            "delivery_fee_total_minor": total_delivery,
            "discount_minor": discount_minor,
            "applied_coupon": applied_coupon,
            "grand_total_minor": grand_total,
            "currency": "INR"
        }
