import uuid
import json
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db

class ProductService:
    @staticmethod
    def create_product(
        business_id: str,
        category_id: str,
        name: str,
        retail_price_minor: int,
        pricing_mode: str = "fixed",
        short_description: Optional[str] = None,
        description: Optional[str] = None,
        brand: Optional[str] = None,
        manufacturer_name: Optional[str] = None,
        sku: Optional[str] = None,
        unit_of_measure: str = "piece",
        package_size: Optional[str] = None,
        min_order_quantity: int = 1,
        stock_quantity: int = 0,
        tax_rate_percent: float = 5.0,
        primary_image_url: Optional[str] = None,
        images: Optional[List[str]] = None,
        is_veg: int = 1,
        variants: Optional[List[Dict[str, Any]]] = None,
        wholesale_tiers: Optional[List[Dict[str, Any]]] = None,
        addon_groups: Optional[List[Dict[str, Any]]] = None,
        product_id: Optional[str] = None
    ) -> Dict[str, Any]:
        # Enforce subscription listing limit
        biz = db.query_one("SELECT * FROM businesses WHERE id = :id", {"id": business_id})
        if not biz:
            raise ValueError("Business not found.")
        
        # Check active product count against subscription limit
        sub = db.query_one(
            """SELECT sp.listing_limit 
               FROM subscriptions s 
               JOIN subscription_plans sp ON s.plan_id = sp.id 
               WHERE s.business_id = :bid AND s.status IN ('active', 'grace_period', 'trial')""",
            {"bid": business_id}
        )
        listing_limit = sub["listing_limit"] if sub else 500 # Default limit
        current_count = db.query_one("SELECT COUNT(*) as count FROM products WHERE business_id = :bid", {"bid": business_id})["count"]
        
        if current_count >= listing_limit:
            raise ValueError(f"Listing limit reached ({listing_limit} products). Please upgrade your subscription plan.")

        pid = product_id or str(uuid.uuid4())
        images_json = json.dumps(images or [])

        db.execute(
            """INSERT INTO products (
                id, business_id, category_id, name, short_description, description,
                brand, manufacturer_name, sku, unit_of_measure, package_size,
                pricing_mode, retail_price_minor, tax_rate_percent, min_order_quantity,
                stock_quantity, is_in_stock, primary_image_url, images_json, is_veg, moderation_status
            ) VALUES (
                :id, :bid, :cat, :name, :short_desc, :desc,
                :brand, :mfr, :sku, :uom, :pkg,
                :mode, :price, :tax, :moq,
                :stock, :in_stock, :img, :imgs, :veg, 'approved'
            )""",
            {
                "id": pid,
                "bid": business_id,
                "cat": category_id,
                "name": name,
                "short_desc": short_description,
                "desc": description,
                "brand": brand,
                "mfr": manufacturer_name,
                "sku": sku,
                "uom": unit_of_measure,
                "pkg": package_size,
                "mode": pricing_mode,
                "price": retail_price_minor,
                "tax": tax_rate_percent,
                "moq": min_order_quantity,
                "stock": stock_quantity,
                "in_stock": 1 if stock_quantity > 0 else 0,
                "img": primary_image_url,
                "imgs": images_json,
                "veg": is_veg
            }
        )

        # Log initial inventory
        if stock_quantity > 0:
            db.execute(
                """INSERT INTO inventory_movements (id, product_id, quantity_change, movement_type, notes)
                   VALUES (:id, :pid, :qty, 'RESTOCK', 'Initial stock on creation')""",
                {"id": str(uuid.uuid4()), "pid": pid, "qty": stock_quantity}
            )

        # Insert Variants
        if variants:
            for v in variants:
                vid = str(uuid.uuid4())
                db.execute(
                    """INSERT INTO product_variants (id, product_id, variant_name, sku, additional_price_minor, retail_price_minor, stock_quantity)
                       VALUES (:id, :pid, :name, :sku, :add_price, :ret_price, :stock)""",
                    {
                        "id": vid,
                        "pid": pid,
                        "name": v["variant_name"],
                        "sku": v.get("sku"),
                        "add_price": v.get("additional_price_minor", 0),
                        "ret_price": v.get("retail_price_minor"),
                        "stock": v.get("stock_quantity", 0)
                    }
                )

        # Insert Wholesale Tiers
        if wholesale_tiers:
            for tier in wholesale_tiers:
                tid = str(uuid.uuid4())
                db.execute(
                    """INSERT INTO wholesale_price_tiers (id, product_id, min_quantity, max_quantity, unit_price_minor, lead_time_days)
                       VALUES (:id, :pid, :min_q, :max_q, :unit_price, :lead)""",
                    {
                        "id": tid,
                        "pid": pid,
                        "min_q": tier["min_quantity"],
                        "max_q": tier.get("max_quantity"),
                        "unit_price": tier["unit_price_minor"],
                        "lead": tier.get("lead_time_days", 3)
                    }
                )

        # Insert Addon Groups & Addons
        if addon_groups:
            for grp in addon_groups:
                gid = str(uuid.uuid4())
                db.execute(
                    """INSERT INTO product_addon_groups (id, product_id, title, is_required, min_selections, max_selections)
                       VALUES (:id, :pid, :title, :req, :min_s, :max_s)""",
                    {
                        "id": gid,
                        "pid": pid,
                        "title": grp["title"],
                        "req": 1 if grp.get("is_required") else 0,
                        "min_s": grp.get("min_selections", 0),
                        "max_s": grp.get("max_selections", 1)
                    }
                )
                for item in grp.get("addons", []):
                    aid = str(uuid.uuid4())
                    db.execute(
                        """INSERT INTO product_addons (id, group_id, name, price_minor, is_available)
                           VALUES (:id, :gid, :name, :price, 1)""",
                        {"id": aid, "gid": gid, "name": item["name"], "price": item.get("price_minor", 0)}
                    )

        return ProductService.get_product_detail(pid)

    @staticmethod
    def get_product_detail(product_id: str) -> Optional[Dict[str, Any]]:
        product = db.query_one(
            """SELECT p.*, b.display_name AS business_name, b.business_type, b.latitude, b.longitude, c.name AS category_name
               FROM products p
               JOIN businesses b ON p.business_id = b.id
               JOIN categories c ON p.category_id = c.id
               WHERE p.id = :id""",
            {"id": product_id}
        )
        if not product:
            return None
        
        # Load variants
        product["variants"] = db.query("SELECT * FROM product_variants WHERE product_id = :pid", {"pid": product_id})
        
        # Load wholesale tiers
        product["wholesale_tiers"] = db.query(
            "SELECT * FROM wholesale_price_tiers WHERE product_id = :pid ORDER BY min_quantity ASC",
            {"pid": product_id}
        )
        
        # Load addon groups with addons
        groups = db.query("SELECT * FROM product_addon_groups WHERE product_id = :pid", {"pid": product_id})
        for grp in groups:
            grp["addons"] = db.query("SELECT * FROM product_addons WHERE group_id = :gid AND is_available = 1", {"gid": grp["id"]})
        product["addon_groups"] = groups
        
        return product

    @staticmethod
    def calculate_applicable_unit_price(product_id: str, quantity: int, variant_id: Optional[str] = None) -> int:
        tier = db.query_one(
            """SELECT unit_price_minor FROM wholesale_price_tiers
               WHERE product_id = :pid AND min_quantity <= :qty 
                 AND (max_quantity IS NULL OR max_quantity >= :qty)
               ORDER BY min_quantity DESC LIMIT 1""",
            {"pid": product_id, "qty": quantity}
        )
        if tier:
            return tier["unit_price_minor"]

        prod = db.query_one("SELECT retail_price_minor, pricing_mode FROM products WHERE id = :id", {"id": product_id})
        if not prod:
            raise ValueError("Product not found.")
        
        if prod["pricing_mode"] == "price_on_demand":
            raise ValueError("This product is Price on Demand. Please submit a Request for Quotation.")

        base_price = prod["retail_price_minor"]

        if variant_id:
            variant = db.query_one("SELECT additional_price_minor, retail_price_minor FROM product_variants WHERE id = :vid", {"vid": variant_id})
            if variant:
                if variant["retail_price_minor"] is not None:
                    return variant["retail_price_minor"]
                base_price += variant.get("additional_price_minor", 0)

        return base_price
