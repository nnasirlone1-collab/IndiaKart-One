import uuid
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db

class MessagingService:
    @staticmethod
    def get_or_create_conversation(user_1: str, user_2: str, conversation_type: str = "direct", reference_id: Optional[str] = None) -> str:
        """Finds or creates a conversation between two users."""
        conv = db.query_one(
            """SELECT c.id FROM conversations c
               JOIN conversation_participants cp1 ON c.id = cp1.conversation_id AND cp1.user_id = :u1
               JOIN conversation_participants cp2 ON c.id = cp2.conversation_id AND cp2.user_id = :u2
               WHERE c.conversation_type = :ctype LIMIT 1""",
            {"u1": user_1, "u2": user_2, "ctype": conversation_type}
        )
        if conv:
            return conv["id"]

        conv_id = str(uuid.uuid4())
        db.execute(
            "INSERT INTO conversations (id, conversation_type, reference_id) VALUES (:id, :ctype, :ref)",
            {"id": conv_id, "ctype": conversation_type, "ref": reference_id}
        )
        for u in [user_1, user_2]:
            db.execute(
                "INSERT INTO conversation_participants (id, conversation_id, user_id) VALUES (:id, :cid, :uid)",
                {"id": str(uuid.uuid4()), "cid": conv_id, "uid": u}
            )
        return conv_id

    @staticmethod
    def send_message(conversation_id: str, sender_id: str, content: str, attachment_url: Optional[str] = None) -> Dict[str, Any]:
        # Verify sender is participant
        participant = db.query_one(
            "SELECT id FROM conversation_participants WHERE conversation_id = :cid AND user_id = :uid",
            {"cid": conversation_id, "uid": sender_id}
        )
        if not participant:
            raise ValueError("Sender is not a participant in this conversation.")

        msg_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO messages (id, conversation_id, sender_id, content, attachment_url)
               VALUES (:id, :cid, :sid, :content, :att)""",
            {"id": msg_id, "cid": conversation_id, "sid": sender_id, "content": content, "att": attachment_url}
        )

        # Notify recipient
        other_participants = db.query(
            "SELECT user_id FROM conversation_participants WHERE conversation_id = :cid AND user_id != :sid",
            {"cid": conversation_id, "sid": sender_id}
        )
        for p in other_participants:
            db.execute(
                """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
                   VALUES (:nid, :uid, 'New Message', SUBSTR(:content, 1, 60), 'ORDER_UPDATE', :cid)""",
                {"nid": str(uuid.uuid4()), "uid": p["user_id"], "content": content, "cid": conversation_id}
            )

        return db.query_one("SELECT * FROM messages WHERE id = :id", {"id": msg_id})

    @staticmethod
    def get_messages(conversation_id: str, user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        # Verify participant
        participant = db.query_one(
            "SELECT id FROM conversation_participants WHERE conversation_id = :cid AND user_id = :uid",
            {"cid": conversation_id, "uid": user_id}
        )
        if not participant:
            raise ValueError("Unauthorized to access this conversation.")

        return db.query(
            """SELECT m.*, u.full_name AS sender_name 
               FROM messages m 
               JOIN users u ON m.sender_id = u.id 
               WHERE m.conversation_id = :cid 
               ORDER BY m.created_at ASC LIMIT :lim""",
            {"cid": conversation_id, "lim": limit}
        )
