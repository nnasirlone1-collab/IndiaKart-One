import uuid
import time
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db

class RFQService:
    @staticmethod
    def create_rfq(
        buyer_id: str,
        product_name: str,
        required_quantity: int,
        unit_of_measure: str,
        delivery_pincode: str,
        delivery_city: str,
        category_id: Optional[str] = None,
        specifications: Optional[str] = None,
        target_price_minor: Optional[int] = None,
        required_date: Optional[str] = None,
        customization_details: Optional[str] = None
    ) -> Dict[str, Any]:
        """Creates a B2B Buying Requirement (RFQ) and notifies matching suppliers."""
        rfq_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO buying_requirements (
                id, buyer_id, category_id, product_name, specifications,
                required_quantity, unit_of_measure, target_price_minor,
                delivery_pincode, delivery_city, required_date, customization_details, status
            ) VALUES (
                :id, :bid, :cat, :pname, :specs,
                :qty, :uom, :tprice,
                :pin, :city, :rdate, :cust, 'open'
            )""",
            {
                "id": rfq_id,
                "bid": buyer_id,
                "cat": category_id,
                "pname": product_name,
                "specs": specifications,
                "qty": required_quantity,
                "uom": unit_of_measure,
                "tprice": target_price_minor,
                "pin": delivery_pincode,
                "city": delivery_city,
                "rdate": required_date,
                "cust": customization_details
            }
        )

        # Notify matching suppliers
        suppliers = db.query(
            """SELECT b.id, b.owner_id, b.display_name 
               FROM businesses b
               WHERE b.verification_status = 'approved' 
                 AND b.business_type IN ('manufacturer', 'wholesaler', 'distributor')
                 AND (:cat IS NULL OR b.category_id = :cat)""",
            {"cat": category_id}
        )

        for s in suppliers:
            db.execute(
                """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
                   VALUES (:nid, :uid, 'New Sourcing Opportunity', 'RFQ for ' || :pname || ' (' || :qty || ' ' || :uom || ') received.', 'RFQ_RECEIVED', :rfq_id)""",
                {
                    "nid": str(uuid.uuid4()),
                    "uid": s["owner_id"],
                    "pname": product_name,
                    "qty": required_quantity,
                    "uom": unit_of_measure,
                    "rfq_id": rfq_id
                }
            )

        return db.query_one("SELECT * FROM buying_requirements WHERE id = :id", {"id": rfq_id})

    @staticmethod
    def submit_quotation(
        rfq_id: str,
        supplier_id: str,
        unit_price_minor: int,
        tax_rate_percent: float = 18.0,
        packaging_costs_minor: int = 0,
        shipping_costs_minor: int = 0,
        production_lead_time_days: int = 7,
        payment_terms: str = "30% Advance, 70% Before Dispatch",
        validity_days: int = 14,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """Submits or updates a quotation for an RFQ, preserving revision history."""
        rfq = db.query_one("SELECT * FROM buying_requirements WHERE id = :id", {"id": rfq_id})
        if not rfq:
            raise ValueError("RFQ not found.")

        # Check existing quotations from this supplier to increment revision number
        existing = db.query_one(
            "SELECT id, revision_number FROM quotations WHERE rfq_id = :rid AND supplier_id = :sid ORDER BY revision_number DESC LIMIT 1",
            {"rid": rfq_id, "sid": supplier_id}
        )
        
        rev_num = (existing["revision_number"] + 1) if existing else 1
        subtotal = unit_price_minor * rfq["required_quantity"]
        tax = int(round(subtotal * (tax_rate_percent / 100.0)))
        grand_total = subtotal + tax + packaging_costs_minor + shipping_costs_minor

        quote_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO quotations (
                id, rfq_id, supplier_id, revision_number, unit_price_minor, total_price_minor,
                tax_rate_percent, packaging_costs_minor, shipping_costs_minor,
                production_lead_time_days, payment_terms, validity_days, notes, status
            ) VALUES (
                :id, :rid, :sid, :rev, :uprice, :tot,
                :tax_r, :pack, :ship,
                :lead, :terms, :val, :notes, 'submitted'
            )""",
            {
                "id": quote_id,
                "rid": rfq_id,
                "sid": supplier_id,
                "rev": rev_num,
                "uprice": unit_price_minor,
                "tot": grand_total,
                "tax_r": tax_rate_percent,
                "pack": packaging_costs_minor,
                "ship": shipping_costs_minor,
                "lead": production_lead_time_days,
                "terms": payment_terms,
                "val": validity_days,
                "notes": notes
            }
        )

        db.execute("UPDATE buying_requirements SET status = 'quotes_received' WHERE id = :id", {"id": rfq_id})

        # Notify buyer
        db.execute(
            """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
               VALUES (:nid, :uid, 'New Quotation Received', 'Supplier has submitted a quotation for your RFQ.', 'QUOTE_RECEIVED', :qid)""",
            {"nid": str(uuid.uuid4()), "uid": rfq["buyer_id"], "qid": quote_id}
        )

        return db.query_one("SELECT * FROM quotations WHERE id = :id", {"id": quote_id})

    @staticmethod
    def accept_quotation_and_convert_to_order(quotation_id: str, buyer_id: str) -> Dict[str, Any]:
        """Converts an accepted B2B quotation directly into a confirmed wholesale order."""
        quote = db.query_one("SELECT * FROM quotations WHERE id = :id", {"id": quotation_id})
        if not quote:
            raise ValueError("Quotation not found.")

        rfq = db.query_one("SELECT * FROM buying_requirements WHERE id = :id", {"id": quote["rfq_id"]})
        if not rfq or rfq["buyer_id"] != buyer_id:
            raise ValueError("Unauthorized to accept this quotation.")

        # Ensure custom B2B reference product exists for this supplier
        custom_prod_id = f"b2b-prod-{quote['supplier_id']}"
        existing_prod = db.query_one("SELECT id FROM products WHERE id = :id", {"id": custom_prod_id})
        if not existing_prod:
            cat_id = rfq.get("category_id") or "cat-industrial-supplies"
            db.execute(
                """INSERT OR IGNORE INTO products (
                    id, business_id, category_id, name, retail_price_minor, pricing_mode, moderation_status
                ) VALUES (
                    :id, :bid, :cat, :name, 0, 'price_on_demand', 'approved'
                )""",
                {
                    "id": custom_prod_id,
                    "bid": quote["supplier_id"],
                    "cat": cat_id,
                    "name": f"Custom Manufacturing: {rfq['product_name'][:50]}"
                }
            )

        # Mark quotation accepted
        order_id = str(uuid.uuid4())
        order_number = f"IKO-B2B-{int(time.time())}-{str(uuid.uuid4())[:6].upper()}"

        db.execute(
            """INSERT INTO orders (
                id, order_number, buyer_id, business_id, order_type,
                order_status, payment_status, items_subtotal_minor, tax_total_minor,
                delivery_fee_minor, grand_total_minor, currency, fulfilment_type, special_instructions
            ) VALUES (
                :id, :onum, :bid, :sid, 'wholesale',
                'confirmed', 'unpaid', :sub, :tax,
                :del_fee, :grand, 'INR', 'freight', :terms
            )""",
            {
                "id": order_id,
                "onum": order_number,
                "bid": buyer_id,
                "sid": quote["supplier_id"],
                "sub": quote["unit_price_minor"] * rfq["required_quantity"],
                "tax": int(round((quote["unit_price_minor"] * rfq["required_quantity"]) * (quote["tax_rate_percent"] / 100.0))),
                "del_fee": quote["shipping_costs_minor"],
                "grand": quote["total_price_minor"],
                "terms": f"Payment Terms: {quote['payment_terms']}. Lead time: {quote['production_lead_time_days']} days."
            }
        )

        # Insert B2B order item referencing the verified custom product
        oi_id = str(uuid.uuid4())
        db.execute(
            """INSERT INTO order_items (
                id, order_id, product_id, product_name, quantity, unit_price_minor, total_price_minor, tax_rate_percent
            ) VALUES (
                :id, :oid, :pid, :pname, :qty, :uprice, :tot, :tax_r
            )""",
            {
                "id": oi_id,
                "oid": order_id,
                "pid": custom_prod_id,
                "pname": f"B2B Wholesale: {rfq['product_name']}",
                "qty": rfq["required_quantity"],
                "uprice": quote["unit_price_minor"],
                "tot": quote["total_price_minor"],
                "tax_r": quote["tax_rate_percent"]
            }
        )

        db.execute(
            "UPDATE quotations SET status = 'accepted', resulting_order_id = :oid, updated_at = CURRENT_TIMESTAMP WHERE id = :qid",
            {"oid": order_id, "qid": quotation_id}
        )
        db.execute("UPDATE buying_requirements SET status = 'accepted' WHERE id = :rid", {"rid": rfq["id"]})

        # History log
        db.execute(
            """INSERT INTO order_status_history (id, order_id, status, notes, changed_by_user_id)
               VALUES (:id, :oid, 'confirmed', 'Order created from accepted quotation ' || :qid, :uid)""",
            {"id": str(uuid.uuid4()), "oid": order_id, "qid": quotation_id, "uid": buyer_id}
        )

        return db.query_one("SELECT * FROM orders WHERE id = :id", {"id": order_id})
