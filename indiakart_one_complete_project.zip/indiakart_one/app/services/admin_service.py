import uuid
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db

class AdminService:
    @staticmethod
    def get_platform_metrics() -> Dict[str, Any]:
        """Calculates live platform KPIs from actual database records."""
        total_users = db.query_one("SELECT COUNT(*) as c FROM users")["c"]
        buyers_count = db.query_one("SELECT COUNT(DISTINCT user_id) as c FROM user_roles WHERE role = 'buyer'")["c"]
        sellers_count = db.query_one("SELECT COUNT(DISTINCT user_id) as c FROM user_roles WHERE role != 'buyer' AND role NOT IN ('admin', 'super_admin')")["c"]
        approved_businesses = db.query_one("SELECT COUNT(*) as c FROM businesses WHERE verification_status = 'approved'")["c"]
        pending_verifications = db.query_one("SELECT COUNT(*) as c FROM businesses WHERE verification_status = 'pending'")["c"]
        
        # Order KPIs
        orders_stat = db.query_one(
            """SELECT 
                COUNT(*) as total_orders,
                COALESCE(SUM(grand_total_minor), 0) as gmv_minor
               FROM orders"""
        )
        total_orders = orders_stat["total_orders"]
        gmv_minor = orders_stat["gmv_minor"]
        
        # Commission KPI
        comm_stat = db.query_one("SELECT COALESCE(SUM(commission_amount_minor), 0) as total_comm FROM commission_records")
        commission_minor = comm_stat["total_comm"]
        
        # Subscriptions
        active_subs = db.query_one("SELECT COUNT(*) as c FROM subscriptions WHERE status = 'active'")["c"]

        return {
            "total_users": total_users,
            "buyers_count": buyers_count,
            "sellers_count": sellers_count,
            "approved_businesses": approved_businesses,
            "pending_verifications": pending_verifications,
            "total_orders": total_orders,
            "gmv_inr": round(gmv_minor / 100.0, 2),
            "commission_inr": round(commission_minor / 100.0, 2),
            "active_subscriptions": active_subs,
            "currency": "INR"
        }

    @staticmethod
    def review_seller_application(business_id: str, action: str, admin_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        biz = db.query_one("SELECT * FROM businesses WHERE id = :id", {"id": business_id})
        if not biz:
            raise ValueError("Business not found.")

        old_status = biz["verification_status"]

        if action == "approve":
            new_status = "approved"
            db.execute(
                "UPDATE businesses SET verification_status = 'approved', rejection_reason = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = :id",
                {"id": business_id}
            )
            # Add role to owner
            role_to_add = biz["business_type"]
            db.execute(
                "INSERT OR IGNORE INTO user_roles (id, user_id, role) VALUES (:id, :uid, :r)",
                {"id": str(uuid.uuid4()), "uid": biz["owner_id"], "r": role_to_add}
            )
            db.execute(
                "INSERT OR IGNORE INTO user_roles (id, user_id, role) VALUES (:id, :uid, 'seller')",
                {"id": str(uuid.uuid4()), "uid": biz["owner_id"]}
            )
            # Notification to seller
            db.execute(
                """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
                   VALUES (:nid, :uid, 'Seller Application Approved!', 'Congratulations! Your business profile is now live on IndiaKart One.', 'ORDER_UPDATE', :bid)""",
                {"nid": str(uuid.uuid4()), "uid": biz["owner_id"], "bid": business_id}
            )

        elif action == "reject":
            new_status = "rejected"
            db.execute(
                "UPDATE businesses SET verification_status = 'rejected', rejection_reason = :reason, updated_at = CURRENT_TIMESTAMP WHERE id = :id",
                {"reason": reason or "Verification requirements not met.", "id": business_id}
            )
            db.execute(
                """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
                   VALUES (:nid, :uid, 'Seller Application Status', 'Your application was rejected: ' || :reason, 'ORDER_UPDATE', :bid)""",
                {"nid": str(uuid.uuid4()), "uid": biz["owner_id"], "reason": reason or "Verification requirements not met.", "bid": business_id}
            )

        elif action == "request_documents":
            new_status = "documents_required"
            db.execute(
                "UPDATE businesses SET verification_status = 'documents_required', rejection_reason = :reason, updated_at = CURRENT_TIMESTAMP WHERE id = :id",
                {"reason": reason or "Additional documents needed.", "id": business_id}
            )
        else:
            raise ValueError(f"Unknown action '{action}'. Valid actions: approve, reject, request_documents.")

        # Record in admin audit log
        db.execute(
            """INSERT INTO admin_audit_logs (id, admin_id, action_type, entity_type, entity_id, old_value, new_value)
               VALUES (:id, :aid, 'SELLER_REVIEW', 'business', :bid, :old, :new)""",
            {
                "id": str(uuid.uuid4()),
                "aid": admin_id,
                "bid": business_id,
                "old": old_status,
                "new": f"{new_status} (Reason: {reason})"
            }
        )

        return db.query_one("SELECT * FROM businesses WHERE id = :id", {"id": business_id})

    @staticmethod
    def get_audit_logs(limit: int = 100) -> List[Dict[str, Any]]:
        return db.query(
            """SELECT a.*, u.full_name AS admin_name, u.email AS admin_email
               FROM admin_audit_logs a
               JOIN users u ON a.admin_id = u.id
               ORDER BY a.created_at DESC LIMIT :lim""",
            {"lim": limit}
        )
