import uuid
import json
import time
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db
from indiakart_one.app.services.cart_service import CartService
from indiakart_one.app.config import settings

class OrderService:
    @classmethod
    def checkout(
        cls,
        user_id: str,
        shipping_address_id: str,
        fulfilment_type: str = "delivery",
        coupon_code: Optional[str] = None,
        special_instructions: Optional[str] = None,
        idempotency_key: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Executes atomic checkout. Groups cart items by seller into distinct seller orders.
        Validates inventory in real-time, deducts stock, and records initial history.
        """
        if idempotency_key:
            # Check for existing orders created with this key or prefix
            existing = db.query(
                "SELECT * FROM orders WHERE idempotency_key = :key OR idempotency_key LIKE :prefix",
                {"key": idempotency_key, "prefix": f"{idempotency_key}%"}
            )
            if existing:
                return existing

        cart_summary = CartService.get_cart_summary(user_id, coupon_code)
        if not cart_summary["sellers"]:
            raise ValueError("Your cart is empty.")

        address = db.query_one("SELECT * FROM addresses WHERE id = :aid AND user_id = :uid", {"aid": shipping_address_id, "uid": user_id})
        if not address:
            raise ValueError("Invalid shipping address selected.")
        address_snapshot = json.dumps(address)

        created_orders = []

        # Validate stock for all items first before any state modification
        for seller in cart_summary["sellers"]:
            for item in seller["items"]:
                prod = db.query_one("SELECT stock_quantity, name FROM products WHERE id = :pid", {"pid": item["product_id"]})
                if not prod or prod["stock_quantity"] < item["quantity"]:
                    raise ValueError(f"Stock unavailable for '{item['product_name']}'. Only {prod['stock_quantity'] if prod else 0} left.")

        # Create distinct order per seller
        for idx, seller in enumerate(cart_summary["sellers"]):
            order_id = str(uuid.uuid4())
            order_number = f"IKO-{int(time.time())}-{str(uuid.uuid4())[:6].upper()}"
            sub_idempotency = f"{idempotency_key}_{seller['business_id']}" if idempotency_key else None

            # Calculate proportional coupon discount if applied
            seller_items_subtotal = seller["subtotal_minor"]
            seller_tax = seller["tax_minor"]
            seller_delivery = seller["delivery_fee_minor"]
            
            # Prorate discount across sellers
            seller_discount = 0
            if cart_summary["discount_minor"] > 0 and cart_summary["items_subtotal_minor"] > 0:
                seller_discount = int(round(cart_summary["discount_minor"] * (seller_items_subtotal / cart_summary["items_subtotal_minor"])))
            
            seller_grand_total = max(0, seller_items_subtotal + seller_tax + seller_delivery - seller_discount)

            # Insert order
            db.execute(
                """INSERT INTO orders (
                    id, order_number, buyer_id, business_id, order_type,
                    order_status, payment_status, items_subtotal_minor, tax_total_minor,
                    delivery_fee_minor, discount_total_minor, grand_total_minor,
                    currency, shipping_address_id, shipping_address_snapshot,
                    fulfilment_type, special_instructions, idempotency_key
                ) VALUES (
                    :id, :num, :bid, :biz_id, :type,
                    'pending_confirmation', 'unpaid', :sub, :tax,
                    :del_fee, :disc, :grand,
                    'INR', :aid, :asnapshot,
                    :fulf, :instr, :ikey
                )""",
                {
                    "id": order_id,
                    "num": order_number,
                    "bid": user_id,
                    "biz_id": seller["business_id"],
                    "type": "food" if seller["business_type"] == "restaurant" else "retail",
                    "sub": seller_items_subtotal,
                    "tax": seller_tax,
                    "del_fee": seller_delivery,
                    "disc": seller_discount,
                    "grand": seller_grand_total,
                    "aid": shipping_address_id,
                    "asnapshot": address_snapshot,
                    "fulf": fulfilment_type,
                    "instr": special_instructions,
                    "ikey": sub_idempotency
                }
            )

            # Insert order items and deduct inventory
            for item in seller["items"]:
                oi_id = str(uuid.uuid4())
                addons_json = json.dumps(item.get("addons", []))
                db.execute(
                    """INSERT INTO order_items (
                        id, order_id, product_id, variant_id, product_name, variant_name,
                        quantity, unit_price_minor, total_price_minor, tax_rate_percent,
                        tax_minor, selected_addons_json
                    ) VALUES (
                        :id, :oid, :pid, :vid, :pname, :vname,
                        :qty, :uprice, :tot, :tax_rate,
                        :tax_m, :addons
                    )""",
                    {
                        "id": oi_id,
                        "oid": order_id,
                        "pid": item["product_id"],
                        "vid": item.get("variant_id"),
                        "pname": item["product_name"],
                        "vname": item.get("variant_name"),
                        "qty": item["quantity"],
                        "uprice": item["effective_unit_price_minor"],
                        "tot": item["line_total_minor"],
                        "tax_rate": item["tax_rate_percent"],
                        "tax_m": item["tax_minor"],
                        "addons": addons_json
                    }
                )

                # Deduct inventory & record movement
                db.execute(
                    "UPDATE products SET stock_quantity = stock_quantity - :q WHERE id = :pid",
                    {"q": item["quantity"], "pid": item["product_id"]}
                )
                db.execute(
                    """INSERT INTO inventory_movements (id, product_id, variant_id, quantity_change, movement_type, reference_id, notes)
                       VALUES (:id, :pid, :vid, :q_change, 'ORDER_FULFILLED', :ref, 'Order placed')""",
                    {
                        "id": str(uuid.uuid4()),
                        "pid": item["product_id"],
                        "vid": item.get("variant_id"),
                        "q_change": -item["quantity"],
                        "ref": order_id
                    }
                )

            # Record initial order status history
            db.execute(
                """INSERT INTO order_status_history (id, order_id, status, notes, changed_by_user_id)
                   VALUES (:id, :oid, 'pending_confirmation', 'Order placed by customer', :uid)""",
                {"id": str(uuid.uuid4()), "oid": order_id, "uid": user_id}
            )

            # Create commission calculation record (e.g. 5% platform fee)
            commission_rate = settings.DEFAULT_COMMISSION_PERCENT
            commission_minor = int(round(seller_grand_total * (commission_rate / 100.0)))
            seller_payout_minor = seller_grand_total - commission_minor
            
            db.execute(
                """INSERT INTO commission_records (
                    id, order_id, business_id, order_total_minor, commission_rate_percent,
                    commission_amount_minor, seller_payout_minor, settlement_status
                ) VALUES (
                    :id, :oid, :biz_id, :tot, :crate, :camt, :payout, 'pending'
                )""",
                {
                    "id": str(uuid.uuid4()),
                    "oid": order_id,
                    "biz_id": seller["business_id"],
                    "tot": seller_grand_total,
                    "crate": commission_rate,
                    "camt": commission_minor,
                    "payout": seller_payout_minor
                }
            )

            # Notification for seller
            db.execute(
                """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
                   SELECT :nid, owner_id, 'New Order Received', 'You have a new order: ' || :onum, 'ORDER_UPDATE', :oid
                   FROM businesses WHERE id = :bid""",
                {
                    "nid": str(uuid.uuid4()),
                    "onum": order_number,
                    "oid": order_id,
                    "bid": seller["business_id"]
                }
            )

            created_orders.append(db.query_one("SELECT * FROM orders WHERE id = :id", {"id": order_id}))

        # Clear cart on successful checkout
        CartService.clear_cart(user_id)

        return created_orders

    @classmethod
    def update_order_status(cls, order_id: str, new_status: str, user_id: str, notes: Optional[str] = None) -> Dict[str, Any]:
        valid_transitions = [
            "pending_confirmation", "confirmed", "processing",
            "ready_for_pickup", "out_for_delivery", "delivered", "completed", "cancelled"
        ]
        if new_status not in valid_transitions:
            raise ValueError(f"Invalid order status '{new_status}'.")

        order = db.query_one("SELECT * FROM orders WHERE id = :id", {"id": order_id})
        if not order:
            raise ValueError("Order not found.")

        # Check permissions: user must be seller or admin or buyer (for cancellation)
        biz = db.query_one("SELECT owner_id FROM businesses WHERE id = :bid", {"bid": order["business_id"]})
        is_seller = biz and biz["owner_id"] == user_id
        is_buyer = order["buyer_id"] == user_id
        user_roles = [r["role"] for r in db.query("SELECT role FROM user_roles WHERE user_id = :uid", {"uid": user_id})]
        is_admin = "admin" in user_roles or "super_admin" in user_roles

        if not (is_seller or is_admin or (is_buyer and new_status == "cancelled")):
            raise ValueError("Unauthorized to update order status.")

        db.execute(
            "UPDATE orders SET order_status = :st, updated_at = CURRENT_TIMESTAMP WHERE id = :id",
            {"st": new_status, "id": order_id}
        )

        db.execute(
            """INSERT INTO order_status_history (id, order_id, status, notes, changed_by_user_id)
               VALUES (:id, :oid, :st, :notes, :uid)""",
            {"id": str(uuid.uuid4()), "oid": order_id, "st": new_status, "notes": notes or f"Status changed to {new_status}", "uid": user_id}
        )

        # Notify buyer
        db.execute(
            """INSERT INTO notifications (id, user_id, title, body, notification_type, reference_id)
               VALUES (:nid, :uid, 'Order Status Updated', 'Your order is now ' || :st, 'ORDER_UPDATE', :oid)""",
            {"nid": str(uuid.uuid4()), "uid": order["buyer_id"], "st": new_status.replace('_', ' ').capitalize(), "oid": order_id}
        )

        return db.query_one("SELECT * FROM orders WHERE id = :id", {"id": order_id})
