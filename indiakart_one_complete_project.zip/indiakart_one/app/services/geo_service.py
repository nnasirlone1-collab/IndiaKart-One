import math
from typing import List, Dict, Any, Optional
from indiakart_one.app.database import db, haversine_distance_km
from indiakart_one.app.config import settings

class GeoService:
    ROAD_NETWORK_FACTOR = 1.30 # Empirical road curvature factor in Indian cities

    @classmethod
    def calculate_distance(cls, lat1: float, lon1: float, lat2: float, lon2: float) -> Dict[str, Any]:
        """Calculates both straight-line (Euclidean/spherical) distance and estimated road distance."""
        straight_km = haversine_distance_km(lat1, lon1, lat2, lon2)
        # Estimated road distance accounts for urban grid layout and road infrastructure
        estimated_road_km = round(straight_km * cls.ROAD_NETWORK_FACTOR, 2)
        
        # Estimate delivery time based on average speed of 25 km/h in Indian cities + 15 min preparation
        est_transit_minutes = int(round((estimated_road_km / 25.0) * 60))
        
        return {
            "straight_line_distance_km": straight_km,
            "estimated_road_distance_km": estimated_road_km,
            "estimated_transit_minutes": est_transit_minutes,
            "distance_type": "estimated_road_distance"
        }

    @classmethod
    def find_nearby_businesses(
        cls,
        user_lat: float,
        user_lon: float,
        business_type: Optional[str] = None,
        category_id: Optional[str] = None,
        max_radius_km: float = 30.0,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Server-side geospatial query finding verified, active businesses within distance and service radius.
        Uses SQLite's custom haversine_distance_km function.
        """
        sql = """
            SELECT 
                b.*,
                haversine_distance_km(b.latitude, b.longitude, :ulat, :ulon) AS distance_km
            FROM businesses b
            WHERE b.verification_status = 'approved'
              AND b.is_open = 1
              AND haversine_distance_km(b.latitude, b.longitude, :ulat, :ulon) <= :max_radius
              AND haversine_distance_km(b.latitude, b.longitude, :ulat, :ulon) <= b.service_radius_km
        """
        params: Dict[str, Any] = {
            "ulat": user_lat,
            "ulon": user_lon,
            "max_radius": max_radius_km
        }
        
        if business_type:
            sql += " AND b.business_type = :btype"
            params["btype"] = business_type
            
        if category_id:
            sql += " AND b.category_id = :cat_id"
            params["cat_id"] = category_id
            
        sql += " ORDER BY distance_km ASC LIMIT :lim"
        params["lim"] = limit
        
        results = db.query(sql, params)
        for row in results:
            dist_info = cls.calculate_distance(user_lat, user_lon, row["latitude"], row["longitude"])
            row["straight_line_distance_km"] = dist_info["straight_line_distance_km"]
            row["estimated_road_distance_km"] = dist_info["estimated_road_distance_km"]
            row["estimated_delivery_minutes"] = dist_info["estimated_transit_minutes"] + 20
        return results

    @classmethod
    def is_within_service_area(cls, business_id: str, user_lat: float, user_lon: float) -> bool:
        """Verifies if customer's delivery location is within business's operational radius."""
        biz = db.query_one("SELECT latitude, longitude, service_radius_km FROM businesses WHERE id = :id", {"id": business_id})
        if not biz:
            return False
        dist = haversine_distance_km(user_lat, user_lon, biz["latitude"], biz["longitude"])
        return dist <= biz["service_radius_km"]
