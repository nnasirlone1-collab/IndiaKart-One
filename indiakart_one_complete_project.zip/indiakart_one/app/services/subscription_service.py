import uuid
import datetime
from typing import Dict, Any, List, Optional
from indiakart_one.app.database import db
from indiakart_one.app.config import settings

class SubscriptionService:
    @staticmethod
    def ensure_default_plan() -> None:
        """Ensures the IndiaKart Business Pro plan exists in database with ₹1,499.00 default."""
        plan = db.query_one("SELECT * FROM subscription_plans WHERE plan_code = 'BUSINESS_PRO'")
        if not plan:
            plan_id = str(uuid.uuid4())
            db.execute(
                """INSERT INTO subscription_plans (
                    id, plan_code, name, description, monthly_price_minor, annual_price_minor,
                    currency, gst_percent, listing_limit, rfq_access, verified_badge_eligible, analytics_tier
                ) VALUES (
                    :id, 'BUSINESS_PRO', 'IndiaKart Business Pro',
                    'Comprehensive growth plan with 500 product listings, RFQ sourcing access, verified badge eligibility, and advanced seller analytics.',
                    :m_price, :a_price, 'INR', 18.0, 500, 1, 1, 'pro'
                )""",
                {
                    "id": plan_id,
                    "m_price": settings.DEFAULT_SUBSCRIPTION_MONTHLY_PRICE_PAISE,
                    "a_price": settings.DEFAULT_SUBSCRIPTION_MONTHLY_PRICE_PAISE * 10
                }
            )

    @classmethod
    def get_plans(cls) -> List[Dict[str, Any]]:
        cls.ensure_default_plan()
        plans = db.query("SELECT * FROM subscription_plans WHERE is_active = 1")
        for p in plans:
            monthly_inr = round(p["monthly_price_minor"] / 100.0, 2)
            gst_amount_inr = round(monthly_inr * (p["gst_percent"] / 100.0), 2)
            p["monthly_price_inr"] = monthly_inr
            p["gst_amount_inr"] = gst_amount_inr
            p["total_payable_inr"] = monthly_inr + gst_amount_inr
        return plans

    @classmethod
    def update_plan_price(
        cls,
        plan_id: str,
        new_monthly_price_minor: int,
        admin_user_id: str,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Allows authorized administrator to update subscription price in database.
        Logs change to admin audit trail.
        """
        old_plan = db.query_one("SELECT * FROM subscription_plans WHERE id = :id", {"id": plan_id})
        if not old_plan:
            raise ValueError("Subscription plan not found.")

        if new_monthly_price_minor <= 0:
            raise ValueError("Price must be greater than zero.")

        old_price = old_plan["monthly_price_minor"]

        db.execute(
            """UPDATE subscription_plans 
               SET monthly_price_minor = :price, updated_at = CURRENT_TIMESTAMP
               WHERE id = :id""",
            {"price": new_monthly_price_minor, "id": plan_id}
        )

        # Audit log
        db.execute(
            """INSERT INTO admin_audit_logs (
                id, admin_id, action_type, entity_type, entity_id, old_value, new_value
            ) VALUES (
                :id, :aid, 'SUBSCRIPTION_PRICE_UPDATE', 'subscription_plan', :pid, :old, :new
            )""",
            {
                "id": str(uuid.uuid4()),
                "aid": admin_user_id,
                "pid": plan_id,
                "old": f"₹{round(old_price / 100.0, 2)}",
                "new": f"₹{round(new_monthly_price_minor / 100.0, 2)} ({notes or 'Updated by admin'})"
            }
        )

        return db.query_one("SELECT * FROM subscription_plans WHERE id = :id", {"id": plan_id})

    @classmethod
    def subscribe_business(cls, business_id: str, plan_id: str) -> Dict[str, Any]:
        """Initiates subscription for an approved business and returns payment intent info."""
        biz = db.query_one("SELECT * FROM businesses WHERE id = :bid", {"bid": business_id})
        if not biz:
            raise ValueError("Business not found.")

        plan = db.query_one("SELECT * FROM subscription_plans WHERE id = :pid", {"pid": plan_id})
        if not plan:
            raise ValueError("Plan not found.")

        # Calculate GST
        subtotal = plan["monthly_price_minor"]
        gst = int(round(subtotal * (plan["gst_percent"] / 100.0)))
        total_payable = subtotal + gst

        sub_id = str(uuid.uuid4())
        now = datetime.datetime.utcnow()
        period_end = now + datetime.timedelta(days=30)
        grace_end = period_end + datetime.timedelta(days=7)

        db.execute(
            """INSERT INTO subscriptions (
                id, business_id, plan_id, status, current_period_start, current_period_end, grace_period_end
            ) VALUES (
                :id, :bid, :pid, 'active', :start, :end, :grace
            )""",
            {
                "id": sub_id,
                "bid": business_id,
                "pid": plan_id,
                "start": now.isoformat(),
                "end": period_end.isoformat(),
                "grace": grace_end.isoformat()
            }
        )

        db.execute("UPDATE businesses SET subscription_active = 1 WHERE id = :bid", {"bid": business_id})

        return {
            "subscription_id": sub_id,
            "business_id": business_id,
            "plan_name": plan["name"],
            "subtotal_minor": subtotal,
            "gst_minor": gst,
            "total_payable_minor": total_payable,
            "currency": "INR",
            "status": "active"
        }

    @staticmethod
    def activate_subscription(subscription_id: str, payment_intent_id: str) -> None:
        db.execute(
            """UPDATE subscriptions 
               SET status = 'active', last_payment_intent_id = :pid, updated_at = CURRENT_TIMESTAMP
               WHERE id = :id""",
            {"pid": payment_intent_id, "id": subscription_id}
        )
        sub = db.query_one("SELECT business_id FROM subscriptions WHERE id = :id", {"id": subscription_id})
        if sub:
            db.execute("UPDATE businesses SET subscription_active = 1 WHERE id = :bid", {"bid": sub["business_id"]})
