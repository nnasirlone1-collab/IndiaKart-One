#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "🇮🇳 Starting IndiaKart One Commerce Super-App Platform..."
echo "=========================================================="

export DATABASE_PATH="${DATABASE_PATH:-/tmp/indiakart_one.db}"
export APP_ENV="${APP_ENV:-development}"
export PYTHONPATH="/home/spark/src/indiakart_one:/working_dir/c_eeef5474b6bb5644/indiakart_one:${PYTHONPATH}"

# Seed database if not existing
python3 -m indiakart_one.app.seed_data

echo "Launching Uvicorn server on http://0.0.0.0:8000..."
exec python3 -m uvicorn indiakart_one.app.main:app --host 0.0.0.0 --port 8000
