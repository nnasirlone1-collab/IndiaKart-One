// IndiaKart One 🇮🇳 - Complete Client Application Logic
const app = {
  state: {
    token: null,
    user: null,
    mode: 'BUY', // 'BUY' or 'SELL'
    activeTab: 'home',
    location: { lat: 12.9352, lon: 77.6245, text: 'Koramangala, Bengaluru' },
    cart: { items: [], total: 0 },
    categories: [],
    businesses: [],
    products: []
  },

  async init() {
    console.log("[IndiaKart One] Initializing application...");
    await this.authenticateDefaultUser();
    await this.loadCategories();
    await this.loadNearbyBusinesses();
    await this.loadProducts();
    await this.refreshCart();
  },

  async authenticateDefaultUser() {
    // Authenticate as demo buyer Rahul Sharma
    try {
      const res = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: '9123456780', password: 'Password#123' })
      });
      const data = await res.json();
      if (data.status === 'success') {
        this.state.token = data.data.access_token;
        this.state.user = data.data;
        document.getElementById('account-name').textContent = data.data.full_name;
        document.getElementById('account-mobile').textContent = '+91 ' + data.data.mobile_number;
      }
    } catch (e) {
      console.warn("Auth initialization fallback:", e);
    }
  },

  getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': this.state.token ? `Bearer ${this.state.token}` : ''
    };
  },

  showToast(msg) {
    const toast = document.getElementById('app-toast');
    toast.textContent = msg;
    toast.style.display = 'block';
    setTimeout(() => { toast.style.display = 'none'; }, 3000);
  },

  setPlatformMode(mode) {
    this.state.mode = mode;
    document.getElementById('btn-mode-buy').classList.toggle('active', mode === 'BUY');
    document.getElementById('btn-mode-sell').classList.toggle('active', mode === 'SELL');

    if (mode === 'SELL') {
      document.getElementById('view-buyer').style.display = 'none';
      document.getElementById('view-b2b').style.display = 'none';
      document.getElementById('view-orders').style.display = 'none';
      document.getElementById('view-account').style.display = 'none';
      document.getElementById('view-admin').style.display = 'none';
      document.getElementById('view-seller').style.display = 'block';
      this.loadSellerDashboard();
    } else {
      document.getElementById('view-seller').style.display = 'none';
      document.getElementById('view-admin').style.display = 'none';
      this.switchTab('home');
    }
  },

  switchTab(tab) {
    this.state.activeTab = tab;
    // Update nav button active states
    ['home', 'categories', 'business', 'orders', 'account'].forEach(t => {
      const btn = document.getElementById(`nav-btn-${t}`);
      if (btn) btn.classList.toggle('active', t === tab || (tab === 'b2b' && t === 'business'));
    });

    // Toggle view containers
    document.getElementById('view-buyer').style.display = (tab === 'home' || tab === 'categories') ? 'block' : 'none';
    document.getElementById('view-b2b').style.display = (tab === 'b2b') ? 'block' : 'none';
    document.getElementById('view-orders').style.display = (tab === 'orders') ? 'block' : 'none';
    document.getElementById('view-account').style.display = (tab === 'account') ? 'block' : 'none';
    document.getElementById('view-seller').style.display = 'none';
    document.getElementById('view-admin').style.display = 'none';

    if (tab === 'b2b') this.loadB2BTab();
    if (tab === 'orders') this.loadOrders();
  },

  async loadCategories() {
    try {
      const res = await fetch('/api/v1/categories');
      const data = await res.json();
      this.state.categories = data.data;
      const strip = document.getElementById('category-strip');
      strip.innerHTML = this.state.categories.map(c => `
        <div class="category-item" onclick="app.filterProductsByCategory('${c.id}')">
          <div class="category-icon-box">📦</div>
          <span class="category-label">${c.name}</span>
        </div>
      `).join('');
    } catch (e) {
      console.error(e);
    }
  },

  async loadNearbyBusinesses(catId = null) {
    try {
      let url = `/api/v1/businesses?user_lat=${this.state.location.lat}&user_lon=${this.state.location.lon}&radius_km=30`;
      if (catId) url += `&category_id=${catId}`;
      const res = await fetch(url);
      const data = await res.json();
      this.state.businesses = data.data;
      const container = document.getElementById('nearby-business-scroll');
      container.innerHTML = this.state.businesses.map(b => `
        <div class="business-card" onclick="app.openStorefront('${b.id}')">
          <div class="biz-card-top">
            <img class="biz-logo" src="${b.logo_url || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=120'}" alt="${b.display_name}">
            <div class="biz-info">
              <div class="biz-name">${b.display_name}</div>
              <span class="biz-type-badge">${b.business_type}</span>
            </div>
          </div>
          <div class="biz-meta">
            <span class="biz-rating">★ ${b.rating.toFixed(1)} (${b.review_count})</span>
            <span class="biz-distance">${b.straight_line_distance_km ? b.straight_line_distance_km + ' km' : 'Nearby'}</span>
          </div>
        </div>
      `).join('');
    } catch (e) {
      console.error(e);
    }
  },

  async loadProducts(catId = null, query = '') {
    try {
      let url = '/api/v1/products?limit=50';
      if (catId) url += `&category_id=${catId}`;
      if (query) url += `&q=${encodeURIComponent(query)}`;
      const res = await fetch(url);
      const data = await res.json();
      this.state.products = data.data;
      this.renderProducts(this.state.products);
    } catch (e) {
      console.error(e);
    }
  },

  renderProducts(products) {
    const grid = document.getElementById('main-product-grid');
    grid.innerHTML = products.map(p => {
      const priceInr = (p.retail_price_minor / 100).toFixed(0);
      const isPod = p.pricing_mode === 'price_on_demand';
      return `
        <div class="product-card">
          <div class="product-img-box">
            <img class="product-img" src="${p.primary_image_url || 'https://images.unsplash.com/photo-1546470427-e26264be0b11?w=300'}" alt="${p.name}">
            ${p.is_veg ? '<div class="veg-indicator"><div class="veg-dot"></div></div>' : ''}
            ${p.has_wholesale_pricing ? '<div class="wholesale-chip">Bulk Tier</div>' : ''}
          </div>
          <div class="product-details">
            <div class="product-title">${p.name}</div>
            <div class="product-seller">${p.business_name}</div>
            <div class="product-pricing">
              ${isPod 
                ? '<span class="price-current" style="color:var(--blue);">Price on RFQ</span>' 
                : `<span class="price-current">₹${priceInr}</span><span class="price-unit">/${p.unit_of_measure}</span>`}
            </div>
            ${isPod 
              ? `<button class="btn-add" style="background:var(--navy);" onclick="app.openRFQModal('${p.name}')">Request Quote</button>`
              : `<button class="btn-add" onclick="app.addToCart('${p.id}')">Add to Cart</button>`}
          </div>
        </div>
      `;
    }).join('');
  },

  async searchProducts() {
    const q = document.getElementById('global-search-input').value;
    await this.loadProducts(null, q);
    this.showToast(`Showing results for "${q}"`);
  },

  filterProductsByCategory(catId, btnElement) {
    if (btnElement) {
      document.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active'));
      btnElement.classList.add('active');
    }
    this.loadProducts(catId);
  },

  filterBusinessesByType(type) {
    this.loadNearbyBusinesses(type);
  },

  async addToCart(productId, qty = 1) {
    try {
      const res = await fetch('/api/v1/cart/items', {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify({ product_id: productId, quantity: qty })
      });
      const data = await res.json();
      if (data.status === 'success') {
        this.showToast("Item added to cart 🛒");
        this.refreshCart();
      } else {
        this.showToast(data.detail || "Could not add item");
      }
    } catch (e) {
      this.showToast("Cart error");
    }
  },

  async refreshCart() {
    try {
      const res = await fetch('/api/v1/cart', { headers: this.getHeaders() });
      const data = await res.json();
      if (data.status === 'success') {
        const count = data.data.total_unique_items;
        document.getElementById('cart-badge').textContent = count;
        this.state.cart = data.data;
      }
    } catch (e) {
      console.warn(e);
    }
  },

  async openCart() {
    await this.refreshCart();
    const cart = this.state.cart;
    const content = document.getElementById('cart-content');

    if (!cart.sellers || cart.sellers.length === 0) {
      content.innerHTML = `
        <div style="text-align:center; padding: 40px 10px;">
          <div style="font-size: 40px;">🛒</div>
          <h3 style="color:var(--navy); margin-top:8px;">Your cart is empty</h3>
          <p style="font-size: 13px; color:var(--text-muted); margin-top:4px;">Add fresh vegetables, gourmet curries, or bulk wholesale products.</p>
        </div>
      `;
    } else {
      let sellersHtml = cart.sellers.map(s => `
        <div class="cart-seller-group">
          <div class="cart-seller-title">
            <span>🏬 ${s.business_name} (${s.business_type})</span>
            <span style="font-size:11px; color:var(--text-muted);">Delivery: ₹${(s.delivery_fee_minor/100).toFixed(0)}</span>
          </div>
          ${s.items.map(it => `
            <div class="cart-item-row">
              <div style="flex:1;">
                <div style="font-size:13px; font-weight:700; color:var(--navy);">${it.product_name}</div>
                <div style="font-size:11px; color:var(--text-muted);">₹${(it.applied_unit_price_minor/100).toFixed(0)} / ${it.unit_of_measure}</div>
              </div>
              <div class="qty-control">
                <button class="qty-btn" onclick="app.updateCartQty('${it.cart_item_id}', ${it.quantity - 1})">-</button>
                <span style="font-size:13px; font-weight:700;">${it.quantity}</span>
                <button class="qty-btn" onclick="app.updateCartQty('${it.cart_item_id}', ${it.quantity + 1})">+</button>
              </div>
              <div style="font-size:13px; font-weight:800; color:var(--navy); margin-left:12px;">₹${(it.line_total_minor/100).toFixed(0)}</div>
            </div>
          `).join('')}
        </div>
      `).join('');

      content.innerHTML = `
        ${sellersHtml}
        <div style="background:#F8FAFC; border-radius:10px; padding:12px; margin-top:10px;">
          <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
            <span>Items Subtotal:</span>
            <span>₹${(cart.items_subtotal_minor/100).toFixed(0)}</span>
          </div>
          <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
            <span>Estimated GST Tax:</span>
            <span>₹${(cart.tax_total_minor/100).toFixed(0)}</span>
          </div>
          <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
            <span>Delivery Charges:</span>
            <span>₹${(cart.delivery_fee_total_minor/100).toFixed(0)}</span>
          </div>
          ${cart.discount_minor > 0 ? `
            <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px; color:var(--success);">
              <span>Coupon Discount (${cart.applied_coupon}):</span>
              <span>-₹${(cart.discount_minor/100).toFixed(0)}</span>
            </div>
          ` : ''}
          <div style="display:flex; justify-content:space-between; font-size:16px; font-weight:800; color:var(--navy); border-top:1px solid var(--border); padding-top:8px; margin-top:6px;">
            <span>Grand Total:</span>
            <span>₹${(cart.grand_total_minor/100).toFixed(0)}</span>
          </div>
        </div>
        <button class="btn-primary" style="margin-top:16px;" onclick="app.proceedToCheckout()">Proceed to Checkout (₹${(cart.grand_total_minor/100).toFixed(0)})</button>
      `;
    }
    document.getElementById('modal-cart').classList.add('active');
  },

  async updateCartQty(itemId, newQty) {
    await fetch(`/api/v1/cart/items/${itemId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify({ quantity: newQty })
    });
    this.openCart();
    this.refreshCart();
  },

  async proceedToCheckout() {
    this.closeModal('modal-cart');
    // Fetch user addresses
    const addrRes = await fetch('/api/v1/users/addresses', { headers: this.getHeaders() });
    const addrs = (await addrRes.json()).data;
    const defaultAddr = addrs[0] || { id: 'addr-default', address_line1: 'Koramangala 4th Block, Bengaluru' };

    // Create checkout orders
    const checkRes = await fetch('/api/v1/checkout', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        shipping_address_id: defaultAddr.id,
        fulfilment_type: 'delivery'
      })
    });
    const checkData = await checkRes.json();
    if (checkData.status !== 'success') {
      this.showToast(checkData.detail || "Checkout error");
      return;
    }
    const order = checkData.data[0];

    // Create payment intent
    const intentRes = await fetch('/api/v1/payments/intent', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        order_id: order.id,
        payment_method: 'upi_qr'
      })
    });
    const intent = (await intentRes.json()).data;

    // Render Checkout & Payment QR Modal
    const checkoutContent = document.getElementById('checkout-content');
    checkoutContent.innerHTML = `
      <div style="text-align:center;">
        <div style="font-size:12px; text-transform:uppercase; font-weight:800; color:var(--text-muted);">Unified Payments Interface 🇮🇳</div>
        <div style="font-size:24px; font-weight:800; color:var(--navy); margin-top:4px;">₹${intent.amount_inr}</div>
        <div style="font-size:12px; color:var(--text-muted); margin-bottom:12px;">Order ID: ${order.order_number}</div>

        <div class="upi-qr-box">
          <div style="width:160px; height:160px; margin:0 auto; background:url('https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(intent.upi_payment_string)}') no-repeat center; background-size:contain;"></div>
          <div class="upi-vpa">indiakartone.merchant@icici</div>
          <div style="font-size:11px; color:var(--text-muted);">Scan with Google Pay, PhonePe, Paytm, BHIM, or CRED</div>
        </div>

        <button class="btn-primary" onclick="app.simulateVerifyPayment('${intent.payment_intent_id}', '${order.id}')">Simulate Payment Success (NPCI Verified)</button>
      </div>
    `;
    document.getElementById('modal-checkout').classList.add('active');
    this.refreshCart();
  },

  async simulateVerifyPayment(intentId, orderId) {
    const res = await fetch('/api/v1/payments/verify', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        payment_intent_id: intentId,
        gateway_payment_id: 'pay_' + Math.random().toString(36).substring(2, 10),
        gateway_signature: 'npci_hmac_verified'
      })
    });
    const data = await res.json();
    if (data.status === 'success') {
      this.closeModal('modal-checkout');
      this.showToast("Payment Successful! Order Confirmed 🎉");
      this.switchTab('orders');
    }
  },

  async loadOrders() {
    const res = await fetch('/api/v1/orders?role_view=buyer', { headers: this.getHeaders() });
    const orders = (await res.json()).data;
    const container = document.getElementById('orders-list');
    if (!orders || orders.length === 0) {
      container.innerHTML = `<div style="text-align:center; padding:30px; color:var(--text-muted);">No active orders yet.</div>`;
      return;
    }
    container.innerHTML = orders.map(o => `
      <div style="background:white; border-radius:12px; padding:14px; border:1px solid var(--border); margin-bottom:12px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
          <span style="font-size:13px; font-weight:800; color:var(--navy);">${o.order_number}</span>
          <span style="font-size:11px; font-weight:700; color:var(--blue); background:#EEF4FD; padding:2px 8px; border-radius:4px;">${o.order_status.toUpperCase()}</span>
        </div>
        <div style="font-size:12px; color:var(--text-muted); margin-bottom:8px;">Seller: ${o.business_name} • Total: ₹${(o.grand_total_minor/100).toFixed(0)}</div>
        <div style="font-size:11px; color:var(--success); font-weight:700;">● Payment: ${o.payment_status.toUpperCase()} (UPI)</div>
      </div>
    `).join('');
  },

  async loadB2BTab() {
    const res = await fetch('/api/v1/rfq', { headers: this.getHeaders() });
    const rfqs = (await res.json()).data;
    const container = document.getElementById('b2b-rfq-list');
    container.innerHTML = rfqs.map(r => `
      <div style="background:white; border-radius:12px; padding:14px; border:1px solid var(--border); margin-bottom:12px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <h4 style="font-size:14px; font-weight:800; color:var(--navy);">${r.product_name}</h4>
          <span style="font-size:11px; font-weight:700; color:var(--saffron); background:#FFF8ED; padding:2px 6px; border-radius:4px;">${r.status.toUpperCase()}</span>
        </div>
        <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">
          Requirement: ${r.required_quantity} ${r.unit_of_measure} • Destination: ${r.delivery_city} (${r.delivery_pincode})
        </div>
        <div style="font-size:12px; color:var(--navy); margin-top:6px;">
          Quotations Received: <strong>${r.quotations_received_count || 0}</strong>
        </div>
      </div>
    `).join('');
  },

  openRFQModal(defaultName = '') {
    if (defaultName) document.getElementById('rfq-pname').value = defaultName;
    document.getElementById('modal-rfq').classList.add('active');
  },

  async submitRFQ() {
    const pname = document.getElementById('rfq-pname').value;
    const qty = parseInt(document.getElementById('rfq-qty').value) || 100;
    const uom = document.getElementById('rfq-uom').value;
    const city = document.getElementById('rfq-city').value;
    const specs = document.getElementById('rfq-specs').value;

    const res = await fetch('/api/v1/rfq', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({
        product_name: pname,
        required_quantity: qty,
        unit_of_measure: uom,
        delivery_pincode: '560058',
        delivery_city: city,
        specifications: specs
      })
    });
    const data = await res.json();
    if (data.status === 'success') {
      this.closeModal('modal-rfq');
      this.showToast("RFQ posted to verified suppliers!");
      this.switchTab('b2b');
    }
  },

  async loadSellerDashboard() {
    // Authenticate as Vikram Singh (Seller)
    const login = await fetch('/api/v1/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: '9234567890', password: 'Password#123' })
    });
    const token = (await login.json()).data.access_token;
    const res = await fetch('/api/v1/seller/dashboard', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = (await res.json()).data;
    if (data) {
      document.getElementById('seller-biz-name').textContent = data.business.display_name;
      document.getElementById('seller-kpi-sales').textContent = `₹${data.metrics.gmv_inr}`;
      document.getElementById('seller-kpi-orders').textContent = data.metrics.pending_orders;
    }
  },

  async openAdminPortal() {
    // Authenticate as Super Admin
    const login = await fetch('/api/v1/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: '9876543210', password: 'Admin#IndiaKart2026' })
    });
    const adminToken = (await login.json()).data.access_token;
    this.adminToken = adminToken;

    // Load admin metrics
    const ovRes = await fetch('/api/v1/admin/overview', {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    const metrics = (await ovRes.json()).data;

    const kpiGrid = document.getElementById('admin-kpi-grid');
    kpiGrid.innerHTML = `
      <div style="background:white; padding:10px; border-radius:8px; border:1px solid var(--border); text-align:center;">
        <div style="font-size:11px; color:var(--text-muted);">Total Users</div>
        <div style="font-size:16px; font-weight:800; color:var(--navy);">${metrics.total_users}</div>
      </div>
      <div style="background:white; padding:10px; border-radius:8px; border:1px solid var(--border); text-align:center;">
        <div style="font-size:11px; color:var(--text-muted);">Approved Sellers</div>
        <div style="font-size:16px; font-weight:800; color:var(--success);">${metrics.approved_businesses}</div>
      </div>
      <div style="background:white; padding:10px; border-radius:8px; border:1px solid var(--border); text-align:center;">
        <div style="font-size:11px; color:var(--text-muted);">Total GMV</div>
        <div style="font-size:16px; font-weight:800; color:var(--navy);">₹${metrics.gmv_inr}</div>
      </div>
      <div style="background:white; padding:10px; border-radius:8px; border:1px solid var(--border); text-align:center;">
        <div style="font-size:11px; color:var(--text-muted);">Platform Fees</div>
        <div style="font-size:16px; font-weight:800; color:var(--blue);">₹${metrics.commission_inr}</div>
      </div>
    `;

    // Load pending sellers
    const pendRes = await fetch('/api/v1/admin/sellers/pending', {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    const sellers = (await pendRes.json()).data;
    const sellersCont = document.getElementById('admin-pending-sellers');
    if (sellers.length === 0) {
      sellersCont.innerHTML = `<div style="font-size:12px; color:var(--text-muted);">No pending KYC applications. All sellers up to date!</div>`;
    } else {
      sellersCont.innerHTML = sellers.map(s => `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid var(--border);">
          <div>
            <div style="font-weight:700; color:var(--navy);">${s.display_name} (${s.business_type})</div>
            <div style="font-size:11px; color:var(--text-muted);">Owner: ${s.owner_name} • GSTIN: ${s.gstin || 'N/A'}</div>
          </div>
          <div style="display:flex; gap:6px;">
            <button class="btn-primary" style="padding:4px 10px; font-size:11px;" onclick="app.approveSeller('${s.id}')">Approve</button>
          </div>
        </div>
      `).join('');
    }

    // Load audit logs
    const auditRes = await fetch('/api/v1/admin/audit-logs', {
      headers: { 'Authorization': `Bearer ${adminToken}` }
    });
    const logs = (await auditRes.json()).data;
    document.getElementById('admin-audit-logs').innerHTML = logs.map(l => `
      <div style="padding:6px 0; border-bottom:1px solid #F1F5F9;">
        <span style="font-weight:700; color:var(--navy);">${l.action_type}</span>: ${l.old_value} ➔ ${l.new_value}
        <div style="font-size:10px; color:var(--text-muted);">${new Date(l.created_at).toLocaleString()} by ${l.admin_name}</div>
      </div>
    `).join('');

    // Toggle viewport
    document.querySelectorAll('.view-container').forEach(v => v.style.display = 'none');
    document.getElementById('view-admin').style.display = 'block';
  },

  async approveSeller(bizId) {
    await fetch(`/api/v1/admin/sellers/${bizId}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.adminToken}` },
      body: JSON.stringify({ action: 'approve' })
    });
    this.showToast("Seller KYC Approved!");
    this.openAdminPortal();
  },

  async updateSubscriptionPrice() {
    const newPriceInr = parseInt(document.getElementById('admin-new-price-input').value) || 1499;
    const plansRes = await fetch('/api/v1/subscriptions/plans');
    const plans = (await plansRes.json()).data;
    const planId = plans[0].id;

    const res = await fetch(`/api/v1/admin/subscriptions/plans/${planId}/price`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.adminToken}` },
      body: JSON.stringify({
        new_monthly_price_minor: newPriceInr * 100,
        notes: "Updated from Admin Console"
      })
    });
    const data = await res.json();
    if (data.status === 'success') {
      this.showToast(`Business Pro Price Updated to ₹${newPriceInr}/month! Recorded in audit log.`);
      this.openAdminPortal();
    }
  },

  closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
  },

  promptLocation() {
    const loc = prompt("Enter delivery address or locality in India:", this.state.location.text);
    if (loc) {
      this.state.location.text = loc;
      document.getElementById('current-location-text').textContent = loc;
      this.showToast(`Delivery location set to: ${loc}`);
    }
  },

  promptLanguage() {
    const lang = prompt("Select display language (en: English, hi: हिन्दी, ur: اردو):", "en");
    if (lang) {
      this.showToast("Language preference saved.");
    }
  },

  logout() {
    this.state.token = null;
    this.showToast("Signed out successfully.");
    setTimeout(() => { location.reload(); }, 500);
  }
};

window.addEventListener('DOMContentLoaded', () => {
  app.init();
});
